import os
import processing
from qgis.core import QgsRasterLayer, QgsProject

# =========================================================
# USE ACTIVE RASTER LAYER
# =========================================================

raster_layer = iface.activeLayer()

if raster_layer is None:
    raise Exception("No active layer selected. Click the raster layer first.")

if not isinstance(raster_layer, QgsRasterLayer):
    raise Exception("The active layer is not a raster. Select the raster layer first.")

print("Using raster:", raster_layer.name())
print("Source:", raster_layer.source())

# =========================================================
# OUTPUT
# =========================================================

input_dir = os.path.dirname(raster_layer.source())

output_raster = os.path.join(
    input_dir,
    "expected_costs_soy_production_reclassified_5880_250m.tif"
)

# =========================================================
# RASTER CALCULATOR
# =========================================================
# Classes:
# 3 = 544 <= value < 1000
# 2 = 1000 <= value <= 1300
# 1 = value > 1300
# 0 = other values

band_name = raster_layer.name() + "@1"

expression = (
    f'(({band_name} >= 544) AND ({band_name} < 1000)) * 3 + '
    f'(({band_name} >= 1000) AND ({band_name} <= 1300)) * 2 + '
    f'({band_name} > 1300) * 1'
)

print("Expression:")
print(expression)

processing.run("qgis:rastercalculator", {
    "EXPRESSION": expression,
    "LAYERS": [raster_layer],
    "CELLSIZE": raster_layer.rasterUnitsPerPixelX(),
    "EXTENT": raster_layer.extent(),
    "CRS": raster_layer.crs(),
    "OUTPUT": output_raster
})

# =========================================================
# LOAD OUTPUT
# =========================================================

output_layer = QgsRasterLayer(output_raster, "soybean_cost_reclassified")

if output_layer.isValid():
    QgsProject.instance().addMapLayer(output_layer)
    print("Reclassification completed successfully.")
    print("Output saved at:")
    print(output_raster)
else:
    raise Exception("Output raster was created, but QGIS could not load it.")