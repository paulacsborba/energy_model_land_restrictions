from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
from qgis.core import QgsRasterLayer
import os

# INPUTS
sugar_path = r"C:/Users/pcsbo/OneDrive/PostDoc/INPE/paper_land_tenure/geospatial_data/rasters/soybean/Expected costs soybean production\expected_costs_soy_production_reclassified_5880_250m.tif"
avail_path = r"H:\My Drive\NZB_raster\rasters\available\br_available_lands_250_version2.tif"
priority_path = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\priority_lands_for_conservation\priority_lands_for_conservation_250m_merged.tif"

# 1) MUDAR CENÁRIO: baseline, conservation, governance, integrated, degraded_pastures [high, medium, low]
out_path = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\soybean\scenarios\conservation\br_soybean_h_available_250m_conservation.tif"

# LOAD RASTERS
sugar = QgsRasterLayer(sugar_path, "sugar")
avail = QgsRasterLayer(avail_path, "avail")
priority = QgsRasterLayer(priority_path, "priority")

if not sugar.isValid() or not avail.isValid() or not priority.isValid():
    raise Exception("Raster failed to load")

# ENTRIES
entries = []

e1 = QgsRasterCalculatorEntry()
e1.ref = 'A@1'
e1.raster = sugar
e1.bandNumber = 1
entries.append(e1)

e2 = QgsRasterCalculatorEntry()
e2.ref = 'B@1'
e2.raster = avail
e2.bandNumber = 1
entries.append(e2)

e3 = QgsRasterCalculatorEntry()
e3.ref = 'C@1'
e3.raster = priority
e3.bandNumber = 1
entries.append(e3)

# 2) FORMULA, alterar A = 3 (high), 2 (medium), 1 (low)
# C@1 = 1 mantém apenas pixels onde priority raster = 1
formula = '(A@1 = 3) * (B@1=1) * (C@1 = 1)'

# CALCULATOR
calc = QgsRasterCalculator(
    formula,
    out_path,
    'GTiff',
    sugar.extent(),
    sugar.width(),
    sugar.height(),
    entries
)

result = calc.processCalculation()

print("Result code:", result)

if os.path.exists(out_path):
    print("File created successfully!")
    iface.addRasterLayer(out_path, "test_qgis_calc")
else:
    print("File NOT created")