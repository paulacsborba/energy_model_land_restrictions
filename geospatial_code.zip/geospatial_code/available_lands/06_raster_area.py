import os
import csv

from qgis.core import (
    QgsVectorLayer,
    QgsRasterLayer,
    QgsProject,
    QgsVectorFileWriter,
    QgsField,
    edit
)
from qgis.analysis import QgsZonalStatistics
from PyQt5.QtCore import QVariant

# =========================================================
# INPUTS
# =========================================================

# Layer de zonas
zones_path = r"C:\Users\pcsbo\OneDrive\Doutorado\Library\Data\shapefile\zones\zones_\zones_fixed.shp"
zone_field = "ZONE"

# Saídas
output_gpkg = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\zonal_stats_sugarcane_embrapa.gpkg"
output_csv  = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\zonal_stats_sugarcane_embrapa.csv"

# Área do pixel de 250 m em km²
PIXEL_AREA_KM2 = 0.25 * 0.25   # = 0.0625 km²

# =========================================================
# RASTERS remove or add _embrapa
# =========================================================

rasters = {
    "sugarcane_high_baseline": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\baseline\br_sugarcane_high_available_250m_baseline_embrapa.tif",
    "sugarcane_medium_baseline": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\baseline\br_sugarcane_medium_available_250m_baseline_embrapa.tif",
    "sugarcane_low_baseline": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\baseline\br_sugarcane_low_available_250m_baseline_embrapa.tif",

    "sugarcane_high_conservation": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\conservation\br_sugarcane_high_available_250m_conservation_embrapa.tif",
    "sugarcane_medium_conservation": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\conservation\br_sugarcane_medium_available_250m_conservation_embrapa.tif",
    "sugarcane_low_conservation": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\conservation\br_sugarcane_low_available_250m_conservation_embrapa.tif",

    "sugarcane_high_degraded_pastures": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\degraded_pastures\br_sugarcane_high_available_250m_degraded_pastures_embrapa.tif",
    "sugarcane_medium_degraded_pastures": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\degraded_pastures\br_sugarcane_medium_available_250m_degraded_pastures_embrapa.tif",
    "sugarcane_low_degraded_pastures": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\degraded_pastures\br_sugarcane_low_available_250m_degraded_pastures_embrapa.tif",

    "sugarcane_high_governance": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\governance\br_sugarcane_high_available_250m_governance_embrapa.tif",
    "sugarcane_medium_governance": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\governance\br_sugarcane_medium_available_250m_governance_embrapa.tif",
    "sugarcane_low_governance": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\governance\br_sugarcane_low_available_250m_governance_embrapa.tif",

    "sugarcane_high_integrated": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\integrated\br_sugarcane_high_available_250m_integrated_embrapa.tif",
    "sugarcane_medium_integrated": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\integrated\br_sugarcane_medium_available_250m_integrated_embrapa.tif",
    "sugarcane_low_integrated": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\integrated\br_sugarcane_low_available_250m_integrated_embrapa.tif",
}

# =========================================================
# LOAD ZONES
# =========================================================

zones = QgsVectorLayer(zones_path, "zones", "ogr")
if not zones.isValid():
    raise Exception("Falha ao carregar o layer de zonas.")

field_names = [f.name() for f in zones.fields()]
if zone_field not in field_names:
    raise Exception(f"Campo '{zone_field}' não encontrado. Campos disponíveis: {field_names}")

# =========================================================
# FILTER EXISTING RASTERS
# =========================================================

existing_rasters = {}
missing_rasters = {}

for name, path in rasters.items():
    if os.path.exists(path):
        r = QgsRasterLayer(path, name)
        if r.isValid():
            existing_rasters[name] = path
        else:
            missing_rasters[name] = f"Arquivo existe mas QGIS não conseguiu carregar: {path}"
    else:
        missing_rasters[name] = f"Arquivo não encontrado: {path}"

print("\n=== RASTERS ENCONTRADOS ===")
for k in existing_rasters:
    print(k)

print("\n=== RASTERS FALTANDO / INVÁLIDOS ===")
for k, v in missing_rasters.items():
    print(f"{k} -> {v}")

if not existing_rasters:
    raise Exception("Nenhum raster válido foi encontrado.")

# =========================================================
# CREATE WORKING COPY AS GPKG
# =========================================================

if os.path.exists(output_gpkg):
    os.remove(output_gpkg)

err = QgsVectorFileWriter.writeAsVectorFormat(
    zones,
    output_gpkg,
    "UTF-8",
    zones.crs(),
    "GPKG"
)

work_layer = QgsVectorLayer(output_gpkg, "work", "ogr")
if not work_layer.isValid():
    raise Exception("Falha ao criar layer de trabalho em GPKG.")

# =========================================================
# ZONAL STATISTICS
# =========================================================

processed_sum_fields = []

for i, (raster_name, raster_path) in enumerate(existing_rasters.items(), start=1):
    print(f"Processando: {raster_name}")

    raster = QgsRasterLayer(raster_path, raster_name)
    if not raster.isValid():
        print(f"Pulando raster inválido: {raster_name}")
        continue

    prefix = f"r{i:02d}_"

    zs = QgsZonalStatistics(
        work_layer,
        raster,
        prefix,
        1,
        QgsZonalStatistics.Sum
    )

    result = zs.calculateStatistics(None)

    if result != 0:
        print(f"Atenção: erro no zonal statistics para {raster_name}. Código: {result}")
        continue

    work_layer.updateFields()
    current_fields = [f.name() for f in work_layer.fields()]

    temp_sum_field = f"{prefix}sum"
    final_sum_name = f"{raster_name}_pixel_sum"

    if temp_sum_field in current_fields:
        idx = work_layer.fields().indexFromName(temp_sum_field)
        ok = work_layer.dataProvider().renameAttributes({idx: final_sum_name})
        work_layer.updateFields()

        if ok:
            processed_sum_fields.append(final_sum_name)
        else:
            print(f"Atenção: não foi possível renomear {temp_sum_field} para {final_sum_name}")
    else:
        print(f"Atenção: campo {temp_sum_field} não encontrado após cálculo.")

# =========================================================
# ADD AREA FIELDS
# =========================================================

current_fields = [f.name() for f in work_layer.fields()]
new_fields = []

for sum_field in processed_sum_fields:
    area_field = sum_field.replace("_pixel_sum", "_area_km2")
    if area_field not in current_fields:
        new_fields.append(QgsField(area_field, QVariant.Double, "double", 20, 6))

if new_fields:
    work_layer.dataProvider().addAttributes(new_fields)
    work_layer.updateFields()

# =========================================================
# CALCULATE AREA FIELDS
# =========================================================

current_fields = [f.name() for f in work_layer.fields()]

with edit(work_layer):
    for feat in work_layer.getFeatures():
        changed = False

        for sum_field in processed_sum_fields:
            area_field = sum_field.replace("_pixel_sum", "_area_km2")

            if sum_field in current_fields and area_field in current_fields:
                val = feat[sum_field]
                if val is None:
                    val = 0
                feat[area_field] = float(val) * PIXEL_AREA_KM2
                changed = True

        if changed:
            work_layer.updateFeature(feat)

print("\nÁreas calculadas com sucesso.")

# =========================================================
# EXPORT ONLY DESIRED COLUMNS TO CSV
# =========================================================

final_fields = [zone_field]

for sum_field in processed_sum_fields:
    area_field = sum_field.replace("_pixel_sum", "_area_km2")
    if sum_field in [f.name() for f in work_layer.fields()]:
        final_fields.append(sum_field)
    if area_field in [f.name() for f in work_layer.fields()]:
        final_fields.append(area_field)

with open(output_csv, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.writer(f)
    writer.writerow(final_fields)

    for feat in work_layer.getFeatures():
        row = [feat[field] for field in final_fields]
        writer.writerow(row)

print("\nConcluído.")
print("GPKG:", output_gpkg)
print("CSV :", output_csv)

QgsProject.instance().addMapLayer(work_layer)