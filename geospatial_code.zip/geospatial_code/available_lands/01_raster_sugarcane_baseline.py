from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
from qgis.core import QgsRasterLayer

import os

#ATENÇÃO MUDAR 1 E 2

# INPUTS
sugar_path = r"H:\My Drive\NZB_raster\rasters\Sugarcane suitability\br_sugarcane_suitable_250m_embrapa.tif"
avail_path = r"H:\My Drive\NZB_raster\rasters\available\br_available_lands_250_version2.tif"

# OUTPUT

# 1) MUDAR CENÁRIO:baseline, conservation, governance, integrated, degraded_pastures [high, medium, low]
out_path = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\rasters\sugarcane\scenarios\baseline\br_sugarcane_low_available_250m_baseline_embrapa.tif"

# LOAD RASTERS
sugar = QgsRasterLayer(sugar_path, "sugar")
avail = QgsRasterLayer(avail_path, "avail")

if not sugar.isValid() or not avail.isValid():
    raise Exception("Raster failed to load")

# ENTRIES
entries = []

e1 = QgsRasterCalculatorEntry()
e1.ref = 'A@1'
e1.raster = sugar
e1.bandNumber = 1
entries.append(e1)

e2 = QgsRasterCalculatorEntry()
e2.ref = 'B@1'
e2.raster = avail
e2.bandNumber = 1
entries.append(e2)

# 2) FORMULA - MUDAR PARA 1 = HIGH, 2 = MEDIUM, 3 = LOW
formula = '(A@1 = 3) * (B@1 = 1)'

# CALCULATOR
calc = QgsRasterCalculator(
    formula,
    out_path,
    'GTiff',
    sugar.extent(),
    sugar.width(),
    sugar.height(),
    entries
)

result = calc.processCalculation()

print("Result code:", result)

if os.path.exists(out_path):
    print("File created successfully!")
    iface.addRasterLayer(out_path, "test_qgis_calc")
else:
    print("File NOT created")