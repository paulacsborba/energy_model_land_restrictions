import os
import re
import csv
import processing

from qgis.core import (
    QgsRasterLayer,
    QgsVectorLayer
)
from qgis.analysis import (
    QgsRasterCalculator,
    QgsRasterCalculatorEntry
)

# ============================================================
# CONFIGURATION
# ============================================================

# ----------------------------
# Scenarios
# ----------------------------
SCENARIOS = [
    "baseline",
    "conservation",
    "governance",
    "degraded_pastures",
    "integrated"
]

# ----------------------------
# Sugarcane potentials
# Soybean will be aggregated into a single raster:
# high OR medium OR low
# ----------------------------
SUGARCANE_POTENTIALS = [
    "high",
    "medium",
    "low"
]

SOYBEAN_POTENTIALS = [
    "high",
    "medium",
    "low"
]

# ----------------------------
# Raster templates
# ----------------------------
SOYBEAN_TEMPLATE = (
    r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"
    r"\geospatial_data\rasters\soybean\scenarios\{scenario}"
    r"\br_soybean_{potential}_available_250m_{scenario}.tif"
)

SUGARCANE_TEMPLATE = (
    r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"
    r"\geospatial_data\rasters\sugarcane\scenarios\{scenario}"
    r"\br_sugarcane_{potential}_available_250m_{scenario}.tif"
)

# ----------------------------
# YAML template with sugarcane available area
# ----------------------------
YAML_TEMPLATE = (
    r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"
    r"\geospatial_data\feedstocks_area"
    r"\{scenario}_sugarcane_{potential}_available_area.yaml"
)

# ----------------------------
# Zones shapefile
# ----------------------------
ZONES_PATH = (
    r"C:\Users\pcsbo\OneDrive\Doutorado\Library\Data"
    r"\shapefile\zones\zones_\zones_fixed.shp"
)

# ----------------------------
# Output directory
# ----------------------------
OUTPUT_DIR = (
    r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"
    r"\geospatial_data\rasters\intersection_sugarcane_soybean_unique"
)

OUTPUT_RASTERS_DIR = os.path.join(OUTPUT_DIR, "rasters")

OUTPUT_CSV = os.path.join(
    OUTPUT_DIR,
    "sugarcane_by_potential_soybean_unique_intersection_area_by_zone.csv"
)

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_RASTERS_DIR, exist_ok=True)

# ----------------------------
# Pixel area
# 250 m x 250 m = 0.25 km x 0.25 km = 0.0625 km²
# ----------------------------
PIXEL_AREA_KM2 = 0.25 * 0.25  # 0.0625 km²

# ----------------------------
# Assumption:
# Sugarcane available area in YAML is already in km².
# If not, change this factor:
# - ha  -> 0.01
# - m²  -> 0.000001
# ----------------------------
YAML_AREA_TO_KM2 = 1.0


# ============================================================
# FUNCTIONS
# ============================================================

def validate_layer(layer, layer_name, path):
    """Check if a QGIS raster/vector layer is valid."""
    if not layer.isValid():
        raise Exception(
            f"{layer_name} is not valid.\nCheck path:\n{path}"
        )


def detect_zone_field(zones_layer):
    """
    Automatically detect the field containing zone names such as SP_Z1, BA_Z2, etc.
    """
    zone_pattern = re.compile(r"^[A-Z]{2}_Z\d+$")

    fields = [field.name() for field in zones_layer.fields()]

    # First try: detect from actual values
    for field_name in fields:
        checked = 0
        matches = 0

        for feat in zones_layer.getFeatures():
            value = str(feat[field_name]).strip()
            checked += 1

            if zone_pattern.match(value):
                matches += 1

            if checked >= 30:
                break

        if checked > 0 and matches >= max(1, checked * 0.5):
            print(f"Zone field automatically detected: {field_name}")
            return field_name

    # Second try: common field names
    candidate_fields = [
        "zone", "Zone", "ZONE",
        "zones", "Zones", "ZONES",
        "name", "Name", "NAME",
        "location", "Location", "LOCATION",
        "id", "ID"
    ]

    for candidate in candidate_fields:
        if candidate in fields:
            print(f"Zone field selected by common name: {candidate}")
            return candidate

    raise Exception(
        "Could not detect the zone ID field automatically.\n"
        f"Available fields: {fields}\n"
        "Please set the correct zone field manually in the script."
    )


def create_soybean_unique_raster(scenario, output_path):
    """
    Create a binary soybean raster aggregating all soybean potentials:

    soybean_unique = soybean_high OR soybean_medium OR soybean_low

    Output:
      1 = available for soybean in at least one potential class
      0 = otherwise
    """

    soy_paths = {
        potential: SOYBEAN_TEMPLATE.format(
            scenario=scenario,
            potential=potential
        )
        for potential in SOYBEAN_POTENTIALS
    }

    soy_layers = {}

    for potential, path in soy_paths.items():
        layer = QgsRasterLayer(path, f"soybean_{potential}")
        validate_layer(layer, f"Soybean {potential} raster", path)
        soy_layers[potential] = layer

    # Remove output if already exists
    if os.path.exists(output_path):
        try:
            os.remove(output_path)
        except Exception:
            pass

    entries = []

    for potential, layer in soy_layers.items():
        entry = QgsRasterCalculatorEntry()
        entry.ref = f"soy_{potential}@1"
        entry.raster = layer
        entry.bandNumber = 1
        entries.append(entry)

    expression = (
        '(("soy_high@1" = 1) '
        'OR ("soy_medium@1" = 1) '
        'OR ("soy_low@1" = 1)) * 1'
    )

    # Use the high soybean raster as spatial reference
    reference_layer = soy_layers["high"]

    calculator = QgsRasterCalculator(
        expression,
        output_path,
        "GTiff",
        reference_layer.extent(),
        reference_layer.width(),
        reference_layer.height(),
        entries
    )

    result = calculator.processCalculation()

    if result != 0:
        raise Exception(
            f"Soybean union raster calculator failed for:\n{output_path}\n"
            f"QgsRasterCalculator result code: {result}"
        )

    print(f"Soybean unique raster created:\n{output_path}")

    return output_path


def create_intersection_raster(soy_unique_path, sugar_path, output_path):
    """
    Create a binary raster:

    1 = soybean_unique == 1 AND sugarcane == 1
    0 = otherwise
    """

    soy_layer = QgsRasterLayer(soy_unique_path, "soybean_unique")
    sugar_layer = QgsRasterLayer(sugar_path, "sugarcane")

    validate_layer(soy_layer, "Soybean unique raster", soy_unique_path)
    validate_layer(sugar_layer, "Sugarcane raster", sugar_path)

    # Remove output if already exists
    if os.path.exists(output_path):
        try:
            os.remove(output_path)
        except Exception:
            pass

    entries = []

    soy_entry = QgsRasterCalculatorEntry()
    soy_entry.ref = "soy_unique@1"
    soy_entry.raster = soy_layer
    soy_entry.bandNumber = 1
    entries.append(soy_entry)

    sugar_entry = QgsRasterCalculatorEntry()
    sugar_entry.ref = "sugar@1"
    sugar_entry.raster = sugar_layer
    sugar_entry.bandNumber = 1
    entries.append(sugar_entry)

    expression = '(("soy_unique@1" = 1) AND ("sugar@1" = 1)) * 1'

    calculator = QgsRasterCalculator(
        expression,
        output_path,
        "GTiff",
        sugar_layer.extent(),
        sugar_layer.width(),
        sugar_layer.height(),
        entries
    )

    result = calculator.processCalculation()

    if result != 0:
        raise Exception(
            f"Intersection raster calculator failed for:\n{output_path}\n"
            f"QgsRasterCalculator result code: {result}"
        )

    print(f"Intersection raster created:\n{output_path}")

    return output_path


def read_yaml_text(path):
    """Read YAML file as plain text."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"YAML file not found:\n{path}")

    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def extract_available_area_from_yaml(yaml_path):
    """
    Extract sugarcane available area by zone from YAML.

    Returns:
      dict: {zone_name: available_area_km2}
    """

    text = read_yaml_text(yaml_path)

    # --------------------------------------------------------
    # Try to load as actual YAML, if PyYAML is available
    # --------------------------------------------------------
    try:
        import yaml
        data = yaml.safe_load(text)

        output = {}
        zone_pattern = re.compile(r"^[A-Z]{2}_Z\d+$")

        def recursive_search(obj, current_zone=None):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    key_str = str(key)

                    # Case 1: key is exactly a zone name
                    new_zone = current_zone
                    if zone_pattern.match(key_str):
                        new_zone = key_str

                    # Case 2: flattened key contains zone name
                    zone_in_key = re.search(r"([A-Z]{2}_Z\d+)", key_str)
                    if zone_in_key:
                        new_zone = zone_in_key.group(1)

                    # Detect area keys
                    key_lower = key_str.lower()
                    is_area_key = (
                        "resource_area_max" in key_lower
                        or "available_area" in key_lower
                        or key_lower.endswith(".area")
                    )

                    if is_area_key and new_zone is not None:
                        if isinstance(value, (int, float)):
                            output[new_zone] = float(value) * YAML_AREA_TO_KM2

                    recursive_search(value, new_zone)

            elif isinstance(obj, list):
                for item in obj:
                    recursive_search(item, current_zone)

        recursive_search(data)

        if len(output) > 0:
            return output

    except ImportError:
        print("PyYAML not available. Falling back to text-based YAML parser.")
    except Exception as e:
        print(f"Warning: YAML structured parsing failed for {yaml_path}")
        print(f"Reason: {e}")
        print("Falling back to text-based parser.")

    # --------------------------------------------------------
    # Fallback: text-based parser
    # --------------------------------------------------------
    output = {}

    zone_pattern = re.compile(r"([A-Z]{2}_Z\d+)")
    number_pattern = re.compile(
        r"([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)"
    )

    current_zone = None

    for line in text.splitlines():

        zone_match = zone_pattern.search(line)
        if zone_match:
            current_zone = zone_match.group(1)

        line_lower = line.lower()

        if current_zone is not None:
            if (
                "resource_area_max" in line_lower
                or "available_area" in line_lower
            ):
                number_match = number_pattern.search(line.split(":")[-1])
                if number_match:
                    value = float(number_match.group(1))
                    output[current_zone] = value * YAML_AREA_TO_KM2

    if len(output) == 0:
        raise Exception(
            f"Could not extract area values from YAML:\n{yaml_path}\n"
            "Check whether the file contains zone-specific area values."
        )

    return output


def calculate_zonal_intersection_area(
    intersection_raster_path,
    zones_path,
    zone_field
):
    """
    Calculate the sum of the binary intersection raster by zone.
    Since raster values are 1, sum = number of intersected pixels.
    """

    zonal_result = processing.run(
        "native:zonalstatisticsfb",
        {
            "INPUT": zones_path,
            "INPUT_RASTER": intersection_raster_path,
            "RASTER_BAND": 1,
            "COLUMN_PREFIX": "int_",
            # 1 = Sum in QGIS Zonal Statistics
            "STATISTICS": [1],
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    zonal_layer = zonal_result["OUTPUT"]

    # Identify the generated sum field
    field_names = [field.name() for field in zonal_layer.fields()]
    sum_field_candidates = [
        f for f in field_names
        if f.lower().startswith("int_") and "sum" in f.lower()
    ]

    if len(sum_field_candidates) == 0:
        raise Exception(
            "Could not find zonal statistics sum field.\n"
            f"Fields returned: {field_names}"
        )

    sum_field = sum_field_candidates[0]

    area_by_zone = {}

    for feature in zonal_layer.getFeatures():
        zone = str(feature[zone_field]).strip()
        pixel_sum = feature[sum_field]

        if pixel_sum is None:
            pixel_sum = 0

        pixel_sum = float(pixel_sum)

        # Because raster is binary 0/1:
        # pixel_sum = number of intersecting pixels
        intersection_area_km2 = pixel_sum * PIXEL_AREA_KM2

        area_by_zone[zone] = {
            "intersection_pixels": pixel_sum,
            "intersection_area_km2": intersection_area_km2
        }

    return area_by_zone


# ============================================================
# MAIN PROCESS
# ============================================================

# Load zones layer and detect zone ID field
zones_layer = QgsVectorLayer(ZONES_PATH, "zones", "ogr")
validate_layer(zones_layer, "Zones shapefile", ZONES_PATH)

ZONE_FIELD = detect_zone_field(zones_layer)

all_rows = []

for scenario in SCENARIOS:

    print("\n" + "=" * 90)
    print(f"Creating soybean unique raster for scenario = {scenario}")
    print("=" * 90)

    # --------------------------------------------------------
    # Scenario output directory
    # --------------------------------------------------------
    scenario_output_dir = os.path.join(
        OUTPUT_RASTERS_DIR,
        scenario
    )
    os.makedirs(scenario_output_dir, exist_ok=True)

    # --------------------------------------------------------
    # 1. Create soybean unique raster
    #    soybean_unique = high OR medium OR low
    # --------------------------------------------------------
    soybean_unique_raster_path = os.path.join(
        scenario_output_dir,
        f"br_soybean_unique_available_250m_{scenario}.tif"
    )

    create_soybean_unique_raster(
        scenario=scenario,
        output_path=soybean_unique_raster_path
    )

    # --------------------------------------------------------
    # 2. Intersect soybean unique with each sugarcane potential
    # --------------------------------------------------------
    for sugarcane_potential in SUGARCANE_POTENTIALS:

        print("\n" + "-" * 90)
        print(
            f"Processing scenario = {scenario} | "
            f"sugarcane potential = {sugarcane_potential} | "
            f"soybean = unique_all_potentials"
        )
        print("-" * 90)

        # ----------------------------------------------------
        # Input sugarcane raster
        # ----------------------------------------------------
        sugar_path = SUGARCANE_TEMPLATE.format(
            scenario=scenario,
            potential=sugarcane_potential
        )

        # ----------------------------------------------------
        # Input YAML with sugarcane available area
        # ----------------------------------------------------
        yaml_path = YAML_TEMPLATE.format(
            scenario=scenario,
            potential=sugarcane_potential
        )

        # ----------------------------------------------------
        # Output intersection raster path
        # ----------------------------------------------------
        intersection_raster_path = os.path.join(
            scenario_output_dir,
            (
                f"br_intersection_sugarcane_{sugarcane_potential}"
                f"_soybean_unique_{scenario}.tif"
            )
        )

        # ----------------------------------------------------
        # 2.1 Create intersection raster
        # ----------------------------------------------------
        create_intersection_raster(
            soy_unique_path=soybean_unique_raster_path,
            sugar_path=sugar_path,
            output_path=intersection_raster_path
        )

        # ----------------------------------------------------
        # 2.2 Calculate intersected area by zone
        # ----------------------------------------------------
        intersection_by_zone = calculate_zonal_intersection_area(
            intersection_raster_path=intersection_raster_path,
            zones_path=ZONES_PATH,
            zone_field=ZONE_FIELD
        )

        # ----------------------------------------------------
        # 2.3 Read available sugarcane area from YAML
        # ----------------------------------------------------
        sugarcane_available_area_by_zone = extract_available_area_from_yaml(
            yaml_path
        )

        # ----------------------------------------------------
        # 2.4 Combine results
        # ----------------------------------------------------
        all_zones = sorted(
            set(intersection_by_zone.keys())
            | set(sugarcane_available_area_by_zone.keys())
        )

        for zone in all_zones:

            intersection_pixels = intersection_by_zone.get(
                zone, {}
            ).get("intersection_pixels", 0)

            intersection_area_km2 = intersection_by_zone.get(
                zone, {}
            ).get("intersection_area_km2", 0)

            sugarcane_available_area_km2 = (
                sugarcane_available_area_by_zone.get(zone)
            )

            if (
                sugarcane_available_area_km2 is not None
                and sugarcane_available_area_km2 > 0
            ):
                intersection_pct_of_sugarcane_area = (
                    intersection_area_km2
                    / sugarcane_available_area_km2
                    * 100
                )
            else:
                intersection_pct_of_sugarcane_area = None

            row = {
                "scenario": scenario,
                "sugarcane_potential": sugarcane_potential,
                "soybean_potential": "unique_high_medium_low",
                "zone": zone,
                "intersection_pixels": round(intersection_pixels, 6),
                "intersection_area_km2": round(intersection_area_km2, 6),
                "sugarcane_available_area_km2_yaml": (
                    round(sugarcane_available_area_km2, 6)
                    if sugarcane_available_area_km2 is not None
                    else None
                ),
                "intersection_pct_of_sugarcane_available_area": (
                    round(intersection_pct_of_sugarcane_area, 6)
                    if intersection_pct_of_sugarcane_area is not None
                    else None
                ),
                "soybean_unique_raster": soybean_unique_raster_path,
                "intersection_raster": intersection_raster_path,
                "yaml_file": yaml_path
            }

            all_rows.append(row)


# ============================================================
# EXPORT FINAL CSV
# ============================================================

fieldnames = [
    "scenario",
    "sugarcane_potential",
    "soybean_potential",
    "zone",
    "intersection_pixels",
    "intersection_area_km2",
    "sugarcane_available_area_km2_yaml",
    "intersection_pct_of_sugarcane_available_area",
    "soybean_unique_raster",
    "intersection_raster",
    "yaml_file"
]

with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(all_rows)

print("\n" + "=" * 90)
print("PROCESS FINISHED SUCCESSFULLY")
print("=" * 90)
print(f"Soybean unique rasters and intersection rasters saved in:\n{OUTPUT_RASTERS_DIR}")
print(f"Final CSV saved at:\n{OUTPUT_CSV}")
print(f"Total rows written: {len(all_rows)}")