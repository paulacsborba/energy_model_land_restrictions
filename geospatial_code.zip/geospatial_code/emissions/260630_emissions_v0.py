# =============================================================================
# dLUC EMISSIONS FROM FINAL DOWNSCALED ALLOCATIONS
# QGIS Python Editor / QGIS Python Console
#
# Corrected version:
#   - Does NOT use ogr.wkbFlatten
#   - Uses manually converted biome GeoPackage
#   - Forces source biome coordinates as EPSG:5880
#   - Uses NOM_BIOMA field
#   - Includes scenario_epe
#   - Exports weighted mean origin-stock validation by scenario
#   - Allows an optional Forest formation / Cerrado override
# =============================================================================

import os
import re
import glob
import csv
import math
import hashlib
from collections import defaultdict
from datetime import datetime
from xml.etree import ElementTree as ET
from zipfile import ZipFile

import numpy as np
from osgeo import gdal, ogr, osr

gdal.UseExceptions()


# =============================================================================
# 1. USER SETTINGS
# =============================================================================

BASE_DIR = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"

INTEGRATION_DIR = os.path.join(
    BASE_DIR,
    "geospatial_data",
    "integration",
)

FACTOR_WORKBOOK_XLSX = os.path.join(
    BASE_DIR,
    "fatores_emissao_lulc_combustiveis_iluc.xlsx",
)

MAPBIOMAS_LANDUSE_RASTER = os.path.join(
    BASE_DIR,
    "geospatial_data",
    "rasters",
    "landuse",
    "br_mapbiomes_250m_5880.tif",
)

PASTURE_VIGOR_RASTER = (
    r"C:\Users\pcsbo\OneDrive\PostDoc\NZB\mapping\biofuel"
    r"\supply_curve\sugarcane\reproject_pasture_vigor_250m.tif"
)

# GeoPackage manually converted to EPSG:5880.
BIOMES_GPKG = os.path.join(
    BASE_DIR,
    "geospatial_data",
    "shapefiles",
    "biomes",
    "biomes5580.gpkg",
)

BIOME_LAYER_NAME = "biomas5000"
BIOME_FIELD = "NOM_BIOMA"

# The GeoPackage does not expose a recognized EPSG authority to GDAL.
# Its geometry coordinates are manually interpreted as EPSG:5880.
BIOME_CRS_OVERRIDE = "EPSG:5880"

SCENARIOS = [
    "scenario_epe",
    "baseline",
    "conservation",
    "governance",
    "degraded_pastures",
    "integrated",
]

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "dLUC_emissions_final_allocations",
)

CACHE_DIR = os.path.join(
    OUTPUT_DIR,
    "_aligned_reference_cache",
)

BLOCK_SIZE = 512
OUTPUT_NODATA = -9999.0
DLUC_AMORTIZATION_YEARS = 20.0

USE_REPORTED_PASTURE_WHEN_VIGOR_UNKNOWN = True
STRICT_FACTOR_COVERAGE = False
FAIL_IF_SUGARCANE_SOYBEAN_OVERLAP = True

# Validation references supplied by you.
SCENARIO_WEIGHTED_MEAN_ORIGIN_STOCK_REFERENCE = {
    "scenario_epe": 270.53,
    "baseline": 268.20,
    "conservation": 262.87,
    "governance": 278.48,
    "degraded_pastures": 278.96,
    "integrated": 298.20,
}

# Leave as None to use the workbook factor.
# Replace with a value in tCO2e/ha when you define the final Cerrado factor.
CERRADO_FOREST_FORMATION_ORIGIN_STOCK_OVERRIDE_TCO2E_PER_HA = None

# Example:
# CERRADO_FOREST_FORMATION_ORIGIN_STOCK_OVERRIDE_TCO2E_PER_HA = 325.40

MANUAL_ALLOCATION_RASTERS = {
    # "scenario_epe": {
    #     "sugarcane": r"C:\path\to\chosen_sugarcane_raster.tif",
    # },
}


# =============================================================================
# 2. DEFINITIONS
# =============================================================================

DESTINATION_MAPBIOMAS_CLASSES = {
    "sugarcane": {20, 39, 40, 41, 62},
    "soybean": {20, 39, 40, 41, 62},
}

DESTINATION_PREFERRED_CLASS = {
    "sugarcane": 20,
    "soybean": 39,
}

MAPBIOMAS_CLASS_NAME = {
    1: "Forest",
    3: "Forest formation",
    4: "Savanna formation",
    5: "Mangrove",
    6: "Flooded forest",
    9: "Forest plantation",
    10: "Herbaceous and shrub vegetation",
    11: "Wetland",
    12: "Grassland",
    13: "Other non-forest natural formation",
    14: "Farming",
    15: "Pasture",
    18: "Agriculture",
    19: "Temporary crops",
    20: "Sugarcane",
    21: "Mosaic agriculture-pasture",
    22: "Non-vegetated area",
    23: "Beach dune sand",
    24: "Urban area",
    25: "Other non-vegetated area",
    26: "Water",
    27: "Non-observed",
    29: "Rocky outcrop",
    30: "Mining",
    31: "Aquaculture",
    32: "Salt flat",
    33: "River, lake and ocean",
    35: "Palm oil",
    36: "Perennial crops",
    39: "Soybean",
    40: "Rice",
    41: "Other temporary crops",
    46: "Coffee",
    47: "Citrus",
    48: "Other perennial crops",
    49: "Wooded sandbank vegetation",
    50: "Herbaceous sandbank vegetation",
    62: "Cotton",
}

PASTURE_VIGOR_LABEL = {
    1: "low_vigor_degraded",
    2: "medium_vigor_nominal",
    3: "high_vigor_improved",
}

BIOME_NAME_TO_CODE = {
    "Amazônia": 1,
    "Cerrado": 2,
    "Caatinga": 3,
    "Mata Atlântica": 4,
    "Pampa": 5,
    "Pantanal": 6,
}

BIOME_CODE_TO_NAME = {
    code: biome
    for biome, code in BIOME_NAME_TO_CODE.items()
}


# =============================================================================
# 3. BASIC HELPERS
# =============================================================================

def ensure_dir(folder):
    os.makedirs(folder, exist_ok=True)


def set_axis_mapping(srs):
    if srs is not None and hasattr(srs, "SetAxisMappingStrategy"):
        srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)


def normalize_text(value):
    if value is None:
        return ""

    text = str(value).strip().lower()

    substitutions = {
        "á": "a", "à": "a", "â": "a", "ã": "a",
        "é": "e", "ê": "e",
        "í": "i",
        "ó": "o", "ô": "o", "õ": "o",
        "ú": "u", "ü": "u",
        "ç": "c",
    }

    for old, new in substitutions.items():
        text = text.replace(old, new)

    return re.sub(r"[\s_\-]+", " ", text).strip()


def normalize_key(value):
    text = normalize_text(value)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def canonical_biome(value):
    cleaned = normalize_text(value)

    aliases = {
        "amazonia": "Amazônia",
        "amazon": "Amazônia",
        "cerrado": "Cerrado",
        "caatinga": "Caatinga",
        "mata atlantica": "Mata Atlântica",
        "atlantic forest": "Mata Atlântica",
        "pampa": "Pampa",
        "pantanal": "Pantanal",
    }

    ignored = {
        "",
        "water",
        "agua",
        "ocean",
        "oceano",
        "mar",
        "marinho",
        "sistema costeiro marinho",
        "costeiro marinho",
        "ilhas oceanicas",
        "ilhas oceanicas e costeiras",
    }

    if cleaned in ignored:
        return None

    if cleaned not in aliases:
        raise ValueError(
            "\nBiome name was not recognized:"
            f"\n  Raw value: '{value}'"
            "\n\nUpdate canonical_biome() if this is terrestrial."
        )

    return aliases[cleaned]


def to_float(value, default=None):
    if value is None:
        return default

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)

    text = str(value).strip()

    if not text:
        return default

    try:
        return float(text)
    except ValueError:
        pass

    try:
        if "," in text and "." in text:
            if text.rfind(",") > text.rfind("."):
                text = text.replace(".", "").replace(",", ".")
            else:
                text = text.replace(",", "")
        elif "," in text:
            text = text.replace(",", ".")

        return float(text)

    except ValueError:
        return default


def parse_mapbiomas_codes(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return {int(round(float(value)))}

    codes = set()

    for token in re.findall(r"\d+(?:\.\d+)?", str(value or "")):
        number = float(token)

        if math.isclose(number, round(number)):
            codes.add(int(round(number)))

    return codes


def safe_remove_file(path):
    if not os.path.exists(path):
        return path

    try:
        os.remove(path)
        return path

    except Exception:
        root, extension = os.path.splitext(path)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        fallback = f"{root}_{timestamp}{extension}"

        print("\nWARNING: Existing file is locked.")
        print(f"Using fallback file:\n{fallback}")

        return fallback


def safe_remove_raster_family(path):
    files = [
        path,
        path + ".aux.xml",
        path + ".ovr",
        path + ".msk",
    ]

    locked = False

    for item in files:
        if os.path.exists(item):
            try:
                os.remove(item)
            except Exception:
                locked = True

    if not locked:
        return path

    root, extension = os.path.splitext(path)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    fallback = f"{root}_{timestamp}{extension}"

    print("\nWARNING: Raster file is locked.")
    print(f"Using fallback raster:\n{fallback}")

    return fallback


def write_csv(path, fieldnames, rows):
    ensure_dir(os.path.dirname(path))
    path = safe_remove_file(path)

    with open(path, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)

    print("\nCSV written:")
    print(path)

    return path


def open_raster(path, label):
    dataset = gdal.Open(path, gdal.GA_ReadOnly)

    if dataset is None:
        raise FileNotFoundError(
            f"\nCould not open {label}:\n{path}"
        )

    return dataset


def pixel_area_ha(reference_ds):
    gt = reference_ds.GetGeoTransform()

    area_m2 = abs(
        gt[1] * gt[5]
        - gt[2] * gt[4]
    )

    if area_m2 <= 0:
        raise RuntimeError("Could not calculate pixel area.")

    return area_m2 / 10_000.0


def valid_data_mask(array, nodata):
    mask = np.isfinite(array)

    if nodata is not None:
        mask &= array != nodata

    mask &= array != OUTPUT_NODATA

    return mask


def valid_positive_mask(array, nodata):
    mask = valid_data_mask(array, nodata)
    mask &= array > 0
    return mask


def grid_signature(reference_ds):
    text = (
        f"{reference_ds.RasterXSize}|"
        f"{reference_ds.RasterYSize}|"
        f"{reference_ds.GetGeoTransform()}|"
        f"{reference_ds.GetProjection()}"
    )

    return hashlib.sha1(
        text.encode("utf-8")
    ).hexdigest()[:16]


def grids_are_equal(reference_ds, other_ds, tolerance=1e-9):
    if reference_ds.RasterXSize != other_ds.RasterXSize:
        return False

    if reference_ds.RasterYSize != other_ds.RasterYSize:
        return False

    for a, b in zip(
        reference_ds.GetGeoTransform(),
        other_ds.GetGeoTransform(),
    ):
        if abs(a - b) > tolerance:
            return False

    return reference_ds.GetProjection() == other_ds.GetProjection()


# =============================================================================
# 4. XLSX READER WITHOUT OPENPYXL
# =============================================================================

def column_index_from_ref(cell_ref):
    letters = re.sub(r"\d", "", cell_ref)
    result = 0

    for char in letters:
        result = result * 26 + (
            ord(char.upper()) - ord("A") + 1
        )

    return result - 1


def read_xlsx_sheet_rows(xlsx_path, desired_sheet_name):
    ns_main = (
        "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    )

    ns_rel = (
        "http://schemas.openxmlformats.org/"
        "officeDocument/2006/relationships"
    )

    ns_pkg_rel = (
        "http://schemas.openxmlformats.org/"
        "package/2006/relationships"
    )

    with ZipFile(xlsx_path) as archive:
        workbook_root = ET.fromstring(
            archive.read("xl/workbook.xml")
        )

        rels_root = ET.fromstring(
            archive.read("xl/_rels/workbook.xml.rels")
        )

        relation_targets = {}

        for relationship in rels_root.findall(
            f"{{{ns_pkg_rel}}}Relationship"
        ):
            target = relationship.attrib["Target"]

            if target.startswith("/"):
                target = target.lstrip("/")
            elif not target.startswith("xl/"):
                target = "xl/" + target.lstrip("/")

            relation_targets[
                relationship.attrib["Id"]
            ] = target

        sheet_path = None

        sheets = workbook_root.find(
            f"{{{ns_main}}}sheets"
        )

        for sheet in sheets:
            if sheet.attrib.get("name") == desired_sheet_name:
                relation_id = sheet.attrib.get(
                    f"{{{ns_rel}}}id"
                )
                sheet_path = relation_targets.get(
                    relation_id
                )
                break

        if sheet_path is None:
            raise ValueError(
                f"\nWorksheet '{desired_sheet_name}' was not found in:"
                f"\n{xlsx_path}"
            )

        shared_strings = []

        if "xl/sharedStrings.xml" in archive.namelist():
            shared_root = ET.fromstring(
                archive.read("xl/sharedStrings.xml")
            )

            for item in shared_root.findall(
                f"{{{ns_main}}}si"
            ):
                shared_strings.append(
                    "".join(
                        node.text or ""
                        for node in item.iter(
                            f"{{{ns_main}}}t"
                        )
                    )
                )

        sheet_root = ET.fromstring(
            archive.read(sheet_path)
        )

        table = []

        for row_node in sheet_root.findall(
            f".//{{{ns_main}}}sheetData/{{{ns_main}}}row"
        ):
            cells = {}

            for cell in row_node.findall(
                f"{{{ns_main}}}c"
            ):
                index = column_index_from_ref(
                    cell.attrib.get("r", "A1")
                )

                cell_type = cell.attrib.get("t")
                value_node = cell.find(
                    f"{{{ns_main}}}v"
                )

                if cell_type == "inlineStr":
                    inline_node = cell.find(
                        f"{{{ns_main}}}is"
                    )

                    value = (
                        "".join(
                            node.text or ""
                            for node in inline_node.iter(
                                f"{{{ns_main}}}t"
                            )
                        )
                        if inline_node is not None
                        else ""
                    )

                elif value_node is None:
                    value = ""

                else:
                    raw_value = value_node.text or ""

                    if cell_type == "s":
                        value = shared_strings[
                            int(raw_value)
                        ]
                    else:
                        numeric = to_float(
                            raw_value,
                            default=None,
                        )

                        value = (
                            numeric
                            if numeric is not None
                            else raw_value
                        )

                cells[index] = value

            if cells:
                table.append([
                    cells.get(i, "")
                    for i in range(max(cells) + 1)
                ])

    if not table:
        return []

    header_index = None

    for index, row in enumerate(table):
        normalized = {
            normalize_key(value)
            for value in row
            if str(value).strip()
        }

        if (
            "biome" in normalized
            and "mapbiomas_class" in normalized
        ):
            header_index = index
            break

    if header_index is None:
        raise ValueError(
            "\nCould not identify a header row in worksheet "
            f"'{desired_sheet_name}'."
        )

    headers = [
        normalize_key(value)
        for value in table[header_index]
    ]

    output = []

    for row in table[header_index + 1:]:
        padded = row + [""] * max(
            0,
            len(headers) - len(row),
        )

        record = {
            headers[i]: padded[i]
            for i in range(len(headers))
            if headers[i]
        }

        if any(
            str(value).strip()
            for value in record.values()
        ):
            output.append(record)

    return output


# =============================================================================
# 5. FACTOR LOADING
# =============================================================================

def load_lulc_factors():
    rows = read_xlsx_sheet_rows(
        FACTOR_WORKBOOK_XLSX,
        "LULC_carbon_factors",
    )

    factors = []

    for row in rows:
        biome_raw = row.get("biome")

        mapbiomas_classes = parse_mapbiomas_codes(
            row.get("mapbiomas_class")
        )

        stock_tco2e = to_float(
            row.get("stock_tco2e_per_ha"),
            default=None,
        )

        if stock_tco2e is None:
            stock_tc = to_float(
                row.get("stock_tc_per_ha"),
                default=None,
            )

            if stock_tc is not None:
                stock_tco2e = stock_tc * 44.0 / 12.0

        if (
            not biome_raw
            or not mapbiomas_classes
            or stock_tco2e is None
        ):
            continue

        biome = canonical_biome(biome_raw)

        if biome is None:
            continue

        factors.append({
            "biome": biome,
            "mapbiomas_classes": mapbiomas_classes,
            "land_use_group": normalize_text(
                row.get("land_use_group")
            ),
            "pasture_condition": normalize_text(
                row.get("pasture_condition")
            ),
            "stock_tco2e_per_ha": float(stock_tco2e),
            "source_url": str(
                row.get("source_url", "")
            ),
            "notes": str(
                row.get("notes", "")
            ),
        })

    if not factors:
        raise RuntimeError(
            "\nNo valid carbon factors were read from "
            "'LULC_carbon_factors'."
        )

    print(f"\nCarbon factors loaded: {len(factors)}")

    return factors


def manual_origin_override(biome, mapbiomas_class):
    if (
        biome == "Cerrado"
        and mapbiomas_class == 3
        and CERRADO_FOREST_FORMATION_ORIGIN_STOCK_OVERRIDE_TCO2E_PER_HA
        is not None
    ):
        return {
            "biome": biome,
            "mapbiomas_classes": {3},
            "land_use_group": "manual override",
            "pasture_condition": "",
            "stock_tco2e_per_ha": float(
                CERRADO_FOREST_FORMATION_ORIGIN_STOCK_OVERRIDE_TCO2E_PER_HA
            ),
            "source_url": "Manual Cerrado Forest Formation override",
            "notes": (
                "Manual override defined in "
                "CERRADO_FOREST_FORMATION_ORIGIN_STOCK_OVERRIDE_TCO2E_PER_HA"
            ),
        }

    return None


def pick_origin_factor(
    factors,
    biome,
    mapbiomas_class,
    pasture_vigor,
):
    override = manual_origin_override(
        biome,
        mapbiomas_class,
    )

    if override is not None:
        return override

    candidates = [
        factor
        for factor in factors
        if factor["biome"] == biome
        and mapbiomas_class in factor["mapbiomas_classes"]
    ]

    if not candidates:
        return None

    if mapbiomas_class == 15:
        preferred_condition = {
            1: "pasture low vigor degraded",
            2: "pasture medium vigor nominal",
            3: "pasture high vigor improved",
        }.get(pasture_vigor)

        if preferred_condition:
            exact = [
                factor
                for factor in candidates
                if factor["pasture_condition"]
                == preferred_condition
            ]

            if exact:
                return exact[0]

        if USE_REPORTED_PASTURE_WHEN_VIGOR_UNKNOWN:
            fallback = [
                factor
                for factor in candidates
                if (
                    factor["land_use_group"] == "reported land use"
                    or factor["pasture_condition"] in {"", "na", "n a"}
                )
            ]

            if fallback:
                return fallback[0]

        return None

    non_pasture = [
        factor
        for factor in candidates
        if factor["land_use_group"] != "pasture type"
    ]

    return non_pasture[0] if non_pasture else None


def pick_destination_factor(factors, biome, feedstock):
    target_classes = DESTINATION_MAPBIOMAS_CLASSES[
        feedstock
    ]

    candidates = [
        factor
        for factor in factors
        if factor["biome"] == biome
        and factor["land_use_group"] != "pasture type"
        and bool(
            factor["mapbiomas_classes"].intersection(
                target_classes
            )
        )
    ]

    if not candidates:
        return None

    preferred_class = DESTINATION_PREFERRED_CLASS[
        feedstock
    ]

    preferred = [
        factor
        for factor in candidates
        if preferred_class in factor["mapbiomas_classes"]
    ]

    return preferred[0] if preferred else candidates[0]


# =============================================================================
# 6. FINAL ALLOCATION DISCOVERY
# =============================================================================

def choose_latest_file(paths):
    paths = sorted(set(paths))

    if not paths:
        return None

    return max(paths, key=os.path.getmtime)


def clean_candidates(paths, scenario, feedstock):
    excluded_tokens = [
        "score_total",
        "summary",
        "selected_pixels",
        "used_for",
        "sourceclass",
        "source_class",
        "available",
        "mask",
        "locked",
        "lock_",
    ]

    selected = []

    for path in sorted(set(paths)):
        filename_lower = os.path.basename(path).lower()
        path_lower = path.lower()

        if scenario.lower() not in path_lower:
            continue

        if feedstock.lower() not in filename_lower:
            continue

        if "chosen" not in filename_lower:
            continue

        if any(
            token in filename_lower
            for token in excluded_tokens
        ):
            continue

        selected.append(path)

    return selected


def recursive_candidates(scenario, feedstock):
    pattern = os.path.join(
        INTEGRATION_DIR,
        "**",
        f"*{feedstock}*chosen*.tif",
    )

    matches = glob.glob(
        pattern,
        recursive=True,
    )

    return clean_candidates(
        matches,
        scenario,
        feedstock,
    )


def find_sugarcane_raster(scenario):
    manual = (
        MANUAL_ALLOCATION_RASTERS
        .get(scenario, {})
        .get("sugarcane")
    )

    if manual:
        if not os.path.exists(manual):
            raise FileNotFoundError(
                f"\nManual sugarcane raster not found:\n{manual}"
            )

        return manual

    candidates = recursive_candidates(
        scenario,
        "sugarcane",
    )

    print("\nSugarcane candidates:")

    if candidates:
        for path in candidates:
            print(f"  {path}")
    else:
        print("  None found.")

    potential_class = [
        path
        for path in candidates
        if "potential_class"
        in os.path.basename(path).lower()
    ]

    binary = [
        path
        for path in candidates
        if "binary"
        in os.path.basename(path).lower()
    ]

    selected = (
        choose_latest_file(potential_class)
        or choose_latest_file(binary)
        or choose_latest_file(candidates)
    )

    print("\nSugarcane raster selected:")
    print(selected)

    return selected


def find_soybean_raster(scenario):
    if scenario == "scenario_epe":
        print("\nSoybean allocation is not expected for scenario_epe.")
        return None

    manual = (
        MANUAL_ALLOCATION_RASTERS
        .get(scenario, {})
        .get("soybean")
    )

    if manual:
        if not os.path.exists(manual):
            raise FileNotFoundError(
                f"\nManual soybean raster not found:\n{manual}"
            )

        return manual

    candidates = recursive_candidates(
        scenario,
        "soybean",
    )

    print("\nSoybean candidates:")

    if candidates:
        for path in candidates:
            print(f"  {path}")
    else:
        print("  None found.")

    after_sugarcane = [
        path
        for path in candidates
        if "after_sugarcane"
        in os.path.basename(path).lower()
    ]

    binary = [
        path
        for path in (
            after_sugarcane
            if after_sugarcane
            else candidates
        )
        if "binary"
        in os.path.basename(path).lower()
    ]

    selected = (
        choose_latest_file(binary)
        or choose_latest_file(after_sugarcane)
        or choose_latest_file(candidates)
    )

    print("\nSoybean raster selected:")
    print(selected)

    return selected


# =============================================================================
# 7. ALIGNMENT FUNCTIONS
# =============================================================================

def align_raster_to_reference(
    input_raster_path,
    reference_ds,
    cache_label,
    output_type,
):
    input_ds = open_raster(
        input_raster_path,
        cache_label,
    )

    if grids_are_equal(reference_ds, input_ds):
        input_ds = None
        return input_raster_path

    ensure_dir(CACHE_DIR)

    signature = grid_signature(reference_ds)

    cache_path = os.path.join(
        CACHE_DIR,
        f"{cache_label}_{signature}.tif",
    )

    if os.path.exists(cache_path):
        cached_ds = gdal.Open(
            cache_path,
            gdal.GA_ReadOnly,
        )

        if (
            cached_ds is not None
            and grids_are_equal(reference_ds, cached_ds)
        ):
            cached_ds = None
            input_ds = None

            print(f"\nUsing cached aligned raster:\n{cache_path}")
            return cache_path

        cached_ds = None

    gt = reference_ds.GetGeoTransform()

    xmin = gt[0]
    ymax = gt[3]

    xmax = xmin + reference_ds.RasterXSize * gt[1]
    ymin = ymax + reference_ds.RasterYSize * gt[5]

    source_nodata = input_ds.GetRasterBand(1).GetNoDataValue()

    cache_path = safe_remove_raster_family(
        cache_path
    )

    warp_kwargs = {
        "format": "GTiff",
        "outputBounds": (xmin, ymin, xmax, ymax),
        "width": reference_ds.RasterXSize,
        "height": reference_ds.RasterYSize,
        "dstSRS": reference_ds.GetProjection(),
        "resampleAlg": "near",
        "outputType": output_type,
        "dstNodata": OUTPUT_NODATA,
        "multithread": True,
        "creationOptions": [
            "COMPRESS=LZW",
            "BIGTIFF=IF_SAFER",
        ],
    }

    if source_nodata is not None:
        warp_kwargs["srcNodata"] = source_nodata

    print(f"\nAligning {cache_label}...")

    aligned_ds = gdal.Warp(
        cache_path,
        input_ds,
        options=gdal.WarpOptions(
            **warp_kwargs
        ),
    )

    if aligned_ds is None:
        raise RuntimeError(
            f"\nCould not align raster:\n{input_raster_path}"
        )

    aligned_ds.FlushCache()

    aligned_ds = None
    input_ds = None

    print(f"Aligned raster written:\n{cache_path}")

    return cache_path


# =============================================================================
# 8. BIOME GEOPACKAGE FUNCTIONS
# =============================================================================

def get_field_name_case_insensitive(layer, requested_name):
    layer_defn = layer.GetLayerDefn()

    fields = [
        layer_defn.GetFieldDefn(i).GetName()
        for i in range(layer_defn.GetFieldCount())
    ]

    for field_name in fields:
        if field_name.lower() == requested_name.lower():
            return field_name

    raise ValueError(
        f"\nBiome field '{requested_name}' was not found."
        f"\nAvailable fields: {fields}"
    )


def create_srs_from_user_input(crs_text):
    srs = osr.SpatialReference()

    result = srs.SetFromUserInput(crs_text)

    if result != 0:
        raise RuntimeError(
            f"\nCould not interpret CRS:\n{crs_text}"
        )

    set_axis_mapping(srs)

    return srs


def repair_geometry(geometry):
    if geometry is None:
        return None, False

    repaired = False

    try:
        is_valid = geometry.IsValid()
    except Exception:
        is_valid = False

    if is_valid:
        return geometry, repaired

    if hasattr(geometry, "MakeValid"):
        try:
            geometry = geometry.MakeValid()
            repaired = True
            return geometry, repaired
        except Exception:
            pass

    try:
        geometry = geometry.Buffer(0)
        repaired = True
        return geometry, repaired
    except Exception:
        return None, repaired


def extract_polygonal_geometry(geometry):
    """
    Extract Polygon/MultiPolygon components without ogr.wkbFlatten.
    Compatible with older QGIS/GDAL distributions.
    """

    if geometry is None or geometry.IsEmpty():
        return None

    geometry_name = (
        geometry.GetGeometryName() or ""
    ).upper().replace(" ", "")

    # Works for POLYGON, POLYGONZ and POLYGONM.
    if geometry_name.startswith("POLYGON"):
        output = ogr.Geometry(ogr.wkbMultiPolygon)
        output.AddGeometry(geometry.Clone())
        return output

    # Works for MULTIPOLYGON, MULTIPOLYGONZ and MULTIPOLYGONM.
    if geometry_name.startswith("MULTIPOLYGON"):
        return geometry.Clone()

    # Geometry collections, multi-surfaces and similar container geometries.
    output = ogr.Geometry(ogr.wkbMultiPolygon)

    geometry_count = geometry.GetGeometryCount()

    for index in range(geometry_count):
        child = geometry.GetGeometryRef(index)

        if child is None:
            continue

        child_polygonal = extract_polygonal_geometry(
            child
        )

        if child_polygonal is None:
            continue

        child_name = (
            child_polygonal.GetGeometryName() or ""
        ).upper().replace(" ", "")

        if child_name.startswith("POLYGON"):
            output.AddGeometry(child_polygonal.Clone())

        elif child_name.startswith("MULTIPOLYGON"):
            for part_index in range(
                child_polygonal.GetGeometryCount()
            ):
                polygon_part = child_polygonal.GetGeometryRef(
                    part_index
                )

                if polygon_part is not None:
                    output.AddGeometry(
                        polygon_part.Clone()
                    )

    if output.GetGeometryCount() == 0:
        return None

    return output


def create_biome_memory_layer_for_reference(reference_ds):
    if not os.path.exists(BIOMES_GPKG):
        raise FileNotFoundError(
            f"\nBiome GeoPackage not found:\n{BIOMES_GPKG}"
        )

    vector_ds = ogr.Open(
        BIOMES_GPKG,
        0,
    )

    if vector_ds is None:
        raise RuntimeError(
            f"\nCould not open GeoPackage:\n{BIOMES_GPKG}"
        )

    source_layer = vector_ds.GetLayerByName(
        BIOME_LAYER_NAME
    )

    if source_layer is None:
        available_layers = [
            vector_ds.GetLayerByIndex(i).GetName()
            for i in range(vector_ds.GetLayerCount())
        ]

        raise ValueError(
            f"\nLayer '{BIOME_LAYER_NAME}' was not found."
            f"\nAvailable layers: {available_layers}"
        )

    resolved_biome_field = get_field_name_case_insensitive(
        source_layer,
        BIOME_FIELD,
    )

    target_srs = osr.SpatialReference()
    target_srs.ImportFromWkt(
        reference_ds.GetProjection()
    )

    set_axis_mapping(target_srs)

    source_srs = create_srs_from_user_input(
        BIOME_CRS_OVERRIDE
    )

    # If both are EPSG:5880, no coordinate operation is needed.
    try:
        same_crs = source_srs.IsSame(target_srs)
    except Exception:
        same_crs = False

    coordinate_transform = None

    if not same_crs:
        coordinate_transform = osr.CoordinateTransformation(
            source_srs,
            target_srs,
        )

    memory_ds = ogr.GetDriverByName(
        "Memory"
    ).CreateDataSource(
        "biomes_memory"
    )

    memory_layer = memory_ds.CreateLayer(
        "biomes_memory",
        srs=target_srs,
        geom_type=ogr.wkbMultiPolygon,
    )

    memory_layer.CreateField(
        ogr.FieldDefn(
            "BIOME_ID",
            ogr.OFTInteger,
        )
    )

    biome_name_field = ogr.FieldDefn(
        "BIOME_NAME",
        ogr.OFTString,
    )

    biome_name_field.SetWidth(100)

    memory_layer.CreateField(
        biome_name_field
    )

    biome_name_to_id = {}
    biome_id_to_name = {}

    next_biome_id = 1
    audit_rows = []

    source_layer.ResetReading()

    for feature in source_layer:
        source_fid = feature.GetFID()

        raw_biome_name = str(
            feature.GetField(
                resolved_biome_field
            )
        ).strip()

        biome = canonical_biome(
            raw_biome_name
        )

        if biome is None:
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": "",
                "status": "excluded_non_terrestrial",
            })
            continue

        if biome not in biome_name_to_id:
            biome_name_to_id[biome] = next_biome_id
            biome_id_to_name[next_biome_id] = biome
            next_biome_id += 1

        biome_id = biome_name_to_id[biome]

        source_geometry = feature.GetGeometryRef()

        if source_geometry is None:
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": biome,
                "status": "skipped_no_geometry",
            })
            continue

        geometry = source_geometry.Clone()

        geometry, repaired_before = repair_geometry(
            geometry
        )

        if geometry is None:
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": biome,
                "status": "skipped_repair_failed",
            })
            continue

        geometry = extract_polygonal_geometry(
            geometry
        )

        if geometry is None or geometry.IsEmpty():
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": biome,
                "status": "skipped_non_polygonal_or_empty",
            })
            continue

        if coordinate_transform is not None:
            try:
                transform_result = geometry.Transform(
                    coordinate_transform
                )
            except Exception:
                transform_result = 1

            if transform_result != 0:
                audit_rows.append({
                    "source_fid": source_fid,
                    "raw_biome_name": raw_biome_name,
                    "canonical_biome": biome,
                    "status": "skipped_transform_failed",
                })
                continue

        geometry, repaired_after = repair_geometry(
            geometry
        )

        if geometry is None:
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": biome,
                "status": "skipped_invalid_after_transform",
            })
            continue

        geometry = extract_polygonal_geometry(
            geometry
        )

        if geometry is None or geometry.IsEmpty():
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": biome,
                "status": "skipped_empty_after_transform",
            })
            continue

        output_feature = ogr.Feature(
            memory_layer.GetLayerDefn()
        )

        output_feature.SetField(
            "BIOME_ID",
            biome_id,
        )

        output_feature.SetField(
            "BIOME_NAME",
            biome,
        )

        output_feature.SetGeometry(
            geometry
        )

        create_result = memory_layer.CreateFeature(
            output_feature
        )

        output_feature = None
        geometry = None

        if create_result != 0:
            audit_rows.append({
                "source_fid": source_fid,
                "raw_biome_name": raw_biome_name,
                "canonical_biome": biome,
                "status": "skipped_memory_write_failed",
            })
            continue

        audit_rows.append({
            "source_fid": source_fid,
            "raw_biome_name": raw_biome_name,
            "canonical_biome": biome,
            "status": (
                "repaired_and_kept"
                if repaired_before or repaired_after
                else "kept"
            ),
        })

    vector_ds = None

    return (
        memory_ds,
        memory_layer,
        biome_id_to_name,
        audit_rows,
    )


def rasterize_biomes_to_reference(reference_ds):
    ensure_dir(CACHE_DIR)

    grid_id = grid_signature(reference_ds)
    biome_mtime = int(os.path.getmtime(BIOMES_GPKG))

    cache_path = os.path.join(
        CACHE_DIR,
        f"biomes_epsg5880_{biome_mtime}_{grid_id}.tif",
    )

    if os.path.exists(cache_path):
        cached_ds = gdal.Open(
            cache_path,
            gdal.GA_ReadOnly,
        )

        if (
            cached_ds is not None
            and grids_are_equal(reference_ds, cached_ds)
        ):
            cached_ds = None
            return cache_path, []

        cached_ds = None

    (
        biome_memory_ds,
        biome_memory_layer,
        biome_id_to_name,
        audit_rows,
    ) = create_biome_memory_layer_for_reference(
        reference_ds
    )

    cache_path = safe_remove_raster_family(
        cache_path
    )

    output_ds = gdal.GetDriverByName(
        "GTiff"
    ).Create(
        cache_path,
        reference_ds.RasterXSize,
        reference_ds.RasterYSize,
        1,
        gdal.GDT_Int16,
        options=[
            "COMPRESS=LZW",
            "BIGTIFF=IF_SAFER",
        ],
    )

    if output_ds is None:
        raise RuntimeError(
            f"\nCould not create biome raster:\n{cache_path}"
        )

    output_ds.SetGeoTransform(
        reference_ds.GetGeoTransform()
    )

    output_ds.SetProjection(
        reference_ds.GetProjection()
    )

    output_band = output_ds.GetRasterBand(1)

    output_band.Fill(0)
    output_band.SetNoDataValue(0)

    result = gdal.RasterizeLayer(
        output_ds,
        [1],
        biome_memory_layer,
        options=[
            "ATTRIBUTE=BIOME_ID",
            "ALL_TOUCHED=FALSE",
        ],
    )

    if result != 0:
        raise RuntimeError(
            "\nCould not rasterize biome polygons."
        )

    output_band.FlushCache()
    output_ds.FlushCache()

    output_ds = None
    biome_memory_ds = None

    print("\nBiome raster written:")
    print(cache_path)

    return cache_path, audit_rows


# =============================================================================
# 9. OVERLAP CHECK
# =============================================================================

def count_overlap_pixels(
    scenario,
    sugarcane_raster_path,
    soybean_raster_path,
):
    sugarcane_ds = open_raster(
        sugarcane_raster_path,
        "sugarcane allocation raster",
    )

    soybean_aligned_path = align_raster_to_reference(
        soybean_raster_path,
        sugarcane_ds,
        cache_label=f"soybean_overlap_{scenario}",
        output_type=gdal.GDT_Byte,
    )

    soybean_ds = open_raster(
        soybean_aligned_path,
        "soybean allocation raster",
    )

    sugarcane_band = sugarcane_ds.GetRasterBand(1)
    soybean_band = soybean_ds.GetRasterBand(1)

    sugarcane_nodata = sugarcane_band.GetNoDataValue()
    soybean_nodata = soybean_band.GetNoDataValue()

    overlap_pixels = 0

    for y in range(
        0,
        sugarcane_ds.RasterYSize,
        BLOCK_SIZE,
    ):
        ysize = min(
            BLOCK_SIZE,
            sugarcane_ds.RasterYSize - y,
        )

        for x in range(
            0,
            sugarcane_ds.RasterXSize,
            BLOCK_SIZE,
        ):
            xsize = min(
                BLOCK_SIZE,
                sugarcane_ds.RasterXSize - x,
            )

            sugarcane = sugarcane_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            soybean = soybean_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            sugarcane_mask = valid_positive_mask(
                sugarcane,
                sugarcane_nodata,
            )

            soybean_mask = valid_positive_mask(
                soybean,
                soybean_nodata,
            )

            overlap_pixels += int(
                np.sum(
                    sugarcane_mask
                    & soybean_mask
                )
            )

    sugarcane_ds = None
    soybean_ds = None

    return overlap_pixels


# =============================================================================
# 10. SPATIAL CROSS-TAB
# =============================================================================

def process_allocation_raster(
    scenario,
    feedstock,
    allocation_raster_path,
):
    print("\n" + "=" * 90)
    print(f"PROCESSING | {scenario} | {feedstock}")
    print("=" * 90)
    print(allocation_raster_path)

    allocation_ds = open_raster(
        allocation_raster_path,
        "allocation raster",
    )

    allocation_band = allocation_ds.GetRasterBand(1)
    allocation_nodata = allocation_band.GetNoDataValue()

    landuse_path = align_raster_to_reference(
        MAPBIOMAS_LANDUSE_RASTER,
        allocation_ds,
        cache_label="mapbiomas_landuse",
        output_type=gdal.GDT_Int16,
    )

    pasture_path = align_raster_to_reference(
        PASTURE_VIGOR_RASTER,
        allocation_ds,
        cache_label="pasture_vigor",
        output_type=gdal.GDT_Int16,
    )

    biome_path, biome_audit_rows = rasterize_biomes_to_reference(
        allocation_ds
    )

    landuse_ds = open_raster(
        landuse_path,
        "aligned MapBiomas raster",
    )

    pasture_ds = open_raster(
        pasture_path,
        "aligned pasture vigor raster",
    )

    biome_ds = open_raster(
        biome_path,
        "aligned biome raster",
    )

    landuse_band = landuse_ds.GetRasterBand(1)
    pasture_band = pasture_ds.GetRasterBand(1)
    biome_band = biome_ds.GetRasterBand(1)

    landuse_nodata = landuse_band.GetNoDataValue()
    pasture_nodata = pasture_band.GetNoDataValue()
    biome_nodata = biome_band.GetNoDataValue()

    area_ha_per_pixel = pixel_area_ha(
        allocation_ds
    )

    grouped_counts = defaultdict(int)

    diagnostics = {
        "scenario": scenario,
        "feedstock": feedstock,
        "allocation_raster": allocation_raster_path,
        "landuse_raster_used": landuse_path,
        "pasture_raster_used": pasture_path,
        "biome_raster_used": biome_path,
        "pixel_area_ha": area_ha_per_pixel,
        "allocated_pixels_raw": 0,
        "allocated_pixels_with_landuse_and_biome": 0,
        "allocated_pixels_missing_landuse_or_biome": 0,
        "allocated_area_km2_raw": 0.0,
        "allocated_area_km2_with_landuse_and_biome": 0.0,
        "allocated_area_km2_missing_landuse_or_biome": 0.0,
    }

    rows = allocation_ds.RasterYSize
    cols = allocation_ds.RasterXSize

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(
            BLOCK_SIZE,
            rows - y,
        )

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(
                BLOCK_SIZE,
                cols - x,
            )

            allocation = allocation_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            landuse = landuse_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            pasture = pasture_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            biome = biome_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(np.int16)

            allocated = valid_positive_mask(
                allocation,
                allocation_nodata,
            )

            valid_landuse = valid_data_mask(
                landuse,
                landuse_nodata,
            )

            valid_landuse &= landuse > 0

            valid_biome = valid_data_mask(
                biome,
                biome_nodata,
            )

            valid_biome &= biome > 0

            valid = (
                allocated
                & valid_landuse
                & valid_biome
            )

            raw_pixels = int(np.sum(allocated))
            valid_pixels = int(np.sum(valid))

            diagnostics["allocated_pixels_raw"] += raw_pixels

            diagnostics[
                "allocated_pixels_with_landuse_and_biome"
            ] += valid_pixels

            diagnostics[
                "allocated_pixels_missing_landuse_or_biome"
            ] += raw_pixels - valid_pixels

            if not np.any(valid):
                continue

            selected_biome = biome[valid].astype(
                np.int16
            )

            selected_landuse = landuse[valid].astype(
                np.int16
            )

            selected_pasture = pasture[valid].astype(
                np.int16
            )

            selected_vigor = np.zeros(
                selected_landuse.shape,
                dtype=np.int16,
            )

            pasture_pixels = selected_landuse == 15

            selected_vigor[
                pasture_pixels
            ] = selected_pasture[
                pasture_pixels
            ]

            selected_vigor[
                ~np.isin(
                    selected_vigor,
                    [1, 2, 3],
                )
            ] = 0

            combinations = np.column_stack((
                selected_biome,
                selected_landuse,
                selected_vigor,
            ))

            unique_rows, counts = np.unique(
                combinations,
                axis=0,
                return_counts=True,
            )

            for (
                biome_code,
                mapbiomas_class,
                pasture_vigor,
            ), count in zip(
                unique_rows,
                counts,
            ):
                grouped_counts[
                    (
                        scenario,
                        feedstock,
                        int(biome_code),
                        int(mapbiomas_class),
                        int(pasture_vigor),
                    )
                ] += int(count)

        print(
            f"Rows processed: "
            f"{min(y + BLOCK_SIZE, rows):,} / {rows:,}"
        )

    diagnostics["allocated_area_km2_raw"] = (
        diagnostics["allocated_pixels_raw"]
        * area_ha_per_pixel
        / 100.0
    )

    diagnostics[
        "allocated_area_km2_with_landuse_and_biome"
    ] = (
        diagnostics[
            "allocated_pixels_with_landuse_and_biome"
        ]
        * area_ha_per_pixel
        / 100.0
    )

    diagnostics[
        "allocated_area_km2_missing_landuse_or_biome"
    ] = (
        diagnostics[
            "allocated_pixels_missing_landuse_or_biome"
        ]
        * area_ha_per_pixel
        / 100.0
    )

    allocation_ds = None
    landuse_ds = None
    pasture_ds = None
    biome_ds = None

    return (
        grouped_counts,
        area_ha_per_pixel,
        diagnostics,
        biome_audit_rows,
    )


# =============================================================================
# 11. dLUC CALCULATION
# =============================================================================

def make_dluc_detail_rows(
    grouped_counts,
    area_ha_per_pixel,
    factors,
):
    detail_rows = []
    missing_rows = []

    for (
        scenario,
        feedstock,
        biome_code,
        mapbiomas_class,
        pasture_vigor,
    ), pixel_count in sorted(grouped_counts.items()):
        biome = BIOME_CODE_TO_NAME.get(
            biome_code
        )

        area_ha = pixel_count * area_ha_per_pixel
        area_km2 = area_ha / 100.0

        pasture_vigor_for_factor = (
            pasture_vigor
            if (
                mapbiomas_class == 15
                and pasture_vigor in {1, 2, 3}
            )
            else None
        )

        origin = (
            pick_origin_factor(
                factors,
                biome,
                mapbiomas_class,
                pasture_vigor_for_factor,
            )
            if biome
            else None
        )

        destination = (
            pick_destination_factor(
                factors,
                biome,
                feedstock,
            )
            if biome
            else None
        )

        factor_status = "calculated"

        if biome is None:
            factor_status = "unmapped_biome"

        elif origin is None:
            factor_status = "missing_origin_factor"

        elif destination is None:
            factor_status = "missing_destination_factor"

        row = {
            "scenario": scenario,
            "feedstock": feedstock,
            "biome": biome or "",
            "biome_code": biome_code,
            "mapbiomas_class": mapbiomas_class,
            "mapbiomas_class_name": MAPBIOMAS_CLASS_NAME.get(
                mapbiomas_class,
                f"MapBiomas class {mapbiomas_class}",
            ),
            "pasture_vigor_code": (
                pasture_vigor
                if mapbiomas_class == 15
                else ""
            ),
            "pasture_vigor_label": (
                PASTURE_VIGOR_LABEL.get(
                    pasture_vigor,
                    "unknown"
                    if mapbiomas_class == 15
                    else "not_applicable",
                )
            ),
            "allocated_pixels": pixel_count,
            "allocated_area_ha": area_ha,
            "allocated_area_km2": area_km2,
            "origin_stock_tCO2e_per_ha": (
                origin["stock_tco2e_per_ha"]
                if origin
                else ""
            ),
            "destination_stock_tCO2e_per_ha": (
                destination["stock_tco2e_per_ha"]
                if destination
                else ""
            ),
            "origin_factor_available": origin is not None,
            "destination_factor_available": destination is not None,
            "dLUC_stock_change_tCO2e_per_ha": "",
            "dLUC_stock_change_tCO2e": "",
            "dLUC_annualized_tCO2e_per_yr": "",
            "factor_status": factor_status,
            "origin_factor_source": (
                origin["source_url"]
                if origin
                else ""
            ),
            "destination_factor_source": (
                destination["source_url"]
                if destination
                else ""
            ),
            "origin_factor_notes": (
                origin["notes"]
                if origin
                else ""
            ),
            "destination_factor_notes": (
                destination["notes"]
                if destination
                else ""
            ),
            "dLUC_amortization_years": (
                DLUC_AMORTIZATION_YEARS
            ),
        }

        if factor_status == "calculated":
            stock_change_per_ha = (
                origin["stock_tco2e_per_ha"]
                - destination["stock_tco2e_per_ha"]
            )

            stock_change_total = (
                area_ha * stock_change_per_ha
            )

            annualized = (
                stock_change_total
                / DLUC_AMORTIZATION_YEARS
            )

            row[
                "dLUC_stock_change_tCO2e_per_ha"
            ] = stock_change_per_ha

            row[
                "dLUC_stock_change_tCO2e"
            ] = stock_change_total

            row[
                "dLUC_annualized_tCO2e_per_yr"
            ] = annualized

        else:
            missing_rows.append({
                "scenario": scenario,
                "feedstock": feedstock,
                "biome": biome or "",
                "biome_code": biome_code,
                "mapbiomas_class": mapbiomas_class,
                "mapbiomas_class_name": row[
                    "mapbiomas_class_name"
                ],
                "pasture_vigor_code": row[
                    "pasture_vigor_code"
                ],
                "unmapped_area_km2": area_km2,
                "factor_status": factor_status,
                "needed_factor": (
                    "origin carbon stock"
                    if origin is None
                    else "destination crop carbon stock"
                ),
            })

        detail_rows.append(row)

    return detail_rows, missing_rows


# =============================================================================
# 12. SUMMARIES
# =============================================================================

def scenario_sort_key(scenario):
    try:
        return SCENARIOS.index(scenario)
    except ValueError:
        return len(SCENARIOS)


def summarize_dluc_by_biome(detail_rows):
    grouped = defaultdict(lambda: {
        "allocated_area_km2_total": 0.0,
        "allocated_area_km2_with_factor": 0.0,
        "allocated_area_km2_without_factor": 0.0,
        "dLUC_stock_change_tCO2e": 0.0,
        "dLUC_annualized_tCO2e_per_yr": 0.0,
    })

    for row in detail_rows:
        key = (
            row["scenario"],
            row["feedstock"],
            row["biome"],
        )

        area_km2 = float(
            row["allocated_area_km2"]
        )

        grouped[key][
            "allocated_area_km2_total"
        ] += area_km2

        if row["factor_status"] == "calculated":
            grouped[key][
                "allocated_area_km2_with_factor"
            ] += area_km2

            grouped[key][
                "dLUC_stock_change_tCO2e"
            ] += float(
                row["dLUC_stock_change_tCO2e"]
            )

            grouped[key][
                "dLUC_annualized_tCO2e_per_yr"
            ] += float(
                row[
                    "dLUC_annualized_tCO2e_per_yr"
                ]
            )

        else:
            grouped[key][
                "allocated_area_km2_without_factor"
            ] += area_km2

    output = []

    for key, values in sorted(
        grouped.items(),
        key=lambda item: (
            scenario_sort_key(item[0][0]),
            item[0][1],
            item[0][2],
        ),
    ):
        scenario, feedstock, biome = key

        total_area = values[
            "allocated_area_km2_total"
        ]

        output.append({
            "scenario": scenario,
            "feedstock": feedstock,
            "biome": biome,
            "allocated_area_km2_total": total_area,
            "allocated_area_km2_with_factor": values[
                "allocated_area_km2_with_factor"
            ],
            "allocated_area_km2_without_factor": values[
                "allocated_area_km2_without_factor"
            ],
            "factor_coverage_pct": (
                100.0
                * values[
                    "allocated_area_km2_with_factor"
                ]
                / total_area
                if total_area > 0
                else 0.0
            ),
            "dLUC_stock_change_tCO2e": values[
                "dLUC_stock_change_tCO2e"
            ],
            "dLUC_annualized_tCO2e_per_yr": values[
                "dLUC_annualized_tCO2e_per_yr"
            ],
            "dLUC_amortization_years": (
                DLUC_AMORTIZATION_YEARS
            ),
        })

    return output


def summarize_weighted_origin_stocks(detail_rows):
    grouped = defaultdict(lambda: {
        "area_ha_total": 0.0,
        "area_ha_with_origin_factor": 0.0,
        "origin_stock_area_weighted_sum": 0.0,
    })

    for row in detail_rows:
        scenario = row["scenario"]

        area_ha = float(
            row["allocated_area_ha"]
        )

        grouped[scenario]["area_ha_total"] += area_ha

        origin_stock = row[
            "origin_stock_tCO2e_per_ha"
        ]

        if origin_stock in ("", None):
            continue

        origin_stock = float(origin_stock)

        grouped[scenario][
            "area_ha_with_origin_factor"
        ] += area_ha

        grouped[scenario][
            "origin_stock_area_weighted_sum"
        ] += area_ha * origin_stock

    output = []

    for scenario in SCENARIOS:
        values = grouped.get(
            scenario,
            {
                "area_ha_total": 0.0,
                "area_ha_with_origin_factor": 0.0,
                "origin_stock_area_weighted_sum": 0.0,
            },
        )

        calculated_mean = (
            values[
                "origin_stock_area_weighted_sum"
            ]
            / values[
                "area_ha_with_origin_factor"
            ]
            if values[
                "area_ha_with_origin_factor"
            ] > 0
            else None
        )

        reference_mean = (
            SCENARIO_WEIGHTED_MEAN_ORIGIN_STOCK_REFERENCE
            .get(scenario)
        )

        output.append({
            "scenario": scenario,
            "allocated_area_ha_total": values[
                "area_ha_total"
            ],
            "allocated_area_ha_with_origin_factor": values[
                "area_ha_with_origin_factor"
            ],
            "origin_factor_coverage_pct": (
                100.0
                * values[
                    "area_ha_with_origin_factor"
                ]
                / values["area_ha_total"]
                if values["area_ha_total"] > 0
                else 0.0
            ),
            "weighted_mean_origin_stock_calculated_tCO2e_per_ha": (
                calculated_mean
            ),
            "weighted_mean_origin_stock_reference_tCO2e_per_ha": (
                reference_mean
            ),
            "difference_calculated_minus_reference_tCO2e_per_ha": (
                calculated_mean - reference_mean
                if (
                    calculated_mean is not None
                    and reference_mean is not None
                )
                else ""
            ),
        })

    return output


def make_factor_template(missing_rows):
    unique_rows = {}

    for row in missing_rows:
        key = (
            row["biome"],
            row["mapbiomas_class"],
            row["pasture_vigor_code"],
            row["needed_factor"],
        )

        unique_rows[key] = {
            "biome": row["biome"],
            "mapbiomas_class": row[
                "mapbiomas_class"
            ],
            "mapbiomas_class_name": row[
                "mapbiomas_class_name"
            ],
            "pasture_vigor_code": row[
                "pasture_vigor_code"
            ],
            "needed_factor": row[
                "needed_factor"
            ],
            "stock_tCO2e_per_ha_to_fill": "",
            "source_or_method": "",
            "notes": (
                "Add this factor to LULC_carbon_factors "
                "or define a manual override in the script."
            ),
        }

    return list(unique_rows.values())


# =============================================================================
# 13. MAIN
# =============================================================================

def main():
    ensure_dir(OUTPUT_DIR)
    ensure_dir(CACHE_DIR)

    required_files = [
        (
            FACTOR_WORKBOOK_XLSX,
            "factor workbook",
        ),
        (
            MAPBIOMAS_LANDUSE_RASTER,
            "MapBiomas raster",
        ),
        (
            PASTURE_VIGOR_RASTER,
            "pasture vigor raster",
        ),
        (
            BIOMES_GPKG,
            "biome GeoPackage",
        ),
    ]

    for path, label in required_files:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"\n{label} not found:\n{path}"
            )

    print("\n" + "=" * 90)
    print("dLUC EMISSIONS FROM FINAL DOWNSCALED ALLOCATIONS")
    print("=" * 90)
    print("Scenarios:")
    print(", ".join(SCENARIOS))

    print("\nBiome source:")
    print(BIOMES_GPKG)

    print("\nBiome layer:")
    print(BIOME_LAYER_NAME)

    print("\nBiome field:")
    print(BIOME_FIELD)

    print("\nBiome CRS override:")
    print(BIOME_CRS_OVERRIDE)

    factors = load_lulc_factors()

    all_details = []
    all_missing = []
    all_input_diagnostics = []
    all_biome_audits = []

    run_tag = datetime.now().strftime(
        "%Y%m%d_%H%M%S_%f"
    )

    for scenario in SCENARIOS:
        print("\n" + "=" * 90)
        print(f"SCENARIO: {scenario}")
        print("=" * 90)

        sugarcane_raster = find_sugarcane_raster(
            scenario
        )

        soybean_raster = find_soybean_raster(
            scenario
        )

        if sugarcane_raster is None:
            raise FileNotFoundError(
                "\nCould not find final sugarcane raster "
                f"for '{scenario}'."
                "\nSet MANUAL_ALLOCATION_RASTERS if needed."
            )

        if (
            scenario != "scenario_epe"
            and soybean_raster is None
        ):
            raise FileNotFoundError(
                "\nCould not find final soybean raster "
                f"for '{scenario}'."
                "\nSet MANUAL_ALLOCATION_RASTERS if needed."
            )

        if soybean_raster:
            overlap_pixels = count_overlap_pixels(
                scenario,
                sugarcane_raster,
                soybean_raster,
            )

            print(
                f"\nSugarcane-soybean overlap: "
                f"{overlap_pixels:,} pixels"
            )

            if (
                overlap_pixels > 0
                and FAIL_IF_SUGARCANE_SOYBEAN_OVERLAP
            ):
                raise RuntimeError(
                    "\nSugarcane and soybean final allocation "
                    "rasters overlap."
                    f"\nScenario: {scenario}"
                    f"\nOverlap pixels: {overlap_pixels:,}"
                )

        feedstock_rasters = {
            "sugarcane": sugarcane_raster,
        }

        if soybean_raster:
            feedstock_rasters["soybean"] = soybean_raster

        for feedstock, allocation_raster in (
            feedstock_rasters.items()
        ):
            (
                grouped_counts,
                area_ha_per_pixel,
                diagnostics,
                biome_audit_rows,
            ) = process_allocation_raster(
                scenario,
                feedstock,
                allocation_raster,
            )

            detail_rows, missing_rows = (
                make_dluc_detail_rows(
                    grouped_counts,
                    area_ha_per_pixel,
                    factors,
                )
            )

            all_details.extend(detail_rows)
            all_missing.extend(missing_rows)
            all_input_diagnostics.append(diagnostics)

            for audit_row in biome_audit_rows:
                audit_row["scenario"] = scenario
                audit_row["feedstock"] = feedstock
                all_biome_audits.append(audit_row)

            print(
                f"\nDetailed rows created: "
                f"{len(detail_rows):,}"
            )

            print(
                f"Rows without complete factor coverage: "
                f"{len(missing_rows):,}"
            )

    summary_by_biome = summarize_dluc_by_biome(
        all_details
    )

    weighted_origin_stock_summary = (
        summarize_weighted_origin_stocks(
            all_details
        )
    )

    factor_template = make_factor_template(
        all_missing
    )

    detail_path = os.path.join(
        OUTPUT_DIR,
        f"dLUC_detail_by_biome_landuse_{run_tag}.csv",
    )

    summary_biome_path = os.path.join(
        OUTPUT_DIR,
        f"dLUC_summary_by_scenario_feedstock_biome_{run_tag}.csv",
    )

    weighted_origin_stock_path = os.path.join(
        OUTPUT_DIR,
        f"weighted_mean_origin_stock_by_scenario_{run_tag}.csv",
    )

    diagnostics_path = os.path.join(
        OUTPUT_DIR,
        f"dLUC_input_coverage_diagnostics_{run_tag}.csv",
    )

    missing_path = os.path.join(
        OUTPUT_DIR,
        f"dLUC_missing_factors_{run_tag}.csv",
    )

    template_path = os.path.join(
        OUTPUT_DIR,
        f"dLUC_factor_template_to_fill_{run_tag}.csv",
    )

    biome_audit_path = os.path.join(
        OUTPUT_DIR,
        f"biome_geometry_audit_{run_tag}.csv",
    )

    write_csv(
        detail_path,
        [
            "scenario",
            "feedstock",
            "biome",
            "biome_code",
            "mapbiomas_class",
            "mapbiomas_class_name",
            "pasture_vigor_code",
            "pasture_vigor_label",
            "allocated_pixels",
            "allocated_area_ha",
            "allocated_area_km2",
            "origin_stock_tCO2e_per_ha",
            "destination_stock_tCO2e_per_ha",
            "origin_factor_available",
            "destination_factor_available",
            "dLUC_stock_change_tCO2e_per_ha",
            "dLUC_stock_change_tCO2e",
            "dLUC_annualized_tCO2e_per_yr",
            "factor_status",
            "origin_factor_source",
            "destination_factor_source",
            "origin_factor_notes",
            "destination_factor_notes",
            "dLUC_amortization_years",
        ],
        all_details,
    )

    write_csv(
        summary_biome_path,
        [
            "scenario",
            "feedstock",
            "biome",
            "allocated_area_km2_total",
            "allocated_area_km2_with_factor",
            "allocated_area_km2_without_factor",
            "factor_coverage_pct",
            "dLUC_stock_change_tCO2e",
            "dLUC_annualized_tCO2e_per_yr",
            "dLUC_amortization_years",
        ],
        summary_by_biome,
    )

    write_csv(
        weighted_origin_stock_path,
        [
            "scenario",
            "allocated_area_ha_total",
            "allocated_area_ha_with_origin_factor",
            "origin_factor_coverage_pct",
            "weighted_mean_origin_stock_calculated_tCO2e_per_ha",
            "weighted_mean_origin_stock_reference_tCO2e_per_ha",
            "difference_calculated_minus_reference_tCO2e_per_ha",
        ],
        weighted_origin_stock_summary,
    )

    write_csv(
        diagnostics_path,
        [
            "scenario",
            "feedstock",
            "allocation_raster",
            "landuse_raster_used",
            "pasture_raster_used",
            "biome_raster_used",
            "pixel_area_ha",
            "allocated_pixels_raw",
            "allocated_pixels_with_landuse_and_biome",
            "allocated_pixels_missing_landuse_or_biome",
            "allocated_area_km2_raw",
            "allocated_area_km2_with_landuse_and_biome",
            "allocated_area_km2_missing_landuse_or_biome",
        ],
        all_input_diagnostics,
    )

    write_csv(
        missing_path,
        [
            "scenario",
            "feedstock",
            "biome",
            "biome_code",
            "mapbiomas_class",
            "mapbiomas_class_name",
            "pasture_vigor_code",
            "unmapped_area_km2",
            "factor_status",
            "needed_factor",
        ],
        all_missing,
    )

    write_csv(
        template_path,
        [
            "biome",
            "mapbiomas_class",
            "mapbiomas_class_name",
            "pasture_vigor_code",
            "needed_factor",
            "stock_tCO2e_per_ha_to_fill",
            "source_or_method",
            "notes",
        ],
        factor_template,
    )

    write_csv(
        biome_audit_path,
        [
            "scenario",
            "feedstock",
            "source_fid",
            "raw_biome_name",
            "canonical_biome",
            "status",
        ],
        all_biome_audits,
    )

    print("\n" + "=" * 90)
    print("WEIGHTED MEAN ORIGIN STOCK VALIDATION")
    print("=" * 90)

    for row in weighted_origin_stock_summary:
        print(
            f"{row['scenario']:<20} | "
            f"Calculated: "
            f"{row['weighted_mean_origin_stock_calculated_tCO2e_per_ha']} | "
            f"Reference: "
            f"{row['weighted_mean_origin_stock_reference_tCO2e_per_ha']} | "
            f"Difference: "
            f"{row['difference_calculated_minus_reference_tCO2e_per_ha']}"
        )

    print("\n" + "=" * 90)
    print("FINISHED")
    print("=" * 90)

    print("\nMain dLUC summary:")
    print(summary_biome_path)

    print("\nWeighted-origin-stock validation:")
    print(weighted_origin_stock_path)

    print("\nInput coverage diagnostics:")
    print(diagnostics_path)

    if all_missing:
        missing_area_km2 = sum(
            float(row["unmapped_area_km2"])
            for row in all_missing
        )

        print(
            f"\nWARNING: {missing_area_km2:,.4f} km² "
            "has incomplete factor coverage."
        )

        if STRICT_FACTOR_COVERAGE:
            raise RuntimeError(
                "\nSTRICT_FACTOR_COVERAGE=True and factor "
                "coverage is incomplete."
            )


main()