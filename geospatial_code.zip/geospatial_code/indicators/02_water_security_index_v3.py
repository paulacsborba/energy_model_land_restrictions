 # ============================================================
# QGIS / GDAL PYTHON SCRIPT
#
# Combine sugarcane + soybean downscaled allocation rasters
# and apply Water Security Index indicator by scenario.
#
# Combined feedstock raster:
#   0 = no allocation / nodata
#   1 = sugarcane
#   2 = soybean
#   3 = overlap between sugarcane and soybean
#
# WSI raster:
#   original scale:
#       1 = worst water security
#       5 = best water security
#
# Converted water risk score:
#       1 = low water risk / best condition
#       2 = medium water risk
#       3 = high water risk / worst condition
#
# Formula:
#   water_risk_score = 3.5 - 0.5 * WSI
#
# Examples:
#   WSI 1 -> risk 3.0
#   WSI 2 -> risk 2.5
#   WSI 3 -> risk 2.0
#   WSI 4 -> risk 1.5
#   WSI 5 -> risk 1.0
#
# Main CSV:
#   combined_water_risk_by_zone_feedstock_all_scenarios_*.csv
#
# Run inside QGIS Python console or OSGeo Python.
# ============================================================

import os
import glob
import csv
from datetime import datetime

import numpy as np

from osgeo import gdal, ogr, osr

gdal.UseExceptions()


# ============================================================
# USER CONFIGURATION
# ============================================================

SCENARIOS = [
    "scenario_epe",
    "baseline",
    "conservation",
    "governance",
    "degraded_pastures",
    "integrated",
]

BASE_DIR = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"

WSI_RASTER_PATH = os.path.join(
    BASE_DIR,
    r"geospatial_data\rasters\water_index\br_ish_water_index_5880_250m.tif"
)

ZONES_PATH = (
    r"C:\Users\pcsbo\OneDrive\Doutorado\Library\Data"
    r"\shapefile\zones\zones_\zones_fixed.shp"
)

# Leave None for automatic detection.
# If automatic detection fails, set manually, e.g.:
# ZONE_FIELD = "ZONE"
ZONE_FIELD = None

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    r"outputs\combined_feedstock_water_index_indicator"
)

os.makedirs(OUTPUT_DIR, exist_ok=True)

BLOCK_SIZE = 1024
OUTPUT_NODATA = -9999.0

# If True, WSI values outside 1-5 are ignored.
EXCLUDE_WSI_OUTSIDE_1_TO_5 = True

# If True, missing scenarios are skipped instead of stopping.
SKIP_MISSING_SCENARIOS = False

# In scenario_epe, only sugarcane is allocated. The combined allocation
# is therefore identical to sugarcane and soybean is not searched.
SUGARCANE_ONLY_SCENARIOS = {"scenario_epe"}

# The new soybean allocation is generated after sugarcane is locked.
# Any overlap therefore indicates that an outdated or incorrect raster
# was selected. Set False only for diagnostic runs.
RAISE_ON_OVERLAP = True

# If automatic search picks the wrong raster, manually force paths here.
#
# Example:
# MANUAL_SUGARCANE_RASTERS = {
#     "integrated": r"C:\...\downscaled_sugarcane_chosen_potential_class_integrated.tif"
# }
MANUAL_SUGARCANE_RASTERS = {}

# Example:
# MANUAL_SOYBEAN_RASTERS = {
#     "integrated": r"C:\...\downscaled_soybean_chosen_binary_after_sugarcane_integrated_new_20260617_105457.tif"
# }
MANUAL_SOYBEAN_RASTERS = {}


# ============================================================
# WSI CONVERSION
# ============================================================

def convert_wsi_1_5_to_water_risk_1_3(wsi_array):
    """
    Converts Water Security Index from 1-5 to water risk 1-3.

    Original WSI:
        1 = worst water security
        5 = best water security

    Water risk:
        1 = low risk
        3 = high risk
    """

    risk_array = 3.5 - 0.5 * wsi_array
    risk_array = np.clip(risk_array, 1.0, 3.0)

    return risk_array


def calculate_water_risk_index_0_to_1(water_risk_score):
    """
    Converts risk score 1-3 into normalized index 0-1.

    0 = lowest risk
    1 = highest risk
    """

    return (water_risk_score - 1.0) / 2.0


def interpret_water_risk_score(water_risk_score):
    if water_risk_score >= 2.5:
        return "high water-risk dominated"

    if water_risk_score >= 1.5:
        return "mixed or medium water-risk dominated"

    return "low water-risk dominated"


# ============================================================
# GENERAL HELPERS
# ============================================================

def safe_scenario_name(name):
    return str(name).replace(" ", "_").replace("/", "_").replace("\\", "_")


def safe_remove_file(path):
    """
    If file exists and can be removed, remove it.
    If it is locked by QGIS/OneDrive/Excel, create a new timestamped path.
    """

    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            root, ext = os.path.splitext(path)
            new_path = f"{root}_new_{timestamp}{ext}"

            print("\nWARNING: could not remove existing file.")
            print("Using alternative output path:")
            print(new_path)

            return new_path

    return path


def write_csv(output_csv, fieldnames, rows):
    output_csv = safe_remove_file(output_csv)

    with open(output_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("CSV written:")
    print(output_csv)

    return output_csv


def calculate_pixel_area_km2(geotransform):
    pixel_width = abs(geotransform[1])
    pixel_height = abs(geotransform[5])
    return (pixel_width * pixel_height) / 1_000_000


def raster_grid_signature(ds):
    return {
        "cols": ds.RasterXSize,
        "rows": ds.RasterYSize,
        "gt": ds.GetGeoTransform(),
        "proj": ds.GetProjection()
    }


def grids_are_equal(reference_ds, other_ds, tolerance=1e-9):
    ref = raster_grid_signature(reference_ds)
    oth = raster_grid_signature(other_ds)

    if ref["cols"] != oth["cols"]:
        return False

    if ref["rows"] != oth["rows"]:
        return False

    for a, b in zip(ref["gt"], oth["gt"]):
        if abs(a - b) > tolerance:
            return False

    if ref["proj"] != oth["proj"]:
        return False

    return True


def open_raster(path):
    ds = gdal.Open(path, gdal.GA_ReadOnly)

    if ds is None:
        raise FileNotFoundError(f"Could not open raster:\n{path}")

    return ds


def get_valid_positive_mask(arr, nodata):
    valid = np.isfinite(arr)

    if nodata is not None:
        valid &= arr != nodata

    valid &= arr != -9999
    valid &= arr > 0

    return valid


def get_valid_wsi_mask(arr, nodata):
    valid = np.isfinite(arr)

    if nodata is not None:
        valid &= arr != nodata

    valid &= arr != -9999

    if EXCLUDE_WSI_OUTSIDE_1_TO_5:
        valid &= arr >= 1
        valid &= arr <= 5

    return valid


def align_raster_to_reference(
    input_raster_path,
    reference_ds,
    output_path,
    output_nodata,
    resample_alg="near"
):
    """
    Aligns input raster to reference raster grid.
    Uses nearest neighbor for categorical/ordinal rasters.
    """

    input_ds = open_raster(input_raster_path)

    if grids_are_equal(reference_ds, input_ds):
        input_ds = None
        return input_raster_path

    print("\nRaster grid differs from reference. Aligning:")
    print(input_raster_path)

    ref_gt = reference_ds.GetGeoTransform()
    ref_proj = reference_ds.GetProjection()
    ref_cols = reference_ds.RasterXSize
    ref_rows = reference_ds.RasterYSize

    xmin = ref_gt[0]
    xmax = ref_gt[0] + ref_cols * ref_gt[1]
    ymax = ref_gt[3]
    ymin = ref_gt[3] + ref_rows * ref_gt[5]

    src_band = input_ds.GetRasterBand(1)
    src_nodata = src_band.GetNoDataValue()

    warp_kwargs = {
        "format": "GTiff",
        "outputBounds": (xmin, ymin, xmax, ymax),
        "width": ref_cols,
        "height": ref_rows,
        "dstSRS": ref_proj,
        "resampleAlg": resample_alg,
        "multithread": True,
        "creationOptions": ["COMPRESS=LZW", "BIGTIFF=IF_SAFER"],
        "dstNodata": output_nodata
    }

    if src_nodata is not None:
        warp_kwargs["srcNodata"] = src_nodata

    output_path = safe_remove_file(output_path)

    aligned_ds = gdal.Warp(
        output_path,
        input_ds,
        options=gdal.WarpOptions(**warp_kwargs)
    )

    if aligned_ds is None:
        raise RuntimeError(f"Failed to align raster:\n{input_raster_path}")

    aligned_ds.FlushCache()
    aligned_ds = None
    input_ds = None

    print("Aligned raster written:")
    print(output_path)

    return output_path


def create_geotiff_like(reference_ds, output_path, dtype, nodata):
    output_path = safe_remove_file(output_path)

    driver = gdal.GetDriverByName("GTiff")

    ds = driver.Create(
        output_path,
        reference_ds.RasterXSize,
        reference_ds.RasterYSize,
        1,
        dtype,
        options=["COMPRESS=LZW", "BIGTIFF=IF_SAFER"]
    )

    if ds is None:
        raise RuntimeError(f"Could not create raster:\n{output_path}")

    ds.SetGeoTransform(reference_ds.GetGeoTransform())
    ds.SetProjection(reference_ds.GetProjection())

    band = ds.GetRasterBand(1)
    band.SetNoDataValue(nodata)
    band.Fill(nodata)

    return ds, output_path


# ============================================================
# FIND DOWNSCALED RASTERS
# ============================================================

def choose_latest_file(paths):
    paths = sorted(set(paths))

    if len(paths) == 0:
        return None

    paths = sorted(paths, key=lambda p: os.path.getmtime(p), reverse=True)

    return paths[0]


def find_sugarcane_raster(scenario):
    """
    Find the final sugarcane allocation raster for the new downscaling.

    Priority:
      1. *_sugarcane_direct_raster_downscaling_checked
      2. *_sugarcane_direct_raster_downscaling
      3. legacy direct-raster folders, only as a fallback

    The final allocated raster must contain both "sugarcane" and "chosen"
    in its filename. Potential-class rasters are preferred over binary
    rasters because they preserve the final selected allocation.
    """
    if scenario in MANUAL_SUGARCANE_RASTERS:
        path = MANUAL_SUGARCANE_RASTERS[scenario]

        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Manual sugarcane raster not found:\n{path}"
            )

        print("\nUsing manual sugarcane raster:")
        print(path)
        return path

    integration_dir = os.path.join(
        BASE_DIR,
        "geospatial_data",
        "integration"
    )

    scenario_folder_token = (
        scenario
        if str(scenario).startswith("scenario_")
        else f"scenario_{scenario}"
    )

    candidate_dirs = [
        f"{scenario_folder_token}_sugarcane_direct_raster_downscaling_checked",
        f"{scenario_folder_token}_sugarcane_direct_raster_downscaling",
        f"{scenario_folder_token}_direct_raster_downscaling_checked",
        f"{scenario_folder_token}_direct_raster_downscaling",
    ]

    patterns = []

    for folder_name in candidate_dirs:
        folder = os.path.join(integration_dir, folder_name)

        patterns.extend([
            os.path.join(
                folder,
                f"downscaled_sugarcane_chosen_potential_class_{scenario}*.tif"
            ),
            os.path.join(
                folder,
                f"downscaled_sugarcane_chosen_binary_{scenario}*.tif"
            ),
            os.path.join(
                folder,
                f"*sugarcane*chosen*{scenario}*.tif"
            ),
        ])

    # Last-resort search, restricted to sugarcane downscaling folders.
    patterns.append(
        os.path.join(
            integration_dir,
            f"*{scenario_folder_token}*sugarcane*downscaling*",
            f"*sugarcane*chosen*{scenario}*.tif"
        )
    )

    matches = []

    for pattern in patterns:
        matches.extend(glob.glob(pattern))

    excluded_tokens = [
        "soybean",
        "score_total",
        "summary",
        "selected_pixels",
        "locked",
        "mask",
        "used_for_soybean",
        "sourceclass",
        "source_class",
        "after_sugarcane",
    ]

    candidates = []

    for path in sorted(set(matches)):
        filename = os.path.basename(path).lower()
        parent = os.path.dirname(path).lower()

        if "soybean" in filename or "soybean" in parent:
            continue

        if "sugarcane" not in filename:
            continue

        if "chosen" not in filename:
            continue

        if any(token in filename for token in excluded_tokens):
            continue

        candidates.append(path)

    print("\nCandidate sugarcane rasters:")
    if candidates:
        for path in candidates:
            print("  ", path)
    else:
        print("  None found.")

    potential_class = [
        path for path in candidates
        if "potential_class" in os.path.basename(path).lower()
    ]

    binary = [
        path for path in candidates
        if "binary" in os.path.basename(path).lower()
    ]

    selected = (
        choose_latest_file(potential_class)
        or choose_latest_file(binary)
        or choose_latest_file(candidates)
    )

    print("\nSelected sugarcane raster:")
    print(selected)

    return selected

def find_soybean_raster(scenario):
    """
    Find the final soybean raster from the post-sugarcane allocation step.

    Only rasters inside:
        scenario_<scenario>_soybean_after_sugarcane_downscaling
    (or its checked version) are eligible.

    This deliberately avoids the old direct soybean downscaling, which may
    overlap with sugarcane and is not compatible with the new workflow.
    """
    if scenario in SUGARCANE_ONLY_SCENARIOS:
        print(
            f"\nScenario '{scenario}' is sugarcane-only. "
            "Soybean raster is not required."
        )
        return None

    if scenario in MANUAL_SOYBEAN_RASTERS:
        path = MANUAL_SOYBEAN_RASTERS[scenario]

        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Manual soybean raster not found:\n{path}"
            )

        print("\nUsing manual soybean raster:")
        print(path)
        return path

    integration_dir = os.path.join(
        BASE_DIR,
        "geospatial_data",
        "integration"
    )

    scenario_folder_token = (
        scenario
        if str(scenario).startswith("scenario_")
        else f"scenario_{scenario}"
    )

    candidate_dirs = [
        f"{scenario_folder_token}_soybean_after_sugarcane_downscaling_checked",
        f"{scenario_folder_token}_soybean_after_sugarcane_downscaling",
    ]

    patterns = []

    for folder_name in candidate_dirs:
        folder = os.path.join(integration_dir, folder_name)

        patterns.extend([
            os.path.join(
                folder,
                f"downscaled_soybean_chosen_binary_after_sugarcane_{scenario}*.tif"
            ),
            os.path.join(
                folder,
                f"downscaled_soybean_chosen_potential_class_after_sugarcane_{scenario}*.tif"
            ),
            os.path.join(
                folder,
                f"*soybean*chosen*after*sugarcane*{scenario}*.tif"
            ),
            os.path.join(
                folder,
                f"*soybean*chosen*{scenario}*.tif"
            ),
        ])

    matches = []

    for pattern in patterns:
        matches.extend(glob.glob(pattern))

    excluded_tokens = [
        "sugarcane_locked",
        "selected_pixels",
        "summary",
        "sourceclass",
        "source_class",
        "locked",
        "mask",
        "score_total",
        "available",
    ]

    candidates = []

    for path in sorted(set(matches)):
        filename = os.path.basename(path).lower()
        parent = os.path.dirname(path).lower()

        # The directory itself must confirm that this is the soybean-after-
        # sugarcane output of the new sequential allocation.
        if "after_sugarcane" not in filename and "after_sugarcane" not in parent:
            continue

        if "soybean" not in filename:
            continue

        if "chosen" not in filename:
            continue

        if any(token in filename for token in excluded_tokens):
            continue

        candidates.append(path)

    print("\nCandidate soybean-after-sugarcane rasters:")
    if candidates:
        for path in candidates:
            print("  ", path)
    else:
        print("  None found.")

    binary_after_sugarcane = [
        path for path in candidates
        if (
            "binary" in os.path.basename(path).lower()
            and "after_sugarcane" in os.path.basename(path).lower()
        )
    ]

    selected = (
        choose_latest_file(binary_after_sugarcane)
        or choose_latest_file(candidates)
    )

    print("\nSelected soybean raster:")
    print(selected)

    return selected
# ============================================================
# ZONES RASTER
# ============================================================

def detect_zone_field(zones_layer, zone_field_input):
    layer_defn = zones_layer.GetLayerDefn()

    field_names = [
        layer_defn.GetFieldDefn(i).GetName()
        for i in range(layer_defn.GetFieldCount())
    ]

    print("\nFields available in zones shapefile:")
    print(field_names)

    if zone_field_input is not None:
        if zone_field_input not in field_names:
            raise Exception(
                f"Manual zone field '{zone_field_input}' was not found. "
                f"Available fields: {field_names}"
            )

        return zone_field_input

    preferred_fields = [
        "ZONE", "zone", "Zone",
        "NAME", "name", "Name",
        "ID", "id", "Id",
        "UF", "uf"
    ]

    detected = [f for f in preferred_fields if f in field_names]

    if len(detected) == 0:
        raise Exception(
            "Could not detect zone field automatically. "
            f"Available fields: {field_names}"
        )

    return detected[0]


def create_zones_raster(
    zones_path,
    zone_field,
    reference_ds,
    zones_raster_path
):
    zones_ds = ogr.Open(zones_path)

    if zones_ds is None:
        raise Exception(f"Could not open zones shapefile:\n{zones_path}")

    zones_layer = zones_ds.GetLayer()

    selected_zone_field = detect_zone_field(zones_layer, zone_field)

    print("Zone field selected:", selected_zone_field)

    raster_projection = reference_ds.GetProjection()
    raster_geotransform = reference_ds.GetGeoTransform()
    cols = reference_ds.RasterXSize
    rows = reference_ds.RasterYSize

    raster_srs = osr.SpatialReference()
    raster_srs.ImportFromWkt(raster_projection)

    zones_srs = zones_layer.GetSpatialRef()

    need_transform = False
    coord_transform = None

    if zones_srs is not None and not zones_srs.IsSame(raster_srs):
        need_transform = True
        coord_transform = osr.CoordinateTransformation(zones_srs, raster_srs)
        print("Zones CRS differs from raster CRS. Reprojecting zones in memory.")
    else:
        print("Zones CRS matches raster CRS.")

    zone_name_to_id = {}
    zone_id_to_name = {}
    current_id = 1

    for feature in zones_layer:
        zone_name = feature.GetField(selected_zone_field)

        if zone_name not in zone_name_to_id:
            zone_name_to_id[zone_name] = current_id
            zone_id_to_name[current_id] = zone_name
            current_id += 1

    zones_layer.ResetReading()

    driver_memory = ogr.GetDriverByName("Memory")
    mem_ds = driver_memory.CreateDataSource("memory_zones")

    mem_layer = mem_ds.CreateLayer(
        "zones_numeric",
        srs=raster_srs,
        geom_type=zones_layer.GetGeomType()
    )

    id_field = ogr.FieldDefn("zone_id", ogr.OFTInteger)
    mem_layer.CreateField(id_field)

    mem_layer_defn = mem_layer.GetLayerDefn()

    for feature in zones_layer:
        zone_name = feature.GetField(selected_zone_field)
        zone_id = zone_name_to_id[zone_name]

        geom = feature.GetGeometryRef()

        if geom is None:
            continue

        geom_copy = geom.Clone()

        if need_transform:
            geom_copy.Transform(coord_transform)

        new_feature = ogr.Feature(mem_layer_defn)
        new_feature.SetField("zone_id", zone_id)
        new_feature.SetGeometry(geom_copy)

        mem_layer.CreateFeature(new_feature)
        new_feature = None

    zones_raster_path = safe_remove_file(zones_raster_path)

    driver_tiff = gdal.GetDriverByName("GTiff")

    zones_raster_ds = driver_tiff.Create(
        zones_raster_path,
        cols,
        rows,
        1,
        gdal.GDT_Int32,
        options=["COMPRESS=LZW", "BIGTIFF=IF_SAFER"]
    )

    if zones_raster_ds is None:
        raise Exception("Could not create zones raster.")

    zones_raster_ds.SetGeoTransform(raster_geotransform)
    zones_raster_ds.SetProjection(raster_projection)

    band = zones_raster_ds.GetRasterBand(1)
    band.SetNoDataValue(0)
    band.Fill(0)

    gdal.RasterizeLayer(
        zones_raster_ds,
        [1],
        mem_layer,
        options=["ATTRIBUTE=zone_id"]
    )

    band.FlushCache()
    zones_raster_ds.FlushCache()
    zones_raster_ds = None

    print("Zones rasterized:")
    print(zones_raster_path)

    return zones_raster_path, zone_id_to_name, selected_zone_field


# ============================================================
# COMBINE SUGARCANE + SOYBEAN RASTERS
# ============================================================

def combine_sugarcane_soybean_rasters(
    scenario,
    sugarcane_raster_path,
    soybean_raster_path,
    scenario_output_dir
):
    """
    Build the final feedstock raster from the current sequential downscaling.

    Codes:
        0 = not allocated
        1 = sugarcane
        2 = soybean
        3 = overlap (diagnostic only; should not occur)
    """
    print("\n------------------------------------------------------------")
    print(f"Combining final allocation rasters for scenario: {scenario}")
    print("------------------------------------------------------------")

    if (
        sugarcane_raster_path is None
        or not os.path.exists(sugarcane_raster_path)
    ):
        raise FileNotFoundError(
            f"Sugarcane raster not found for scenario {scenario}:\n"
            f"{sugarcane_raster_path}"
        )

    has_soybean = soybean_raster_path is not None

    if has_soybean and not os.path.exists(soybean_raster_path):
        raise FileNotFoundError(
            f"Soybean raster not found for scenario {scenario}:\n"
            f"{soybean_raster_path}"
        )

    print("Sugarcane raster:")
    print(sugarcane_raster_path)

    if has_soybean:
        print("Soybean raster (after sugarcane):")
        print(soybean_raster_path)
    else:
        print("Soybean raster: not applicable (sugarcane-only scenario).")

    sugar_ds = open_raster(sugarcane_raster_path)

    run_tag = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    soybean_aligned_path = None
    soy_ds = None
    soy_band = None
    soy_nodata = None

    if has_soybean:
        aligned_soybean_path = os.path.join(
            scenario_output_dir,
            f"soybean_after_sugarcane_aligned_to_sugarcane_"
            f"{scenario}_{run_tag}.tif"
        )

        soybean_aligned_path = align_raster_to_reference(
            input_raster_path=soybean_raster_path,
            reference_ds=sugar_ds,
            output_path=aligned_soybean_path,
            output_nodata=0,
            resample_alg="near"
        )

        soy_ds = open_raster(soybean_aligned_path)

        if not grids_are_equal(sugar_ds, soy_ds):
            raise RuntimeError(
                "Soybean raster could not be aligned to the sugarcane grid."
            )

        soy_band = soy_ds.GetRasterBand(1)
        soy_nodata = soy_band.GetNoDataValue()

    cols = sugar_ds.RasterXSize
    rows = sugar_ds.RasterYSize
    geotransform = sugar_ds.GetGeoTransform()

    sugar_band = sugar_ds.GetRasterBand(1)
    sugar_nodata = sugar_band.GetNoDataValue()

    combined_binary_path = os.path.join(
        scenario_output_dir,
        f"combined_feedstocks_binary_{scenario}_{run_tag}.tif"
    )

    combined_feedstock_path = os.path.join(
        scenario_output_dir,
        f"combined_feedstocks_code_{scenario}_{run_tag}.tif"
    )

    combined_binary_ds, combined_binary_path = create_geotiff_like(
        reference_ds=sugar_ds,
        output_path=combined_binary_path,
        dtype=gdal.GDT_Byte,
        nodata=0
    )

    combined_feedstock_ds, combined_feedstock_path = create_geotiff_like(
        reference_ds=sugar_ds,
        output_path=combined_feedstock_path,
        dtype=gdal.GDT_Byte,
        nodata=0
    )

    combined_binary_band = combined_binary_ds.GetRasterBand(1)
    combined_feedstock_band = combined_feedstock_ds.GetRasterBand(1)

    total_sugar_pixels = 0
    total_soy_pixels = 0
    total_overlap_pixels = 0
    total_combined_pixels = 0

    pixel_area_km2 = calculate_pixel_area_km2(geotransform)

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(BLOCK_SIZE, rows - y)

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(BLOCK_SIZE, cols - x)

            sugar_arr = sugar_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            sugar_mask = get_valid_positive_mask(
                sugar_arr,
                sugar_nodata
            )

            if has_soybean:
                soy_arr = soy_band.ReadAsArray(
                    x, y, xsize, ysize
                ).astype(float)

                soy_mask = get_valid_positive_mask(
                    soy_arr,
                    soy_nodata
                )
            else:
                soy_mask = np.zeros(
                    sugar_arr.shape,
                    dtype=bool
                )

            overlap_mask = sugar_mask & soy_mask
            combined_mask = sugar_mask | soy_mask

            feedstock_arr = np.zeros(
                sugar_arr.shape,
                dtype=np.uint8
            )

            binary_arr = np.zeros(
                sugar_arr.shape,
                dtype=np.uint8
            )

            feedstock_arr[sugar_mask] = 1
            feedstock_arr[soy_mask] = 2
            feedstock_arr[overlap_mask] = 3

            binary_arr[combined_mask] = 1

            combined_feedstock_band.WriteArray(
                feedstock_arr,
                x,
                y
            )

            combined_binary_band.WriteArray(
                binary_arr,
                x,
                y
            )

            total_sugar_pixels += int(np.sum(sugar_mask))
            total_soy_pixels += int(np.sum(soy_mask))
            total_overlap_pixels += int(np.sum(overlap_mask))
            total_combined_pixels += int(np.sum(combined_mask))

        print(
            f"Combined row {min(y + BLOCK_SIZE, rows)} "
            f"of {rows}"
        )

    combined_binary_band.FlushCache()
    combined_feedstock_band.FlushCache()

    combined_binary_ds.FlushCache()
    combined_feedstock_ds.FlushCache()

    combined_binary_ds = None
    combined_feedstock_ds = None
    sugar_ds = None
    soy_ds = None

    sugarcane_area_km2 = total_sugar_pixels * pixel_area_km2
    soybean_area_km2 = total_soy_pixels * pixel_area_km2
    overlap_area_km2 = total_overlap_pixels * pixel_area_km2
    combined_area_km2 = total_combined_pixels * pixel_area_km2

    print("\nCombined feedstock area summary:")
    print(f"  Sugarcane area: {sugarcane_area_km2:,.3f} km²")
    print(f"  Soybean area:   {soybean_area_km2:,.3f} km²")
    print(f"  Overlap area:   {overlap_area_km2:,.3f} km²")
    print(f"  Combined area:  {combined_area_km2:,.3f} km²")

    if total_overlap_pixels > 0:
        message = (
            "\nOverlap between sugarcane and soybean was detected "
            f"({overlap_area_km2:,.3f} km²).\n"
            "The new soybean raster must be the post-sugarcane allocation, "
            "therefore overlap should be zero.\n"
            f"Sugarcane: {sugarcane_raster_path}\n"
            f"Soybean: {soybean_raster_path}"
        )

        if RAISE_ON_OVERLAP:
            raise RuntimeError(message)

        print("WARNING:", message)

    return {
        "combined_binary_raster": combined_binary_path,
        "combined_feedstock_raster": combined_feedstock_path,
        "sugarcane_raster": sugarcane_raster_path,
        "soybean_raster": soybean_aligned_path,
        "sugarcane_area_km2": sugarcane_area_km2,
        "soybean_area_km2": soybean_area_km2,
        "overlap_area_km2": overlap_area_km2,
        "combined_area_km2": combined_area_km2,
    }
# ============================================================
# APPLY WSI INDICATOR
# ============================================================

def feedstock_label(code):
    if code == 1:
        return "sugarcane"
    if code == 2:
        return "soybean"
    if code == 3:
        return "overlap"
    return "none"


def add_counts_to_dict(dictionary, key, value):
    dictionary[key] = dictionary.get(key, 0) + value


def get_unique_values_from_raster(raster_path):
    ds = open_raster(raster_path)
    band = ds.GetRasterBand(1)
    nodata = band.GetNoDataValue()

    cols = ds.RasterXSize
    rows = ds.RasterYSize

    unique_values = set()

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(BLOCK_SIZE, rows - y)

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(BLOCK_SIZE, cols - x)

            arr = band.ReadAsArray(x, y, xsize, ysize)

            if arr is None:
                continue

            arr = arr.astype(float)
            valid = np.isfinite(arr)

            if nodata is not None:
                valid &= arr != nodata

            if np.any(valid):
                for value in np.unique(arr[valid]):
                    unique_values.add(float(value))

    ds = None

    return sorted(unique_values)


def apply_wsi_indicator_to_combined(
    scenario,
    combined_feedstock_raster,
    wsi_raster_path,
    zones_path,
    zone_field,
    scenario_output_dir
):
    print("\n------------------------------------------------------------")
    print(f"Applying WSI indicator for scenario: {scenario}")
    print("------------------------------------------------------------")

    run_tag = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    feedstock_ds = open_raster(combined_feedstock_raster)

    cols = feedstock_ds.RasterXSize
    rows = feedstock_ds.RasterYSize
    geotransform = feedstock_ds.GetGeoTransform()
    projection = feedstock_ds.GetProjection()

    pixel_area_km2 = calculate_pixel_area_km2(geotransform)

    aligned_wsi_path = os.path.join(
        scenario_output_dir,
        f"WSI_aligned_to_combined_feedstocks_{scenario}_{run_tag}.tif"
    )

    wsi_aligned_path = align_raster_to_reference(
        input_raster_path=wsi_raster_path,
        reference_ds=feedstock_ds,
        output_path=aligned_wsi_path,
        output_nodata=OUTPUT_NODATA,
        resample_alg="near"
    )

    zones_raster_path = os.path.join(
        scenario_output_dir,
        f"zones_aligned_to_combined_feedstocks_{scenario}_{run_tag}.tif"
    )

    zones_raster_path, zone_id_to_name, selected_zone_field = create_zones_raster(
        zones_path=zones_path,
        zone_field=zone_field,
        reference_ds=feedstock_ds,
        zones_raster_path=zones_raster_path
    )

    wsi_ds = open_raster(wsi_aligned_path)
    zones_ds = open_raster(zones_raster_path)

    feedstock_band = feedstock_ds.GetRasterBand(1)
    wsi_band = wsi_ds.GetRasterBand(1)
    zone_band = zones_ds.GetRasterBand(1)

    feedstock_nodata = feedstock_band.GetNoDataValue()
    wsi_nodata = wsi_band.GetNoDataValue()

    water_risk_raster_path = os.path.join(
        scenario_output_dir,
        f"water_risk_score_combined_feedstocks_{scenario}_{run_tag}.tif"
    )

    water_risk_ds, water_risk_raster_path = create_geotiff_like(
        reference_ds=feedstock_ds,
        output_path=water_risk_raster_path,
        dtype=gdal.GDT_Float32,
        nodata=OUTPUT_NODATA
    )

    water_risk_band = water_risk_ds.GetRasterBand(1)

    # Aggregation dictionaries:
    # keys use (zone_id, feedstock_code)
    COMBINED_CODE = 99

    total_pixels = {}
    total_area = {}

    weighted_wsi_sum = {}
    weighted_risk_sum = {}

    min_wsi = {}
    max_wsi = {}
    min_risk = {}
    max_risk = {}

    # wsi_class_counts[(zone_id, feedstock_code, wsi_class)] = pixels
    wsi_class_counts = {}

    print("\nProcessing blocks...")

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(BLOCK_SIZE, rows - y)

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(BLOCK_SIZE, cols - x)

            feedstock_arr = feedstock_band.ReadAsArray(x, y, xsize, ysize)
            wsi_arr = wsi_band.ReadAsArray(x, y, xsize, ysize)
            zone_arr = zone_band.ReadAsArray(x, y, xsize, ysize)

            if feedstock_arr is None or wsi_arr is None or zone_arr is None:
                continue

            feedstock_arr = feedstock_arr.astype(np.int32)
            wsi_arr = wsi_arr.astype(float)
            zone_arr = zone_arr.astype(np.int32)

            valid_feedstock = feedstock_arr > 0

            if feedstock_nodata is not None:
                valid_feedstock &= feedstock_arr != feedstock_nodata

            valid_wsi = get_valid_wsi_mask(wsi_arr, wsi_nodata)
            valid_zone = zone_arr > 0

            valid_mask = valid_feedstock & valid_wsi & valid_zone

            output_arr = np.full(feedstock_arr.shape, OUTPUT_NODATA, dtype=np.float32)

            if np.any(valid_mask):
                water_risk_arr = convert_wsi_1_5_to_water_risk_1_3(wsi_arr)
                output_arr[valid_mask] = water_risk_arr[valid_mask].astype(np.float32)

            water_risk_band.WriteArray(output_arr, x, y)

            if not np.any(valid_mask):
                continue

            selected_zones = zone_arr[valid_mask].astype(np.int32)
            selected_feedstocks = feedstock_arr[valid_mask].astype(np.int32)
            selected_wsi = wsi_arr[valid_mask].astype(float)
            selected_risk = convert_wsi_1_5_to_water_risk_1_3(selected_wsi)

            # ------------------------------------------------
            # Specific feedstock groups:
            #   1 = sugarcane
            #   2 = soybean
            #   3 = overlap
            # ------------------------------------------------

            unique_groups = np.unique(
                np.column_stack((selected_zones, selected_feedstocks)),
                axis=0
            )

            for group in unique_groups:
                zone_id = int(group[0])
                feedstock_code = int(group[1])

                group_mask = (
                    (selected_zones == zone_id) &
                    (selected_feedstocks == feedstock_code)
                )

                group_wsi = selected_wsi[group_mask]
                group_risk = selected_risk[group_mask]

                pixel_count = int(group_wsi.size)
                area_km2 = pixel_count * pixel_area_km2

                key = (zone_id, feedstock_code)

                add_counts_to_dict(total_pixels, key, pixel_count)
                total_area[key] = total_area.get(key, 0.0) + area_km2

                weighted_wsi_sum[key] = weighted_wsi_sum.get(key, 0.0) + float(
                    np.sum(group_wsi * pixel_area_km2)
                )

                weighted_risk_sum[key] = weighted_risk_sum.get(key, 0.0) + float(
                    np.sum(group_risk * pixel_area_km2)
                )

                if key not in min_wsi:
                    min_wsi[key] = float(np.min(group_wsi))
                    max_wsi[key] = float(np.max(group_wsi))
                    min_risk[key] = float(np.min(group_risk))
                    max_risk[key] = float(np.max(group_risk))
                else:
                    min_wsi[key] = min(min_wsi[key], float(np.min(group_wsi)))
                    max_wsi[key] = max(max_wsi[key], float(np.max(group_wsi)))
                    min_risk[key] = min(min_risk[key], float(np.min(group_risk)))
                    max_risk[key] = max(max_risk[key], float(np.max(group_risk)))

                group_wsi_classes = np.rint(group_wsi).astype(int)
                group_wsi_classes = group_wsi_classes[
                    (group_wsi_classes >= 1) &
                    (group_wsi_classes <= 5)
                ]

                if group_wsi_classes.size > 0:
                    unique_classes, class_counts = np.unique(
                        group_wsi_classes,
                        return_counts=True
                    )

                    for wsi_class, class_count in zip(unique_classes, class_counts):
                        add_counts_to_dict(
                            wsi_class_counts,
                            (zone_id, feedstock_code, int(wsi_class)),
                            int(class_count)
                        )

            # ------------------------------------------------
            # Combined group:
            #   99 = all feedstocks combined, union area
            # ------------------------------------------------

            unique_zones = np.unique(selected_zones)

            for zone_id in unique_zones:
                zone_id = int(zone_id)

                zone_mask = selected_zones == zone_id

                zone_wsi = selected_wsi[zone_mask]
                zone_risk = selected_risk[zone_mask]

                pixel_count = int(zone_wsi.size)
                area_km2 = pixel_count * pixel_area_km2

                key = (zone_id, COMBINED_CODE)

                add_counts_to_dict(total_pixels, key, pixel_count)
                total_area[key] = total_area.get(key, 0.0) + area_km2

                weighted_wsi_sum[key] = weighted_wsi_sum.get(key, 0.0) + float(
                    np.sum(zone_wsi * pixel_area_km2)
                )

                weighted_risk_sum[key] = weighted_risk_sum.get(key, 0.0) + float(
                    np.sum(zone_risk * pixel_area_km2)
                )

                if key not in min_wsi:
                    min_wsi[key] = float(np.min(zone_wsi))
                    max_wsi[key] = float(np.max(zone_wsi))
                    min_risk[key] = float(np.min(zone_risk))
                    max_risk[key] = float(np.max(zone_risk))
                else:
                    min_wsi[key] = min(min_wsi[key], float(np.min(zone_wsi)))
                    max_wsi[key] = max(max_wsi[key], float(np.max(zone_wsi)))
                    min_risk[key] = min(min_risk[key], float(np.min(zone_risk)))
                    max_risk[key] = max(max_risk[key], float(np.max(zone_risk)))

                zone_wsi_classes = np.rint(zone_wsi).astype(int)
                zone_wsi_classes = zone_wsi_classes[
                    (zone_wsi_classes >= 1) &
                    (zone_wsi_classes <= 5)
                ]

                if zone_wsi_classes.size > 0:
                    unique_classes, class_counts = np.unique(
                        zone_wsi_classes,
                        return_counts=True
                    )

                    for wsi_class, class_count in zip(unique_classes, class_counts):
                        add_counts_to_dict(
                            wsi_class_counts,
                            (zone_id, COMBINED_CODE, int(wsi_class)),
                            int(class_count)
                        )

        print(f"Processed row {min(y + BLOCK_SIZE, rows)} of {rows}")

    water_risk_band.FlushCache()
    water_risk_ds.FlushCache()
    water_risk_ds = None

    print("\nWater risk raster created:")
    print(water_risk_raster_path)

    # ========================================================
    # Build CSV rows by zone and feedstock
    # ========================================================

    results = []

    for key in sorted(total_area.keys()):
        zone_id, feedstock_code = key
        group_area = total_area[key]

        if group_area <= 0:
            continue

        mean_wsi = weighted_wsi_sum[key] / group_area
        mean_risk = weighted_risk_sum[key] / group_area
        risk_index = calculate_water_risk_index_0_to_1(mean_risk)

        area_wsi_1 = wsi_class_counts.get((zone_id, feedstock_code, 1), 0) * pixel_area_km2
        area_wsi_2 = wsi_class_counts.get((zone_id, feedstock_code, 2), 0) * pixel_area_km2
        area_wsi_3 = wsi_class_counts.get((zone_id, feedstock_code, 3), 0) * pixel_area_km2
        area_wsi_4 = wsi_class_counts.get((zone_id, feedstock_code, 4), 0) * pixel_area_km2
        area_wsi_5 = wsi_class_counts.get((zone_id, feedstock_code, 5), 0) * pixel_area_km2

        results.append({
            "scenario": scenario,
            selected_zone_field: zone_id_to_name[zone_id],
            "feedstock": "combined" if feedstock_code == COMBINED_CODE else feedstock_label(feedstock_code),
            "feedstock_code": feedstock_code,

            "allocated_pixels": total_pixels[key],
            "allocated_area_km2": group_area,

            "mean_WSI_1_worst_5_best": mean_wsi,
            "mean_water_risk_score_1_low_3_high": mean_risk,
            "water_risk_index_0_low_1_high": risk_index,

            "min_WSI_1_worst_5_best": min_wsi[key],
            "max_WSI_1_worst_5_best": max_wsi[key],
            "min_water_risk_score_1_low_3_high": min_risk[key],
            "max_water_risk_score_1_low_3_high": max_risk[key],

            "area_WSI_1_risk_3_km2": area_wsi_1,
            "area_WSI_2_risk_2_5_km2": area_wsi_2,
            "area_WSI_3_risk_2_km2": area_wsi_3,
            "area_WSI_4_risk_1_5_km2": area_wsi_4,
            "area_WSI_5_risk_1_km2": area_wsi_5,

            "share_WSI_1_risk_3_pct": (area_wsi_1 / group_area) * 100,
            "share_WSI_2_risk_2_5_pct": (area_wsi_2 / group_area) * 100,
            "share_WSI_3_risk_2_pct": (area_wsi_3 / group_area) * 100,
            "share_WSI_4_risk_1_5_pct": (area_wsi_4 / group_area) * 100,
            "share_WSI_5_risk_1_pct": (area_wsi_5 / group_area) * 100,

            "interpretation": interpret_water_risk_score(mean_risk)
        })

    # ========================================================
    # Add TOTAL rows by feedstock over all zones
    # ========================================================

    feedstock_codes_present = sorted(set([feedstock_code for _, feedstock_code in total_area.keys()]))

    for feedstock_code in feedstock_codes_present:
        total_area_all = 0.0
        total_pixels_all = 0
        total_weighted_wsi_all = 0.0
        total_weighted_risk_all = 0.0

        total_area_wsi = {
            1: 0.0,
            2: 0.0,
            3: 0.0,
            4: 0.0,
            5: 0.0
        }

        total_min_wsi = None
        total_max_wsi = None
        total_min_risk = None
        total_max_risk = None

        for key in total_area.keys():
            zone_id, f_code = key

            if f_code != feedstock_code:
                continue

            total_area_all += total_area[key]
            total_pixels_all += total_pixels[key]
            total_weighted_wsi_all += weighted_wsi_sum[key]
            total_weighted_risk_all += weighted_risk_sum[key]

            if total_min_wsi is None:
                total_min_wsi = min_wsi[key]
                total_max_wsi = max_wsi[key]
                total_min_risk = min_risk[key]
                total_max_risk = max_risk[key]
            else:
                total_min_wsi = min(total_min_wsi, min_wsi[key])
                total_max_wsi = max(total_max_wsi, max_wsi[key])
                total_min_risk = min(total_min_risk, min_risk[key])
                total_max_risk = max(total_max_risk, max_risk[key])

            for wsi_class in [1, 2, 3, 4, 5]:
                total_area_wsi[wsi_class] += (
                    wsi_class_counts.get((zone_id, feedstock_code, wsi_class), 0)
                    * pixel_area_km2
                )

        if total_area_all <= 0:
            continue

        total_mean_wsi = total_weighted_wsi_all / total_area_all
        total_mean_risk = total_weighted_risk_all / total_area_all
        total_risk_index = calculate_water_risk_index_0_to_1(total_mean_risk)

        results.append({
            "scenario": scenario,
            selected_zone_field: "TOTAL_BRAZIL",
            "feedstock": "combined" if feedstock_code == COMBINED_CODE else feedstock_label(feedstock_code),
            "feedstock_code": feedstock_code,

            "allocated_pixels": total_pixels_all,
            "allocated_area_km2": total_area_all,

            "mean_WSI_1_worst_5_best": total_mean_wsi,
            "mean_water_risk_score_1_low_3_high": total_mean_risk,
            "water_risk_index_0_low_1_high": total_risk_index,

            "min_WSI_1_worst_5_best": total_min_wsi,
            "max_WSI_1_worst_5_best": total_max_wsi,
            "min_water_risk_score_1_low_3_high": total_min_risk,
            "max_water_risk_score_1_low_3_high": total_max_risk,

            "area_WSI_1_risk_3_km2": total_area_wsi[1],
            "area_WSI_2_risk_2_5_km2": total_area_wsi[2],
            "area_WSI_3_risk_2_km2": total_area_wsi[3],
            "area_WSI_4_risk_1_5_km2": total_area_wsi[4],
            "area_WSI_5_risk_1_km2": total_area_wsi[5],

            "share_WSI_1_risk_3_pct": (total_area_wsi[1] / total_area_all) * 100,
            "share_WSI_2_risk_2_5_pct": (total_area_wsi[2] / total_area_all) * 100,
            "share_WSI_3_risk_2_pct": (total_area_wsi[3] / total_area_all) * 100,
            "share_WSI_4_risk_1_5_pct": (total_area_wsi[4] / total_area_all) * 100,
            "share_WSI_5_risk_1_pct": (total_area_wsi[5] / total_area_all) * 100,

            "interpretation": interpret_water_risk_score(total_mean_risk)
        })

    fieldnames = [
        "scenario",
        selected_zone_field,
        "feedstock",
        "feedstock_code",

        "allocated_pixels",
        "allocated_area_km2",

        "mean_WSI_1_worst_5_best",
        "mean_water_risk_score_1_low_3_high",
        "water_risk_index_0_low_1_high",

        "min_WSI_1_worst_5_best",
        "max_WSI_1_worst_5_best",
        "min_water_risk_score_1_low_3_high",
        "max_water_risk_score_1_low_3_high",

        "area_WSI_1_risk_3_km2",
        "area_WSI_2_risk_2_5_km2",
        "area_WSI_3_risk_2_km2",
        "area_WSI_4_risk_1_5_km2",
        "area_WSI_5_risk_1_km2",

        "share_WSI_1_risk_3_pct",
        "share_WSI_2_risk_2_5_pct",
        "share_WSI_3_risk_2_pct",
        "share_WSI_4_risk_1_5_pct",
        "share_WSI_5_risk_1_pct",

        "interpretation"
    ]

    output_csv = os.path.join(
        scenario_output_dir,
        f"water_risk_score_by_zone_feedstock_{scenario}_{run_tag}.csv"
    )

    output_csv = write_csv(
        output_csv,
        fieldnames,
        sorted(results, key=lambda d: (str(d[selected_zone_field]), str(d["feedstock"])))
    )

    unique_risk_values = get_unique_values_from_raster(water_risk_raster_path)

    print("\nUnique water risk values in raster:")
    print(unique_risk_values)

    feedstock_ds = None
    wsi_ds = None
    zones_ds = None

    return {
        "water_risk_raster": water_risk_raster_path,
        "csv": output_csv,
        "unique_risk_values": unique_risk_values
    }


# ============================================================
# COMBINE CSVS ACROSS SCENARIOS
# ============================================================

def combine_csvs(input_csvs, output_csv):
    rows_all = []
    fieldnames = None

    for path in input_csvs:
        if path is None or not os.path.exists(path):
            continue

        with open(path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)

            if fieldnames is None:
                fieldnames = reader.fieldnames

            for row in reader:
                rows_all.append(row)

    if fieldnames is None:
        print("No CSVs found to combine.")
        return None

    return write_csv(output_csv, fieldnames, rows_all)


# ============================================================
# MAIN EXECUTION
# ============================================================

def handle_missing_input(message):
    """Skip or stop according to the configured missing-file policy."""
    if SKIP_MISSING_SCENARIOS:
        print("\nWARNING:", message)
        print("Skipping scenario.")
        return True

    raise FileNotFoundError(message)


def main():
    gdal.UseExceptions()

    for path, description in [
        (WSI_RASTER_PATH, "WSI raster"),
        (ZONES_PATH, "Zones shapefile"),
    ]:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"{description} not found:\n{path}"
            )

    all_outputs = []
    run_main_tag = datetime.now().strftime(
        "%Y%m%d_%H%M%S_%f"
    )

    for scenario in SCENARIOS:
        scenario_safe = safe_scenario_name(scenario)

        scenario_output_dir = os.path.join(
            OUTPUT_DIR,
            scenario_safe
        )

        os.makedirs(
            scenario_output_dir,
            exist_ok=True
        )

        print("\n")
        print("=" * 76)
        print(f"SCENARIO: {scenario}")
        print("=" * 76)

        sugarcane_raster = find_sugarcane_raster(
            scenario
        )

        if sugarcane_raster is None:
            should_skip = handle_missing_input(
                "Could not find the final sugarcane raster for "
                f"scenario: {scenario}\n"
                "Set it in MANUAL_SUGARCANE_RASTERS if necessary."
            )

            if should_skip:
                continue

        soybean_raster = find_soybean_raster(
            scenario
        )

        if (
            scenario not in SUGARCANE_ONLY_SCENARIOS
            and soybean_raster is None
        ):
            should_skip = handle_missing_input(
                "Could not find the soybean-after-sugarcane raster for "
                f"scenario: {scenario}\n"
                "Only rasters in the new sequential downscaling folders "
                "are accepted. Set MANUAL_SOYBEAN_RASTERS if necessary."
            )

            if should_skip:
                continue

        combine_outputs = combine_sugarcane_soybean_rasters(
            scenario=scenario,
            sugarcane_raster_path=sugarcane_raster,
            soybean_raster_path=soybean_raster,
            scenario_output_dir=scenario_output_dir
        )

        wsi_outputs = apply_wsi_indicator_to_combined(
            scenario=scenario,
            combined_feedstock_raster=(
                combine_outputs["combined_feedstock_raster"]
            ),
            wsi_raster_path=WSI_RASTER_PATH,
            zones_path=ZONES_PATH,
            zone_field=ZONE_FIELD,
            scenario_output_dir=scenario_output_dir
        )

        all_outputs.append({
            "scenario": scenario,
            **combine_outputs,
            **wsi_outputs
        })

    combined_csv = os.path.join(
        OUTPUT_DIR,
        "combined_water_risk_score_by_zone_feedstock_"
        f"all_scenarios_{run_main_tag}.csv"
    )

    combined_csv = combine_csvs(
        input_csvs=[
            item["csv"]
            for item in all_outputs
        ],
        output_csv=combined_csv
    )

    print("\n")
    print("=" * 76)
    print("DONE")
    print("=" * 76)

    for item in all_outputs:
        print("\nScenario:", item["scenario"])

        print("Sugarcane raster:")
        print(item["sugarcane_raster"])

        print("Soybean raster:")
        print(
            item["soybean_raster"]
            if item["soybean_raster"] is not None
            else "Not applicable (sugarcane-only scenario)."
        )

        print("Combined binary raster:")
        print(item["combined_binary_raster"])

        print("Combined feedstock-code raster:")
        print(item["combined_feedstock_raster"])

        print("Water risk raster:")
        print(item["water_risk_raster"])

        print("Water risk CSV:")
        print(item["csv"])

        print("Areas:")
        print(
            f"  Sugarcane: "
            f"{item['sugarcane_area_km2']:,.3f} km²"
        )
        print(
            f"  Soybean:   "
            f"{item['soybean_area_km2']:,.3f} km²"
        )
        print(
            f"  Overlap:   "
            f"{item['overlap_area_km2']:,.3f} km²"
        )
        print(
            f"  Combined:  "
            f"{item['combined_area_km2']:,.3f} km²"
        )

        print("Unique water risk values:")
        print(item["unique_risk_values"])

    print("\nCombined water risk CSV:")
    print(combined_csv)
    print("=" * 76)

    return all_outputs, combined_csv


# QGIS Python Editor executes scripts through exec(), where __name__
# may not be "__main__". Keep main() direct.
main()
