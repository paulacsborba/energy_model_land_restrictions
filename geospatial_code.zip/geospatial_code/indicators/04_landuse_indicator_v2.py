# -*- coding: utf-8 -*-
# ============================================================
# LAND-USE CONFLICT RISK | NEW TWO-STAGE DOWNSCALING
# ALL SCENARIOS | SUGARCANE + SOYBEAN + COMBINED
# QGIS Python Editor
# ============================================================
#
# This version is compatible with the new downscaling workflow:
#   1) sugarcane is allocated first;
#   2) soybean is allocated only on remaining pixels;
#   3) combined is the UNION of final sugarcane and soybean allocations.
#
# Output structure:
#   outputs\combined_feedstock_landuse_conflict_indicator\<scenario>\
#
# CSV feedstock rows:
#   sugarcane  = final sugarcane allocation
#   soybean    = final soybean allocation
#   overlap    = pixels assigned to both crops, if any (diagnostic only)
#   combined   = union of sugarcane and soybean; never double-counted
#
# Scenario EPE:
#   sugarcane only; combined == sugarcane.
#
# Risk score:
#   1 = low conflict
#   2 = medium conflict
#   3 = high conflict
# ============================================================

import os
import re
import glob
import csv
from datetime import datetime

import numpy as np
from osgeo import gdal, ogr, osr

try:
    from qgis.core import QgsProject, QgsRasterLayer
    QGIS_AVAILABLE = True
except Exception:
    QGIS_AVAILABLE = False


gdal.UseExceptions()


# ============================================================
# USER CONFIGURATION
# ============================================================

BASE_DIR = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"

INTEGRATION_DIR = os.path.join(
    BASE_DIR,
    "geospatial_data",
    "integration"
)

LANDUSE_RASTER_PATH = os.path.join(
    BASE_DIR,
    r"geospatial_data\rasters\landuse\br_mapbiomes_250m_5880.tif"
)

PASTURE_VIGOR_RASTER_PATH = (
    r"C:\Users\pcsbo\OneDrive\PostDoc\NZB\mapping\biofuel"
    r"\supply_curve\sugarcane\reproject_pasture_vigor_250m.tif"
)

ZONES_PATH = (
    r"C:\Users\pcsbo\OneDrive\Doutorado\Library\Data"
    r"\shapefile\zones\zones_\zones_fixed.shp"
)

# Set manually only if automatic detection fails, e.g. "ZONE".
ZONE_FIELD = None

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    r"outputs\combined_feedstock_landuse_conflict_indicator"
)

SCENARIO_ORDER = [
    "baseline",
    "conservation",
    "governance",
    "degraded_pastures",
    "integrated",
    "scenario_epe",
]

# ----------------------------------------------------------------
# Optional exact raster paths.
# Leave None to use automatic final-raster discovery.
#
# The automatic search first checks scenario-specific final folders.
# Soybean is read only from the post-sugarcane allocation folder.
# It then falls back to a ranked recursive search only if necessary.
# ----------------------------------------------------------------
MANUAL_ALLOCATION_RASTERS = {
    "baseline": {
        "sugarcane": None,
        "soybean": None,
    },
    "conservation": {
        "sugarcane": None,
        "soybean": None,
    },
    "governance": {
        "sugarcane": None,
        "soybean": None,
    },
    "degraded_pastures": {
        "sugarcane": None,
        "soybean": None,
    },
    "integrated": {
        "sugarcane": None,
        "soybean": None,
    },
    "scenario_epe": {
        "sugarcane": None,
        "soybean": None,  # EPE is sugarcane-only by design
    },
}

# ----------------------------------------------------------------
# EXPECTED FINAL NEW-DOWNSCALING FOLDERS
# ----------------------------------------------------------------
# Sugarcane is allocated first. Soybean must come from the subsequent
# "soybean_after_sugarcane_downscaling" folder, for example:
#
#   ...\integration\scenario_conservation_soybean_after_sugarcane_downscaling\
#
# The code searches these exact scenario-specific folders FIRST, before any
# broad recursive fallback. This avoids accidentally selecting an old soybean
# downscaling raster that was produced before sugarcane pixels were locked.
# ----------------------------------------------------------------

def scenario_directory_stem(scenario):
    """Return the integration-folder stem used by the new downscaling."""
    if scenario == "scenario_epe":
        return "scenario_epe"

    return f"scenario_{scenario}"


def expected_final_allocation_directories(scenario, feedstock):
    """Return scenario-specific folders ordered from most to least preferred."""
    stem = scenario_directory_stem(scenario)

    if feedstock == "soybean":
        return [
            os.path.join(
                INTEGRATION_DIR,
                f"{stem}_soybean_after_sugarcane_downscaling_checked"
            ),
            os.path.join(
                INTEGRATION_DIR,
                f"{stem}_soybean_after_sugarcane_downscaling"
            ),
        ]

    if feedstock == "sugarcane":
        return [
            os.path.join(
                INTEGRATION_DIR,
                f"{stem}_sugarcane_direct_raster_downscaling_checked"
            ),
            os.path.join(
                INTEGRATION_DIR,
                f"{stem}_sugarcane_direct_raster_downscaling"
            ),
            os.path.join(
                INTEGRATION_DIR,
                f"{stem}_direct_raster_downscaling_checked"
            ),
            os.path.join(
                INTEGRATION_DIR,
                f"{stem}_direct_raster_downscaling"
            ),
        ]

    raise ValueError(f"Unsupported feedstock: {feedstock}")

# The script stops if sugarcane is missing in any listed scenario.
REQUIRE_SUGARCANE = True

# Soybean is mandatory for these scenarios. Remove scenarios from this set only
# when soybean demand is truly zero in that scenario.
SCENARIOS_REQUIRING_SOYBEAN = {
    "baseline",
    "conservation",
    "governance",
    "degraded_pastures",
    "integrated",
}

# New two-stage downscaling should have zero overlap. Set this False only to
# inspect a diagnostic run while preserving combined as the non-double-counted
# union of both crops.
FAIL_IF_FINAL_CROP_OVERLAP = True

BLOCK_SIZE = 1024
OUTPUT_NODATA = -9999
LOAD_OUTPUTS_TO_QGIS = False

SUGARCANE_CODE = 1
SOYBEAN_CODE = 2
OVERLAP_CODE = 3
COMBINED_CODE = 99


# ============================================================
# MAPBIOMAS LAND-USE CONFLICT CLASSIFICATION
# ============================================================

MAPBIOMAS_CONFLICT_SCORE = {
    # Natural vegetation / ecosystems
    3: 3,     # Forest formation
    4: 3,     # Savanna formation
    5: 3,     # Mangrove
    6: 3,     # Flooded forest
    11: 3,    # Wetland
    12: 3,    # Grassland / campo natural
    49: 3,    # Wooded sandbank vegetation
    50: 3,    # Herbaceous sandbank vegetation

    # Forestry
    9: 2,     # Forest plantation

    # Agriculture / farming
    15: 2,    # Pasture; refined below using pasture vigor
    18: 3,    # Agriculture
    19: 3,    # Temporary crops
    20: 2,    # Sugarcane
    21: 2,    # Mosaic agriculture-pasture
    35: 3,    # Palm oil
    36: 3,    # Perennial crops
    39: 3,    # Soybean
    40: 3,    # Rice
    41: 3,    # Other temporary crops
    46: 3,    # Coffee
    47: 3,    # Citrus
    48: 3,    # Other perennial crops
    62: 3,    # Cotton

    # Non-vegetated / other
    23: 3,    # Beach / dune / sand
    24: 3,    # Urban area
    25: 1,    # Other non-vegetated area
    29: 3,    # Rocky outcrop
    30: 3,    # Mining
    31: 3,    # Aquaculture
    32: 3,    # Salt flat
    33: 3,    # Water
}


# ============================================================
# GENERAL HELPERS
# ============================================================

def ensure_dir_writable(folder):
    os.makedirs(folder, exist_ok=True)

    test_path = os.path.join(folder, "__write_test.tmp")

    try:
        with open(test_path, "w", encoding="utf-8") as file:
            file.write("ok")

        os.remove(test_path)

    except Exception as exc:
        raise RuntimeError(
            "Output directory is not writable.\n"
            f"Directory:\n{folder}\n\n"
            f"Original error:\n{exc}"
        )


def safe_remove_file(path):
    if not os.path.exists(path):
        return path

    try:
        os.remove(path)
        return path

    except Exception:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        root, extension = os.path.splitext(path)
        alternative = f"{root}_new_{timestamp}{extension}"

        print("\nWARNING: file is locked.")
        print("Using alternative output path:")
        print(alternative)

        return alternative


def safe_remove_raster_family(path):
    sidecars = [
        path,
        path + ".aux.xml",
        path + ".ovr",
        path + ".msk",
    ]

    locked = False

    for sidecar in sidecars:
        if os.path.exists(sidecar):
            try:
                os.remove(sidecar)
            except Exception:
                locked = True

    if not locked:
        return path

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    root, extension = os.path.splitext(path)
    alternative = f"{root}_new_{timestamp}{extension}"

    print("\nWARNING: raster is locked.")
    print("Using alternative output path:")
    print(alternative)

    return alternative


def write_csv(output_csv, fieldnames, rows):
    ensure_dir_writable(os.path.dirname(output_csv))
    output_csv = safe_remove_file(output_csv)

    with open(
        output_csv,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("CSV written:")
    print(output_csv)

    return output_csv


def open_raster(path):
    dataset = gdal.Open(path, gdal.GA_ReadOnly)

    if dataset is None:
        raise FileNotFoundError(
            f"Could not open raster:\n{path}"
        )

    return dataset


def calculate_pixel_area_km2(geotransform):
    pixel_width = abs(geotransform[1])
    pixel_height = abs(geotransform[5])

    return (
        pixel_width * pixel_height
    ) / 1_000_000.0


def grids_are_equal(reference_ds, other_ds, tolerance=1e-9):
    if reference_ds.RasterXSize != other_ds.RasterXSize:
        return False

    if reference_ds.RasterYSize != other_ds.RasterYSize:
        return False

    for a, b in zip(
        reference_ds.GetGeoTransform(),
        other_ds.GetGeoTransform()
    ):
        if abs(a - b) > tolerance:
            return False

    return (
        reference_ds.GetProjection()
        == other_ds.GetProjection()
    )


def create_geotiff_like(reference_ds, output_path, dtype, nodata):
    ensure_dir_writable(os.path.dirname(output_path))
    output_path = safe_remove_raster_family(output_path)

    driver = gdal.GetDriverByName("GTiff")

    output_ds = driver.Create(
        output_path,
        reference_ds.RasterXSize,
        reference_ds.RasterYSize,
        1,
        dtype,
        options=["COMPRESS=LZW", "BIGTIFF=IF_SAFER"]
    )

    if output_ds is None:
        raise RuntimeError(
            f"Could not create raster:\n{output_path}"
        )

    output_ds.SetGeoTransform(reference_ds.GetGeoTransform())
    output_ds.SetProjection(reference_ds.GetProjection())

    output_band = output_ds.GetRasterBand(1)
    output_band.SetNoDataValue(nodata)
    output_band.Fill(nodata)

    return output_ds, output_path


def align_raster_to_reference(
    input_raster_path,
    reference_ds,
    output_path,
    output_type=gdal.GDT_Int16,
):
    """Align a categorical/allocation raster using nearest-neighbour."""

    input_ds = open_raster(input_raster_path)

    if grids_are_equal(reference_ds, input_ds):
        input_ds = None
        return input_raster_path

    gt = reference_ds.GetGeoTransform()

    xmin = gt[0]
    ymax = gt[3]
    xmax = xmin + reference_ds.RasterXSize * gt[1]
    ymin = ymax + reference_ds.RasterYSize * gt[5]

    source_nodata = input_ds.GetRasterBand(1).GetNoDataValue()

    output_path = safe_remove_raster_family(output_path)

    warp_kwargs = {
        "format": "GTiff",
        "outputBounds": (xmin, ymin, xmax, ymax),
        "width": reference_ds.RasterXSize,
        "height": reference_ds.RasterYSize,
        "dstSRS": reference_ds.GetProjection(),
        "resampleAlg": "near",
        "outputType": output_type,
        "dstNodata": OUTPUT_NODATA,
        "multithread": True,
        "creationOptions": ["COMPRESS=LZW", "BIGTIFF=IF_SAFER"],
    }

    if source_nodata is not None:
        warp_kwargs["srcNodata"] = source_nodata

    print("\nAligning raster to allocation grid:")
    print(input_raster_path)

    output_ds = gdal.Warp(
        output_path,
        input_ds,
        options=gdal.WarpOptions(**warp_kwargs)
    )

    if output_ds is None:
        raise RuntimeError(
            f"Could not align raster:\n{input_raster_path}"
        )

    output_ds.FlushCache()
    output_ds = None
    input_ds = None

    print("Aligned raster written:")
    print(output_path)

    return output_path


def add_count(dictionary, key, value):
    dictionary[key] = dictionary.get(key, 0) + int(value)


def safe_share(numerator, denominator):
    if denominator <= 0:
        return 0.0

    return 100.0 * numerator / denominator


def normalise_for_match(text):
    return re.sub(
        r"[^a-z0-9]+",
        "",
        str(text).lower()
    )


def valid_allocation_mask(array, nodata):
    mask = np.isfinite(array)
    mask &= array > 0
    mask &= array != OUTPUT_NODATA

    if nodata is not None:
        mask &= array != nodata

    return mask


# ============================================================
# FINAL NEW-DOWNSCALING RASTER DISCOVERY
# ============================================================

def candidate_score(path, scenario, feedstock):
    """Rank final allocation rasters from the new downscaling workflow."""

    filename = os.path.basename(path).lower()
    parent = os.path.dirname(path).lower()
    full = (parent + "\\" + filename).lower()

    score = 0

    # Strong preference for the final chosen allocation.
    if f"downscaled_{feedstock}_chosen" in filename:
        score += 160

    if "chosen_binary_after_sugarcane" in filename:
        score += 250

    if feedstock == "soybean" and "after_sugarcane" in full:
        score += 200

    if "chosen_potential_class" in filename:
        score += 130

    if "chosen_binary" in filename:
        score += 120

    if "final" in filename:
        score += 40

    if "checked" in parent:
        score += 20

    if feedstock in filename:
        score += 30

    if scenario in filename:
        score += 30

    if scenario in parent:
        score += 20

    # Penalise intermediate and non-allocation files.
    excluded_penalties = {
        "score_total": 1000,
        "sourceclass": 1000,
        "source_class": 1000,
        "selected_pixels": 1000,
        "summary": 800,
        "mask": 800,
        "locked": 800,
        "used_for": 800,
        "available": 700,
        "potential_area": 700,
        "allocation_check": 700,
        "validation": 700,
    }

    for token, penalty in excluded_penalties.items():
        if token in full:
            score -= penalty

    return score


def find_final_allocation_raster(scenario, feedstock):
    """
    Find the final allocation raster for one crop and scenario.

    Priority order:
      1. MANUAL_ALLOCATION_RASTERS (when explicitly provided);
      2. expected scenario-specific new-downscaling folders;
      3. broad recursive search under INTEGRATION_DIR as a fallback.

    For soybean, the expected source is always the final output of the
    second-stage allocation folder:
        scenario_<scenario>_soybean_after_sugarcane_downscaling
    """

    manual_path = MANUAL_ALLOCATION_RASTERS[scenario][feedstock]

    if manual_path is not None:
        if not os.path.exists(manual_path):
            raise FileNotFoundError(
                "Manual allocation raster not found:\n"
                f"{manual_path}"
            )

        print("\nUsing manual raster:")
        print(f"  {scenario} | {feedstock}")
        print(f"  {manual_path}")

        return manual_path

    if scenario == "scenario_epe" and feedstock == "soybean":
        print("\nScenario EPE has no soybean allocation by design.")
        return None

    # ------------------------------------------------------------
    # 1. Direct, scenario-specific folders (preferred)
    # ------------------------------------------------------------
    direct_candidates = []

    for folder in expected_final_allocation_directories(
        scenario,
        feedstock
    ):
        if not os.path.isdir(folder):
            continue

        patterns = []

        if feedstock == "soybean":
            patterns = [
                os.path.join(
                    folder,
                    f"downscaled_soybean_chosen_binary_after_sugarcane_{scenario}*.tif"
                ),
                os.path.join(
                    folder,
                    f"downscaled_soybean_chosen_potential_class_after_sugarcane_{scenario}*.tif"
                ),
                os.path.join(
                    folder,
                    f"downscaled_soybean_chosen*after_sugarcane*{scenario}*.tif"
                ),
                os.path.join(
                    folder,
                    "downscaled_soybean_chosen*after_sugarcane*.tif"
                ),
                os.path.join(
                    folder,
                    "downscaled_soybean_chosen*.tif"
                ),
            ]

        elif feedstock == "sugarcane":
            patterns = [
                os.path.join(
                    folder,
                    f"downscaled_sugarcane_chosen_potential_class_{scenario}*.tif"
                ),
                os.path.join(
                    folder,
                    f"downscaled_sugarcane_chosen_binary_{scenario}*.tif"
                ),
                os.path.join(
                    folder,
                    f"downscaled_sugarcane_chosen*{scenario}*.tif"
                ),
                os.path.join(
                    folder,
                    "downscaled_sugarcane_chosen*.tif"
                ),
            ]

        for pattern in patterns:
            direct_candidates.extend(glob.glob(pattern))

    direct_candidates = sorted(set(direct_candidates))

    if direct_candidates:
        ranked_direct = sorted(
            [
                (
                    candidate_score(path, scenario, feedstock),
                    path
                )
                for path in direct_candidates
            ],
            key=lambda item: (
                item[0],
                os.path.getmtime(item[1])
            ),
            reverse=True
        )

        print("\nPreferred new-downscaling candidates:")
        print(f"  Scenario: {scenario}")
        print(f"  Feedstock: {feedstock}")

        for rank, path in ranked_direct:
            print(f"  score={rank:4d} | {path}")

        selected = ranked_direct[0][1]

        print("\nSelected preferred final allocation raster:")
        print(selected)

        return selected

    # ------------------------------------------------------------
    # 2. Broad recursive fallback
    # ------------------------------------------------------------
    print("\nWARNING: preferred scenario-specific folder was not found.")
    print("Falling back to recursive search under integration:")

    scenario_norm = normalise_for_match(scenario)
    feedstock_norm = normalise_for_match(feedstock)

    all_tifs = glob.glob(
        os.path.join(
            INTEGRATION_DIR,
            "**",
            "*.tif"
        ),
        recursive=True
    )

    candidates = []

    for path in all_tifs:
        full_norm = normalise_for_match(path)
        filename_norm = normalise_for_match(
            os.path.basename(path)
        )

        if scenario_norm not in full_norm:
            continue

        if feedstock_norm not in filename_norm:
            continue

        if "chosen" not in filename_norm:
            continue

        # Soybean must still originate from the after-sugarcane step.
        if (
            feedstock == "soybean"
            and "aftersugarcane" not in full_norm
        ):
            continue

        ranked = candidate_score(
            path,
            scenario,
            feedstock
        )

        if ranked <= 0:
            continue

        candidates.append((ranked, path))

    candidates = sorted(
        candidates,
        key=lambda item: (
            item[0],
            os.path.getmtime(item[1])
        ),
        reverse=True
    )

    print("\nFallback candidates:")
    print(f"  Scenario: {scenario}")
    print(f"  Feedstock: {feedstock}")

    if not candidates:
        print("  None found.")
        return None

    for rank, path in candidates[:10]:
        print(f"  score={rank:4d} | {path}")

    selected = candidates[0][1]

    print("\nSelected fallback final allocation raster:")
    print(selected)

    return selected


# ============================================================
# ZONES
# ============================================================

def detect_zone_field(zones_layer):
    definition = zones_layer.GetLayerDefn()

    field_names = [
        definition.GetFieldDefn(index).GetName()
        for index in range(definition.GetFieldCount())
    ]

    print("\nAvailable zone fields:")
    print(field_names)

    if ZONE_FIELD is not None:
        if ZONE_FIELD not in field_names:
            raise KeyError(
                f"ZONE_FIELD not found: {ZONE_FIELD}\n"
                f"Available fields: {field_names}"
            )

        return ZONE_FIELD

    zone_pattern = re.compile(r"^[A-Z]{2}_Z\d+$")

    for field_name in field_names:
        zones_layer.ResetReading()

        checked = 0
        matched = 0

        for feature in zones_layer:
            value = str(feature.GetField(field_name)).strip()

            checked += 1

            if zone_pattern.match(value):
                matched += 1

            if checked >= 50:
                break

        if checked > 0 and matched >= max(1, checked * 0.5):
            return field_name

    for field_name in [
        "ZONE", "zone", "Zone",
        "NAME", "name", "Name",
        "ID", "id", "Id",
    ]:
        if field_name in field_names:
            return field_name

    raise RuntimeError(
        "Could not detect the zone field.\n"
        f"Fields: {field_names}"
    )


def create_zones_raster(reference_ds, output_path):
    zones_ds = ogr.Open(ZONES_PATH)

    if zones_ds is None:
        raise FileNotFoundError(
            f"Could not open zones shapefile:\n{ZONES_PATH}"
        )

    zones_layer = zones_ds.GetLayer()

    selected_zone_field = detect_zone_field(zones_layer)

    raster_srs = osr.SpatialReference()
    raster_srs.ImportFromWkt(reference_ds.GetProjection())

    zones_srs = zones_layer.GetSpatialRef()

    coordinate_transform = None

    if (
        zones_srs is not None
        and not zones_srs.IsSame(raster_srs)
    ):
        coordinate_transform = osr.CoordinateTransformation(
            zones_srs,
            raster_srs
        )

        print("Reprojecting zones in memory.")

    zone_name_to_id = {}
    zone_id_to_name = {}
    next_id = 1

    zones_layer.ResetReading()

    for feature in zones_layer:
        zone_name = feature.GetField(selected_zone_field)

        if zone_name not in zone_name_to_id:
            zone_name_to_id[zone_name] = next_id
            zone_id_to_name[next_id] = zone_name
            next_id += 1

    memory_driver = ogr.GetDriverByName("Memory")
    memory_ds = memory_driver.CreateDataSource("memory_zones")

    memory_layer = memory_ds.CreateLayer(
        "zones_numeric",
        srs=raster_srs,
        geom_type=zones_layer.GetGeomType()
    )

    memory_layer.CreateField(
        ogr.FieldDefn("zone_id", ogr.OFTInteger)
    )

    memory_definition = memory_layer.GetLayerDefn()

    zones_layer.ResetReading()

    for feature in zones_layer:
        geometry = feature.GetGeometryRef()

        if geometry is None:
            continue

        geometry_copy = geometry.Clone()

        if coordinate_transform is not None:
            geometry_copy.Transform(coordinate_transform)

        output_feature = ogr.Feature(memory_definition)

        output_feature.SetField(
            "zone_id",
            zone_name_to_id[
                feature.GetField(selected_zone_field)
            ]
        )

        output_feature.SetGeometry(geometry_copy)
        memory_layer.CreateFeature(output_feature)
        output_feature = None

    zones_raster_ds, output_path = create_geotiff_like(
        reference_ds,
        output_path,
        gdal.GDT_Int32,
        0
    )

    zones_band = zones_raster_ds.GetRasterBand(1)
    zones_band.Fill(0)

    gdal.RasterizeLayer(
        zones_raster_ds,
        [1],
        memory_layer,
        options=["ATTRIBUTE=zone_id"]
    )

    zones_band.FlushCache()
    zones_raster_ds.FlushCache()

    zones_raster_ds = None
    memory_ds = None
    zones_ds = None

    print("Zones raster written:")
    print(output_path)

    return output_path, zone_id_to_name, selected_zone_field


# ============================================================
# LAND-USE CONFLICT LOGIC
# ============================================================

def classify_landuse_conflict(landuse_array, pasture_array):
    """
    MapBiomas conflict score:
      1 = low, 2 = medium, 3 = high.

    Pasture refinement:
      MapBiomas 15 + vigor 1/2 -> 1
      MapBiomas 15 + vigor 3   -> 2
    """
    score = np.full(
        landuse_array.shape,
        OUTPUT_NODATA,
        dtype=np.int16
    )

    for class_value, risk_value in MAPBIOMAS_CONFLICT_SCORE.items():
        score[landuse_array == class_value] = risk_value

    pasture_mask = landuse_array == 15

    valid_vigor = np.isfinite(pasture_array)
    valid_vigor &= pasture_array != OUTPUT_NODATA
    valid_vigor &= pasture_array > 0

    low_vigor = (
        pasture_mask
        & valid_vigor
        & ((pasture_array == 1) | (pasture_array == 2))
    )

    high_vigor = (
        pasture_mask
        & valid_vigor
        & (pasture_array == 3)
    )

    score[low_vigor] = 1
    score[high_vigor] = 2

    return score


def feedstock_label(feedstock_code):
    labels = {
        SUGARCANE_CODE: "sugarcane",
        SOYBEAN_CODE: "soybean",
        OVERLAP_CODE: "overlap",
        COMBINED_CODE: "combined",
    }

    return labels.get(feedstock_code, "none")


def risk_label(score):
    labels = {
        1: "low conflict",
        2: "medium conflict",
        3: "high conflict",
    }

    return labels.get(int(score), "nodata")


def interpret_conflict_score(mean_score):
    if not np.isfinite(mean_score):
        return "no classified area"

    if mean_score >= 2.5:
        return "high land-use conflict dominated"

    if mean_score >= 1.5:
        return "mixed or medium land-use conflict dominated"

    return "low land-use conflict dominated"


# ============================================================
# STATISTICS
# ============================================================

def update_statistics_for_mask(
    mask,
    feedstock_code,
    zones_array,
    score_array,
    landuse_array,
    pasture_array,
    valid_classification,
    raw_pixels_by_zone_feedstock,
    classified_pixels_by_zone_feedstock,
    score_counts,
    weighted_score_sums,
    min_scores,
    max_scores,
    pasture_vigor_counts,
    landuse_class_counts,
):
    """
    Update zonal statistics for a physical crop mask.

    The combined mask is processed once as a union, so it is never the sum of
    potentially overlapping sugarcane and soybean layers.
    """

    valid_zone = zones_array > 0

    raw_mask = mask & valid_zone

    if np.any(raw_mask):
        raw_zones = zones_array[raw_mask].astype(np.int32)

        unique_zones, raw_counts = np.unique(
            raw_zones,
            return_counts=True
        )

        for zone_id, pixel_count in zip(unique_zones, raw_counts):
            add_count(
                raw_pixels_by_zone_feedstock,
                (int(zone_id), feedstock_code),
                int(pixel_count)
            )

    classified_mask = raw_mask & valid_classification

    if not np.any(classified_mask):
        return

    selected_zones = zones_array[classified_mask].astype(np.int32)
    selected_scores = score_array[classified_mask].astype(np.int16)
    selected_landuse = landuse_array[classified_mask].astype(np.int16)
    selected_pasture = pasture_array[classified_mask].astype(np.int16)

    unique_zones, classified_counts = np.unique(
        selected_zones,
        return_counts=True
    )

    for zone_id, pixel_count in zip(unique_zones, classified_counts):
        zone_id = int(zone_id)
        pixel_count = int(pixel_count)

        add_count(
            classified_pixels_by_zone_feedstock,
            (zone_id, feedstock_code),
            pixel_count
        )

        zone_scores = selected_scores[selected_zones == zone_id]

        weighted_score_sums[(zone_id, feedstock_code)] = (
            weighted_score_sums.get(
                (zone_id, feedstock_code),
                0.0
            )
            + float(np.sum(zone_scores))
        )

        current_min = int(np.min(zone_scores))
        current_max = int(np.max(zone_scores))

        min_scores[(zone_id, feedstock_code)] = min(
            min_scores.get(
                (zone_id, feedstock_code),
                current_min
            ),
            current_min
        )

        max_scores[(zone_id, feedstock_code)] = max(
            max_scores.get(
                (zone_id, feedstock_code),
                current_max
            ),
            current_max
        )

    zone_score_pairs = np.column_stack(
        (selected_zones, selected_scores)
    )

    unique_pairs, pair_counts = np.unique(
        zone_score_pairs,
        axis=0,
        return_counts=True
    )

    for (zone_id, score), pixel_count in zip(
        unique_pairs,
        pair_counts
    ):
        add_count(
            score_counts,
            (
                int(zone_id),
                feedstock_code,
                int(score)
            ),
            int(pixel_count)
        )

    zone_landuse_pairs = np.column_stack(
        (selected_zones, selected_landuse)
    )

    unique_landuse_pairs, landuse_counts = np.unique(
        zone_landuse_pairs,
        axis=0,
        return_counts=True
    )

    for (zone_id, landuse_class), pixel_count in zip(
        unique_landuse_pairs,
        landuse_counts
    ):
        add_count(
            landuse_class_counts,
            (
                int(zone_id),
                feedstock_code,
                int(landuse_class)
            ),
            int(pixel_count)
        )

    pasture_mask = (
        (selected_landuse == 15)
        & np.isin(selected_pasture, [1, 2, 3])
    )

    if np.any(pasture_mask):
        pasture_pairs = np.column_stack(
            (
                selected_zones[pasture_mask],
                selected_pasture[pasture_mask]
            )
        )

        unique_pasture_pairs, pasture_counts = np.unique(
            pasture_pairs,
            axis=0,
            return_counts=True
        )

        for (zone_id, vigor), pixel_count in zip(
            unique_pasture_pairs,
            pasture_counts
        ):
            add_count(
                pasture_vigor_counts,
                (
                    int(zone_id),
                    feedstock_code,
                    int(vigor)
                ),
                int(pixel_count)
            )


def summary_fieldnames(zone_field):
    return [
        "scenario",
        zone_field,
        "feedstock",
        "feedstock_code",

        # Legacy-compatible classified allocation fields:
        "allocated_pixels",
        "allocated_area_km2",
        "total_allocated_area_km2",

        # Explicit raw/allocation-mask fields:
        "raw_allocated_pixels",
        "raw_allocated_area_km2",
        "unclassified_allocated_area_km2",

        "mean_landuse_conflict_score_1_low_3_high",
        "landuse_conflict_index_0_low_1_high",
        "min_landuse_conflict_score_1_low_3_high",
        "max_landuse_conflict_score_1_low_3_high",

        "area_low_conflict_score_1_km2",
        "area_medium_conflict_score_2_km2",
        "area_high_conflict_score_3_km2",

        "share_low_conflict_score_1_pct",
        "share_medium_conflict_score_2_pct",
        "share_high_conflict_score_3_pct",

        "pasture_low_vigor_area_km2",
        "pasture_medium_vigor_area_km2",
        "pasture_high_vigor_area_km2",

        "interpretation",
    ]


def build_summary_row(
    scenario,
    zone_field,
    zone_name,
    feedstock_code,
    raw_pixels,
    classified_pixels,
    score_counts_for_group,
    weighted_score_sum,
    min_score,
    max_score,
    pasture_counts_for_group,
    pixel_area_km2,
):
    raw_area = raw_pixels * pixel_area_km2
    classified_area = classified_pixels * pixel_area_km2

    area_low = (
        score_counts_for_group.get(1, 0)
        * pixel_area_km2
    )
    area_medium = (
        score_counts_for_group.get(2, 0)
        * pixel_area_km2
    )
    area_high = (
        score_counts_for_group.get(3, 0)
        * pixel_area_km2
    )

    mean_score = (
        weighted_score_sum / classified_pixels
        if classified_pixels > 0
        else np.nan
    )

    normalized_index = (
        (mean_score - 1.0) / 2.0
        if np.isfinite(mean_score)
        else np.nan
    )

    return {
        "scenario": scenario,
        zone_field: zone_name,
        "feedstock": feedstock_label(feedstock_code),
        "feedstock_code": feedstock_code,

        "allocated_pixels": classified_pixels,
        "allocated_area_km2": classified_area,
        "total_allocated_area_km2": classified_area,

        "raw_allocated_pixels": raw_pixels,
        "raw_allocated_area_km2": raw_area,
        "unclassified_allocated_area_km2": (
            raw_area - classified_area
        ),

        "mean_landuse_conflict_score_1_low_3_high": mean_score,
        "landuse_conflict_index_0_low_1_high": normalized_index,
        "min_landuse_conflict_score_1_low_3_high": min_score,
        "max_landuse_conflict_score_1_low_3_high": max_score,

        "area_low_conflict_score_1_km2": area_low,
        "area_medium_conflict_score_2_km2": area_medium,
        "area_high_conflict_score_3_km2": area_high,

        "share_low_conflict_score_1_pct": safe_share(
            area_low,
            classified_area
        ),
        "share_medium_conflict_score_2_pct": safe_share(
            area_medium,
            classified_area
        ),
        "share_high_conflict_score_3_pct": safe_share(
            area_high,
            classified_area
        ),

        "pasture_low_vigor_area_km2": (
            pasture_counts_for_group.get(1, 0)
            * pixel_area_km2
        ),
        "pasture_medium_vigor_area_km2": (
            pasture_counts_for_group.get(2, 0)
            * pixel_area_km2
        ),
        "pasture_high_vigor_area_km2": (
            pasture_counts_for_group.get(3, 0)
            * pixel_area_km2
        ),

        "interpretation": interpret_conflict_score(mean_score),
    }


# ============================================================
# OUTPUT LEGENDS AND COMBINED CSV
# ============================================================

def write_map_legend(output_csv):
    rows = []

    for feedstock_code in [
        SUGARCANE_CODE,
        SOYBEAN_CODE,
        OVERLAP_CODE,
    ]:
        for score in [1, 2, 3]:
            rows.append({
                "map_code": feedstock_code * 100 + score,
                "feedstock_code": feedstock_code,
                "feedstock": feedstock_label(feedstock_code),
                "landuse_conflict_score": score,
                "risk_label": risk_label(score),
            })

    return write_csv(
        output_csv,
        [
            "map_code",
            "feedstock_code",
            "feedstock",
            "landuse_conflict_score",
            "risk_label",
        ],
        rows
    )


def combine_csvs(input_csvs, output_csv):
    rows_all = []
    fieldnames = None

    for csv_path in input_csvs:
        if not os.path.exists(csv_path):
            continue

        with open(
            csv_path,
            "r",
            encoding="utf-8-sig"
        ) as file:
            reader = csv.DictReader(file)

            if fieldnames is None:
                fieldnames = reader.fieldnames

            rows_all.extend(reader)

    if fieldnames is None:
        print("\nNo scenario CSVs were available to combine.")
        return None

    return write_csv(
        output_csv,
        fieldnames,
        rows_all
    )


# ============================================================
# SCENARIO PROCESSING
# ============================================================

def process_scenario(
    scenario,
    sugarcane_raster_path,
    soybean_raster_path,
):
    """
    Apply land-use-conflict classification over the final crop-allocation
    rasters from the new downscaling workflow.
    """

    print("\n" + "=" * 86)
    print(f"LAND-USE CONFLICT | NEW DOWNSCALING | {scenario.upper()}")
    print("=" * 86)

    if sugarcane_raster_path is None and soybean_raster_path is None:
        raise FileNotFoundError(
            f"No final allocation raster found for '{scenario}'."
        )

    scenario_output_dir = os.path.join(
        OUTPUT_DIR,
        scenario
    )
    ensure_dir_writable(scenario_output_dir)

    run_tag = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    # Sugarcane is the preferred grid reference. EPE uses it exclusively.
    reference_path = (
        sugarcane_raster_path
        if sugarcane_raster_path is not None
        else soybean_raster_path
    )

    reference_ds = open_raster(reference_path)

    # Align crop rasters to one final-allocation grid only when required.
    sugarcane_aligned_path = None
    soybean_aligned_path = None

    if sugarcane_raster_path is not None:
        sugarcane_aligned_path = align_raster_to_reference(
            sugarcane_raster_path,
            reference_ds,
            os.path.join(
                scenario_output_dir,
                f"aligned_final_sugarcane_allocation_{scenario}_{run_tag}.tif"
            ),
            output_type=gdal.GDT_Int16
        )

    if soybean_raster_path is not None:
        soybean_aligned_path = align_raster_to_reference(
            soybean_raster_path,
            reference_ds,
            os.path.join(
                scenario_output_dir,
                f"aligned_final_soybean_allocation_{scenario}_{run_tag}.tif"
            ),
            output_type=gdal.GDT_Int16
        )

    sugarcane_ds = (
        open_raster(sugarcane_aligned_path)
        if sugarcane_aligned_path is not None
        else None
    )

    soybean_ds = (
        open_raster(soybean_aligned_path)
        if soybean_aligned_path is not None
        else None
    )

    rows = reference_ds.RasterYSize
    cols = reference_ds.RasterXSize

    pixel_area_km2 = calculate_pixel_area_km2(
        reference_ds.GetGeoTransform()
    )

    print("\nInput allocation rasters:")
    print(f"  Sugarcane: {sugarcane_raster_path}")
    print(f"  Soybean:   {soybean_raster_path}")
    print(f"  Grid:      {cols} columns x {rows} rows")
    print(f"  Pixel area: {pixel_area_km2:.8f} km²")

    aligned_landuse_path = align_raster_to_reference(
        LANDUSE_RASTER_PATH,
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"aligned_mapbiomas_landuse_{scenario}_{run_tag}.tif"
        ),
        output_type=gdal.GDT_Int16
    )

    aligned_pasture_path = align_raster_to_reference(
        PASTURE_VIGOR_RASTER_PATH,
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"aligned_pasture_vigor_{scenario}_{run_tag}.tif"
        ),
        output_type=gdal.GDT_Int16
    )

    zones_raster_path, zone_id_to_name, selected_zone_field = (
        create_zones_raster(
            reference_ds,
            os.path.join(
                scenario_output_dir,
                f"zones_aligned_to_landuse_conflict_{scenario}_{run_tag}.tif"
            )
        )
    )

    landuse_ds = open_raster(aligned_landuse_path)
    pasture_ds = open_raster(aligned_pasture_path)
    zones_ds = open_raster(zones_raster_path)

    sugarcane_band = (
        sugarcane_ds.GetRasterBand(1)
        if sugarcane_ds is not None
        else None
    )

    soybean_band = (
        soybean_ds.GetRasterBand(1)
        if soybean_ds is not None
        else None
    )

    sugarcane_nodata = (
        sugarcane_band.GetNoDataValue()
        if sugarcane_band is not None
        else None
    )

    soybean_nodata = (
        soybean_band.GetNoDataValue()
        if soybean_band is not None
        else None
    )

    landuse_band = landuse_ds.GetRasterBand(1)
    pasture_band = pasture_ds.GetRasterBand(1)
    zones_band = zones_ds.GetRasterBand(1)

    landuse_nodata = landuse_band.GetNoDataValue()

    # --------------------------------------------------------
    # Output rasters
    # --------------------------------------------------------

    binary_ds, binary_path = create_geotiff_like(
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"combined_feedstocks_binary_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Byte,
        0
    )

    feedstock_ds, feedstock_path = create_geotiff_like(
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"combined_feedstocks_code_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Byte,
        0
    )

    raw_ds, raw_path = create_geotiff_like(
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"raw_mapbiomas_class_combined_feedstocks_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Int16,
        OUTPUT_NODATA
    )

    conflict_ds, conflict_path = create_geotiff_like(
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"landuse_conflict_score_1_low_3_high_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Int16,
        OUTPUT_NODATA
    )

    map_ds, map_path = create_geotiff_like(
        reference_ds,
        os.path.join(
            scenario_output_dir,
            f"feedstock_landuse_conflict_risk_map_code_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Int16,
        OUTPUT_NODATA
    )

    binary_band = binary_ds.GetRasterBand(1)
    feedstock_band = feedstock_ds.GetRasterBand(1)
    raw_band = raw_ds.GetRasterBand(1)
    conflict_band = conflict_ds.GetRasterBand(1)
    map_band = map_ds.GetRasterBand(1)

    # --------------------------------------------------------
    # Statistics dictionaries
    # --------------------------------------------------------

    raw_pixels_by_zone_feedstock = {}
    classified_pixels_by_zone_feedstock = {}
    score_counts = {}
    weighted_score_sums = {}
    min_scores = {}
    max_scores = {}
    pasture_vigor_counts = {}
    landuse_class_counts = {}

    physical_pixels = {
        "sugarcane": 0,
        "soybean": 0,
        "overlap": 0,
        "combined": 0,
    }

    classified_combined_pixels = 0

    print("\nClassifying conflict risk and aggregating zonal results...")

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(BLOCK_SIZE, rows - y)

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(BLOCK_SIZE, cols - x)

            if sugarcane_band is not None:
                sugarcane_array = sugarcane_band.ReadAsArray(
                    x, y, xsize, ysize
                ).astype(float)
                sugarcane_mask = valid_allocation_mask(
                    sugarcane_array,
                    sugarcane_nodata
                )
            else:
                sugarcane_mask = np.zeros(
                    (ysize, xsize),
                    dtype=bool
                )

            if soybean_band is not None:
                soybean_array = soybean_band.ReadAsArray(
                    x, y, xsize, ysize
                ).astype(float)
                soybean_mask = valid_allocation_mask(
                    soybean_array,
                    soybean_nodata
                )
            else:
                soybean_mask = np.zeros(
                    (ysize, xsize),
                    dtype=bool
                )

            overlap_mask = sugarcane_mask & soybean_mask
            combined_mask = sugarcane_mask | soybean_mask

            physical_pixels["sugarcane"] += int(
                np.sum(sugarcane_mask)
            )
            physical_pixels["soybean"] += int(
                np.sum(soybean_mask)
            )
            physical_pixels["overlap"] += int(
                np.sum(overlap_mask)
            )
            physical_pixels["combined"] += int(
                np.sum(combined_mask)
            )

            landuse_array = landuse_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            pasture_array = pasture_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(float)

            zones_array = zones_band.ReadAsArray(
                x, y, xsize, ysize
            ).astype(np.int32)

            valid_landuse = np.isfinite(landuse_array)
            valid_landuse &= landuse_array > 0
            valid_landuse &= landuse_array != OUTPUT_NODATA

            if landuse_nodata is not None:
                valid_landuse &= landuse_array != landuse_nodata

            score_array = classify_landuse_conflict(
                landuse_array,
                pasture_array
            )

            valid_score = score_array >= 1
            valid_score &= score_array <= 3
            valid_score &= score_array != OUTPUT_NODATA

            valid_classification = (
                valid_landuse & valid_score
            )

            # Output 1: binary union of crops.
            binary_array = np.zeros(
                (ysize, xsize),
                dtype=np.uint8
            )
            binary_array[combined_mask] = 1
            binary_band.WriteArray(binary_array, x, y)

            # Output 2: feedstock allocation code.
            feedstock_array = np.zeros(
                (ysize, xsize),
                dtype=np.uint8
            )
            feedstock_array[
                sugarcane_mask & ~soybean_mask
            ] = SUGARCANE_CODE
            feedstock_array[
                soybean_mask & ~sugarcane_mask
            ] = SOYBEAN_CODE
            feedstock_array[
                overlap_mask
            ] = OVERLAP_CODE
            feedstock_band.WriteArray(feedstock_array, x, y)

            # Output 3: raw MapBiomas class over allocated union.
            raw_output = np.full(
                (ysize, xsize),
                OUTPUT_NODATA,
                dtype=np.int16
            )
            valid_raw = combined_mask & valid_landuse
            raw_output[valid_raw] = landuse_array[
                valid_raw
            ].astype(np.int16)
            raw_band.WriteArray(raw_output, x, y)

            # Output 4: conflict score over allocated union.
            conflict_output = np.full(
                (ysize, xsize),
                OUTPUT_NODATA,
                dtype=np.int16
            )
            valid_union = combined_mask & valid_classification
            conflict_output[valid_union] = score_array[
                valid_union
            ].astype(np.int16)
            conflict_band.WriteArray(conflict_output, x, y)

            # Output 5: feedstock x risk map code.
            map_output = np.full(
                (ysize, xsize),
                OUTPUT_NODATA,
                dtype=np.int16
            )
            map_output[valid_union] = (
                feedstock_array[valid_union].astype(np.int16) * 100
                + score_array[valid_union].astype(np.int16)
            )
            map_band.WriteArray(map_output, x, y)

            # Zonal statistics by crop / overlap / non-double-counted combined.
            category_masks = {
                SUGARCANE_CODE: sugarcane_mask,
                SOYBEAN_CODE: soybean_mask,
                OVERLAP_CODE: overlap_mask,
                COMBINED_CODE: combined_mask,
            }

            for feedstock_code, category_mask in category_masks.items():
                if not np.any(category_mask):
                    continue

                update_statistics_for_mask(
                    mask=category_mask,
                    feedstock_code=feedstock_code,
                    zones_array=zones_array,
                    score_array=score_array,
                    landuse_array=landuse_array,
                    pasture_array=pasture_array,
                    valid_classification=valid_classification,
                    raw_pixels_by_zone_feedstock=(
                        raw_pixels_by_zone_feedstock
                    ),
                    classified_pixels_by_zone_feedstock=(
                        classified_pixels_by_zone_feedstock
                    ),
                    score_counts=score_counts,
                    weighted_score_sums=weighted_score_sums,
                    min_scores=min_scores,
                    max_scores=max_scores,
                    pasture_vigor_counts=pasture_vigor_counts,
                    landuse_class_counts=landuse_class_counts,
                )

            classified_combined_pixels += int(
                np.sum(valid_union & (zones_array > 0))
            )

        print(
            f"Processed row "
            f"{min(y + BLOCK_SIZE, rows)} of {rows}"
        )

    for dataset in [
        binary_ds,
        feedstock_ds,
        raw_ds,
        conflict_ds,
        map_ds,
    ]:
        dataset.FlushCache()

    binary_ds = None
    feedstock_ds = None
    raw_ds = None
    conflict_ds = None
    map_ds = None

    # --------------------------------------------------------
    # Mandatory two-stage allocation check
    # --------------------------------------------------------

    overlap_area_km2 = (
        physical_pixels["overlap"]
        * pixel_area_km2
    )

    if physical_pixels["overlap"] > 0:
        message = (
            "\nFINAL-ALLOCATION OVERLAP DETECTED.\n"
            f"Scenario: {scenario}\n"
            f"Overlap area: {overlap_area_km2:,.4f} km²\n"
            "The new two-stage downscaling should allocate soybean only "
            "outside final sugarcane pixels."
        )

        if FAIL_IF_FINAL_CROP_OVERLAP:
            raise RuntimeError(message)

        print("WARNING:", message)

    # --------------------------------------------------------
    # Build by-zone summary and distribution rows
    # --------------------------------------------------------

    summary_rows = []
    distribution_rows = []
    landuse_distribution_rows = []

    all_zone_feedstock_keys = sorted(
        raw_pixels_by_zone_feedstock.keys()
    )

    for zone_id, feedstock_code in all_zone_feedstock_keys:
        raw_pixels = raw_pixels_by_zone_feedstock.get(
            (zone_id, feedstock_code),
            0
        )

        classified_pixels = classified_pixels_by_zone_feedstock.get(
            (zone_id, feedstock_code),
            0
        )

        score_counts_for_group = {
            score: score_counts.get(
                (zone_id, feedstock_code, score),
                0
            )
            for score in [1, 2, 3]
        }

        pasture_counts_for_group = {
            vigor: pasture_vigor_counts.get(
                (zone_id, feedstock_code, vigor),
                0
            )
            for vigor in [1, 2, 3]
        }

        summary_rows.append(
            build_summary_row(
                scenario=scenario,
                zone_field=selected_zone_field,
                zone_name=zone_id_to_name[zone_id],
                feedstock_code=feedstock_code,
                raw_pixels=raw_pixels,
                classified_pixels=classified_pixels,
                score_counts_for_group=score_counts_for_group,
                weighted_score_sum=weighted_score_sums.get(
                    (zone_id, feedstock_code),
                    0.0
                ),
                min_score=min_scores.get(
                    (zone_id, feedstock_code),
                    np.nan
                ),
                max_score=max_scores.get(
                    (zone_id, feedstock_code),
                    np.nan
                ),
                pasture_counts_for_group=pasture_counts_for_group,
                pixel_area_km2=pixel_area_km2,
            )
        )

        classified_area = classified_pixels * pixel_area_km2

        for score in [1, 2, 3]:
            pixels = score_counts_for_group[score]
            area = pixels * pixel_area_km2

            distribution_rows.append({
                "scenario": scenario,
                selected_zone_field: zone_id_to_name[zone_id],
                "feedstock": feedstock_label(feedstock_code),
                "feedstock_code": feedstock_code,
                "landuse_conflict_score": score,
                "risk_label": risk_label(score),
                "pixel_count": pixels,
                "area_km2": area,
                "total_allocated_area_group_km2": classified_area,
                "percentage_in_group": safe_share(
                    area,
                    classified_area
                ),
            })

        for (current_zone_id, current_feedstock_code, landuse_class), pixels in (
            landuse_class_counts.items()
        ):
            if current_zone_id != zone_id:
                continue

            if current_feedstock_code != feedstock_code:
                continue

            landuse_distribution_rows.append({
                "scenario": scenario,
                selected_zone_field: zone_id_to_name[zone_id],
                "feedstock": feedstock_label(feedstock_code),
                "feedstock_code": feedstock_code,
                "mapbiomas_class": landuse_class,
                "pixel_count": pixels,
                "area_km2": pixels * pixel_area_km2,
            })

    # --------------------------------------------------------
    # TOTAL_BRAZIL rows
    # --------------------------------------------------------

    for feedstock_code in [
        SUGARCANE_CODE,
        SOYBEAN_CODE,
        OVERLAP_CODE,
        COMBINED_CODE,
    ]:
        total_raw_pixels = sum(
            pixels
            for (zone_id, code), pixels in raw_pixels_by_zone_feedstock.items()
            if code == feedstock_code
        )

        if total_raw_pixels <= 0:
            continue

        total_classified_pixels = sum(
            pixels
            for (zone_id, code), pixels in (
                classified_pixels_by_zone_feedstock.items()
            )
            if code == feedstock_code
        )

        total_score_counts = {
            score: sum(
                pixels
                for (zone_id, code, current_score), pixels in score_counts.items()
                if code == feedstock_code and current_score == score
            )
            for score in [1, 2, 3]
        }

        total_pasture_counts = {
            vigor: sum(
                pixels
                for (zone_id, code, current_vigor), pixels in (
                    pasture_vigor_counts.items()
                )
                if code == feedstock_code and current_vigor == vigor
            )
            for vigor in [1, 2, 3]
        }

        total_weighted_sum = sum(
            value
            for (zone_id, code), value in weighted_score_sums.items()
            if code == feedstock_code
        )

        all_min_scores = [
            value
            for (zone_id, code), value in min_scores.items()
            if code == feedstock_code
        ]

        all_max_scores = [
            value
            for (zone_id, code), value in max_scores.items()
            if code == feedstock_code
        ]

        summary_rows.append(
            build_summary_row(
                scenario=scenario,
                zone_field=selected_zone_field,
                zone_name="TOTAL_BRAZIL",
                feedstock_code=feedstock_code,
                raw_pixels=total_raw_pixels,
                classified_pixels=total_classified_pixels,
                score_counts_for_group=total_score_counts,
                weighted_score_sum=total_weighted_sum,
                min_score=(
                    min(all_min_scores)
                    if all_min_scores
                    else np.nan
                ),
                max_score=(
                    max(all_max_scores)
                    if all_max_scores
                    else np.nan
                ),
                pasture_counts_for_group=total_pasture_counts,
                pixel_area_km2=pixel_area_km2,
            )
        )

        classified_area = (
            total_classified_pixels
            * pixel_area_km2
        )

        for score in [1, 2, 3]:
            pixels = total_score_counts[score]
            area = pixels * pixel_area_km2

            distribution_rows.append({
                "scenario": scenario,
                selected_zone_field: "TOTAL_BRAZIL",
                "feedstock": feedstock_label(feedstock_code),
                "feedstock_code": feedstock_code,
                "landuse_conflict_score": score,
                "risk_label": risk_label(score),
                "pixel_count": pixels,
                "area_km2": area,
                "total_allocated_area_group_km2": classified_area,
                "percentage_in_group": safe_share(
                    area,
                    classified_area
                ),
            })

        total_landuse_counts = {}

        for (zone_id, code, landuse_class), pixels in landuse_class_counts.items():
            if code != feedstock_code:
                continue

            total_landuse_counts[landuse_class] = (
                total_landuse_counts.get(landuse_class, 0)
                + pixels
            )

        for landuse_class, pixels in sorted(
            total_landuse_counts.items()
        ):
            landuse_distribution_rows.append({
                "scenario": scenario,
                selected_zone_field: "TOTAL_BRAZIL",
                "feedstock": feedstock_label(feedstock_code),
                "feedstock_code": feedstock_code,
                "mapbiomas_class": landuse_class,
                "pixel_count": pixels,
                "area_km2": pixels * pixel_area_km2,
            })

    # --------------------------------------------------------
    # Integrity checks
    # --------------------------------------------------------

    zonal_combined_classified = sum(
        pixels
        for (zone_id, code), pixels in (
            classified_pixels_by_zone_feedstock.items()
        )
        if code == COMBINED_CODE
    )

    if zonal_combined_classified != classified_combined_pixels:
        raise RuntimeError(
            "Combined classified-pixel mismatch between zonal and block totals.\n"
            f"Zonal total: {zonal_combined_classified}\n"
            f"Block total: {classified_combined_pixels}"
        )

    summary_rows = sorted(
        summary_rows,
        key=lambda row: (
            str(row[selected_zone_field]),
            int(row["feedstock_code"])
        )
    )

    distribution_rows = sorted(
        distribution_rows,
        key=lambda row: (
            str(row[selected_zone_field]),
            int(row["feedstock_code"]),
            int(row["landuse_conflict_score"])
        )
    )

    landuse_distribution_rows = sorted(
        landuse_distribution_rows,
        key=lambda row: (
            str(row[selected_zone_field]),
            int(row["feedstock_code"]),
            int(row["mapbiomas_class"])
        )
    )

    # --------------------------------------------------------
    # Write outputs
    # --------------------------------------------------------

    legend_csv = write_map_legend(
        os.path.join(
            scenario_output_dir,
            f"feedstock_landuse_conflict_risk_map_legend_{scenario}_{run_tag}.csv"
        )
    )

    distribution_csv = write_csv(
        os.path.join(
            scenario_output_dir,
            f"landuse_conflict_distribution_by_zone_feedstock_{scenario}_{run_tag}.csv"
        ),
        [
            "scenario",
            selected_zone_field,
            "feedstock",
            "feedstock_code",
            "landuse_conflict_score",
            "risk_label",
            "pixel_count",
            "area_km2",
            "total_allocated_area_group_km2",
            "percentage_in_group",
        ],
        distribution_rows
    )

    landuse_distribution_csv = write_csv(
        os.path.join(
            scenario_output_dir,
            f"mapbiomas_distribution_by_zone_feedstock_{scenario}_{run_tag}.csv"
        ),
        [
            "scenario",
            selected_zone_field,
            "feedstock",
            "feedstock_code",
            "mapbiomas_class",
            "pixel_count",
            "area_km2",
        ],
        landuse_distribution_rows
    )

    risk_csv = write_csv(
        os.path.join(
            scenario_output_dir,
            f"landuse_conflict_risk_score_by_zone_feedstock_{scenario}_{run_tag}.csv"
        ),
        summary_fieldnames(selected_zone_field),
        summary_rows
    )

    manifest_csv = write_csv(
        os.path.join(
            scenario_output_dir,
            f"allocation_input_manifest_{scenario}_{run_tag}.csv"
        ),
        [
            "scenario",
            "feedstock",
            "input_raster",
            "physical_allocated_pixels",
            "physical_allocated_area_km2",
        ],
        [
            {
                "scenario": scenario,
                "feedstock": "sugarcane",
                "input_raster": sugarcane_raster_path,
                "physical_allocated_pixels": physical_pixels["sugarcane"],
                "physical_allocated_area_km2": (
                    physical_pixels["sugarcane"]
                    * pixel_area_km2
                ),
            },
            {
                "scenario": scenario,
                "feedstock": "soybean",
                "input_raster": soybean_raster_path,
                "physical_allocated_pixels": physical_pixels["soybean"],
                "physical_allocated_area_km2": (
                    physical_pixels["soybean"]
                    * pixel_area_km2
                ),
            },
            {
                "scenario": scenario,
                "feedstock": "overlap",
                "input_raster": "sugarcane AND soybean",
                "physical_allocated_pixels": physical_pixels["overlap"],
                "physical_allocated_area_km2": (
                    physical_pixels["overlap"]
                    * pixel_area_km2
                ),
            },
            {
                "scenario": scenario,
                "feedstock": "combined",
                "input_raster": "sugarcane OR soybean",
                "physical_allocated_pixels": physical_pixels["combined"],
                "physical_allocated_area_km2": (
                    physical_pixels["combined"]
                    * pixel_area_km2
                ),
            },
        ]
    )

    # --------------------------------------------------------
    # Console checks
    # --------------------------------------------------------

    print("\n" + "-" * 86)
    print(f"AREA CHECK | {scenario.upper()}")
    print("-" * 86)

    for label in [
        "sugarcane",
        "soybean",
        "overlap",
        "combined",
    ]:
        area = physical_pixels[label] * pixel_area_km2
        print(f"{label.capitalize():12s}: {area:,.3f} km²")

    combined_classified_area = (
        classified_combined_pixels
        * pixel_area_km2
    )

    combined_raw_area = (
        physical_pixels["combined"]
        * pixel_area_km2
    )

    print(
        f"Combined classified area: "
        f"{combined_classified_area:,.3f} km²"
    )

    print(
        f"Combined unclassified area: "
        f"{combined_raw_area - combined_classified_area:,.3f} km²"
    )

    print(
        "\nImportant: the 'combined' CSV rows are the crop-allocation UNION. "
        "They are not sugarcane + soybean rows concatenated."
    )

    # Close input datasets.
    reference_ds = None
    sugarcane_ds = None
    soybean_ds = None
    landuse_ds = None
    pasture_ds = None
    zones_ds = None

    return {
        "scenario": scenario,
        "scenario_output_dir": scenario_output_dir,
        "sugarcane_raster": sugarcane_raster_path,
        "soybean_raster": soybean_raster_path,
        "combined_binary_raster": binary_path,
        "combined_feedstock_raster": feedstock_path,
        "raw_mapbiomas_raster": raw_path,
        "landuse_conflict_raster": conflict_path,
        "feedstock_landuse_conflict_map": map_path,
        "legend_csv": legend_csv,
        "distribution_csv": distribution_csv,
        "mapbiomas_distribution_csv": landuse_distribution_csv,
        "risk_csv": risk_csv,
        "manifest_csv": manifest_csv,
    }


# ============================================================
# OPTIONAL QGIS LOADER
# ============================================================

def add_raster_to_qgis(raster_path, layer_name):
    if not LOAD_OUTPUTS_TO_QGIS:
        return

    if not QGIS_AVAILABLE:
        print(
            "QGIS imports are unavailable; output was not added."
        )
        return

    layer = QgsRasterLayer(raster_path, layer_name)

    if layer.isValid():
        QgsProject.instance().addMapLayer(layer)
        print("Added to QGIS:")
        print(raster_path)
    else:
        print("Created but could not add to QGIS:")
        print(raster_path)


# ============================================================
# MAIN
# ============================================================

def main():
    print("\n" + "=" * 86)
    print("LAND-USE CONFLICT | NEW TWO-STAGE DOWNSCALING")
    print("=" * 86)

    ensure_dir_writable(OUTPUT_DIR)

    for path, description in [
        (LANDUSE_RASTER_PATH, "MapBiomas land-use raster"),
        (PASTURE_VIGOR_RASTER_PATH, "Pasture-vigor raster"),
        (ZONES_PATH, "Zones shapefile"),
    ]:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"{description} not found:\n{path}"
            )

    all_outputs = []

    for scenario in SCENARIO_ORDER:
        sugarcane_raster = find_final_allocation_raster(
            scenario,
            "sugarcane"
        )

        soybean_raster = find_final_allocation_raster(
            scenario,
            "soybean"
        )

        if sugarcane_raster is None and REQUIRE_SUGARCANE:
            raise FileNotFoundError(
                "\nCould not locate the final sugarcane raster.\n"
                f"Scenario: {scenario}\n"
                "Set MANUAL_ALLOCATION_RASTERS for this scenario."
            )

        if (
            scenario in SCENARIOS_REQUIRING_SOYBEAN
            and soybean_raster is None
        ):
            raise FileNotFoundError(
                "\nCould not locate the final soybean raster.\n"
                f"Scenario: {scenario}\n"
                "Set MANUAL_ALLOCATION_RASTERS for this scenario."
            )

        outputs = process_scenario(
            scenario=scenario,
            sugarcane_raster_path=sugarcane_raster,
            soybean_raster_path=soybean_raster,
        )

        all_outputs.append(outputs)

        add_raster_to_qgis(
            outputs["landuse_conflict_raster"],
            f"Land-use conflict | {scenario}"
        )

        add_raster_to_qgis(
            outputs["feedstock_landuse_conflict_map"],
            f"Feedstock + land-use conflict | {scenario}"
        )

    combined_tag = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    combined_csv = combine_csvs(
        input_csvs=[
            item["risk_csv"]
            for item in all_outputs
        ],
        output_csv=os.path.join(
            OUTPUT_DIR,
            "combined_landuse_conflict_risk_score_by_zone_feedstock_"
            f"all_scenarios_{combined_tag}.csv"
        )
    )

    print("\n" + "=" * 86)
    print("DONE")
    print("=" * 86)

    for item in all_outputs:
        print(f"\nScenario: {item['scenario']}")
        print("  Risk CSV:")
        print(f"  {item['risk_csv']}")
        print("  Combined feedstock raster:")
        print(f"  {item['combined_feedstock_raster']}")

    print("\nCombined all-scenario CSV:")
    print(combined_csv)


# QGIS Editor executes temporary scripts with exec(...). Call main() directly.
main()
