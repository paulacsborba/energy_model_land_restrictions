# -*- coding: utf-8 -*-
# ============================================================
# LABOR RISK INDICATOR | NEW SEQUENTIAL DOWNSCALING
# BRAZIL | QGIS PYTHON EDITOR / OSGeo Python
# ============================================================
#
# This script is compatible with the new two-stage allocation:
#
#   1. Sugarcane is downscaled first.
#   2. Soybean is downscaled only on pixels remaining after sugarcane.
#
# Therefore, sugarcane and soybean should not overlap.
#
# Scenario outputs include:
#   - combined feedstock binary raster
#   - combined feedstock code raster:
#         0 = no allocation
#         1 = sugarcane
#         2 = soybean
#         3 = overlap (unexpected; triggers an error by default)
#   - labor-risk continuous raster (1 = low; 3 = high)
#   - labor-risk categorical raster (1 = low; 2 = medium; 3 = high)
#   - feedstock + labor-risk map-code raster
#   - CSVs by zone and feedstock:
#         sugarcane, soybean, overlap (only if present), combined
#   - TOTAL_BRAZIL rows
#
# scenario_epe is sugarcane-only:
#   combined == sugarcane
#
# Run this script through QGIS Python Console > Show Editor > Run Script.
# Do not paste exec(Path(...).read_text()) inside this file.
# ============================================================

import os
import re
import glob
import csv
from datetime import datetime

import numpy as np
from osgeo import gdal, ogr, osr


gdal.UseExceptions()


# ============================================================
# USER CONFIGURATION
# ============================================================

SCENARIOS = [
    "scenario_epe",
    "baseline",
    "conservation",
    "governance",
    "degraded_pastures",
    "integrated",
]

BASE_DIR = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"

OCCURRENCES_POINTS_PATH = os.path.join(
    BASE_DIR,
    r"geospatial_data\shapefiles\social_indicator"
    r"\Slavery_likely_2020_2022"
    r"\Slavery_likely_2020_2022.shp"
)

ZONES_PATH = (
    r"C:\Users\pcsbo\OneDrive\Doutorado\Library\Data"
    r"\shapefile\zones\zones_\zones_fixed.shp"
)

# Leave None for automatic identification.
# Example: ZONE_FIELD = "ZONE"
ZONE_FIELD = None

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    r"outputs\combined_feedstock_labor_risk_indicator"
)

# Maximum influence distance:
#   distance = 0 km                -> score = 3
#   distance >= MAX_DISTANCE_KM     -> score = 1
MAX_DISTANCE_KM = 100.0

BLOCK_SIZE = 1024
OUTPUT_NODATA = -9999.0

# New soybean-after-sugarcane allocation should have zero overlap.
STOP_IF_OVERLAP = True

# False: missing required raster stops execution.
# True: prints a warning and skips that scenario.
SKIP_MISSING_SCENARIOS = False

# Use only when automatic selection chooses a wrong or outdated raster.
# Example:
#
# MANUAL_ALLOCATION_RASTERS = {
#     "conservation": {
#         "sugarcane": (
#             r"C:\...\scenario_conservation_direct_raster_downscaling"
#             r"\downscaled_sugarcane_chosen_potential_class_conservation.tif"
#         ),
#         "soybean": (
#             r"C:\...\scenario_conservation_soybean_after_sugarcane_downscaling"
#             r"\downscaled_soybean_chosen_binary_after_sugarcane_conservation.tif"
#         ),
#     },
# }
MANUAL_ALLOCATION_RASTERS = {
    "scenario_epe": {
        "sugarcane": (
            r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure"
            r"\geospatial_data\integration"
            r"\scenario_epe_sugarcane_direct_raster_downscaling_checked"
            r"\downscaled_sugarcane_chosen_potential_class_scenario_epe.tif"
        ),
    },
}

# scenario_epe has sugarcane only by design.
SCENARIOS_WITHOUT_SOYBEAN = {"scenario_epe"}

SUGARCANE_CODE = 1
SOYBEAN_CODE = 2
OVERLAP_CODE = 3
COMBINED_CODE = 99


# ============================================================
# RISK CONVERSION
# ============================================================

def convert_distance_to_labor_risk_1_3(distance_km_array):
    """
    Converts distance to the nearest recorded occurrence into labor risk.

    Score = 1 + 2 * (1 - min(distance, max_distance) / max_distance)

        1 = low risk
        2 = medium risk
        3 = high risk
    """
    clipped_distance = np.minimum(
        distance_km_array,
        MAX_DISTANCE_KM
    )

    risk_array = 1.0 + 2.0 * (
        1.0 - clipped_distance / MAX_DISTANCE_KM
    )

    return np.clip(risk_array, 1.0, 3.0)


def continuous_risk_to_class(risk_array):
    """
    Convert continuous labor risk to discrete classes.

        score < 1.5          -> 1 = low
        1.5 <= score < 2.5   -> 2 = medium
        score >= 2.5         -> 3 = high
    """
    classes = np.full(
        risk_array.shape,
        OUTPUT_NODATA,
        dtype=np.int16
    )

    finite = np.isfinite(risk_array)

    classes[finite & (risk_array < 1.5)] = 1
    classes[
        finite
        & (risk_array >= 1.5)
        & (risk_array < 2.5)
    ] = 2
    classes[finite & (risk_array >= 2.5)] = 3

    return classes


def calculate_labor_risk_index_0_to_1(risk_score):
    """Convert a mean score from 1-3 to an index from 0-1."""
    return (risk_score - 1.0) / 2.0


def interpret_labor_risk_score(risk_score):
    if risk_score >= 2.5:
        return "high labor-risk dominated"

    if risk_score >= 1.5:
        return "mixed or medium labor-risk dominated"

    return "low labor-risk dominated"


# ============================================================
# FILE, RASTER AND NUMERIC HELPERS
# ============================================================

def ensure_dir_writable(folder):
    """Create a directory and verify that it can be written."""
    os.makedirs(folder, exist_ok=True)

    test_path = os.path.join(folder, "__write_test.tmp")

    try:
        with open(test_path, "w", encoding="utf-8") as handle:
            handle.write("ok")

        os.remove(test_path)

    except Exception as exc:
        raise RuntimeError(
            "Output directory is not writable.\n"
            f"Directory:\n{folder}\n\n"
            f"Original error:\n{exc}"
        )


def safe_remove_file(path):
    """
    Remove a regular file. If it is locked by QGIS/Excel/OneDrive,
    use a timestamped alternative path.
    """
    if not os.path.exists(path):
        return path

    try:
        os.remove(path)
        return path

    except Exception:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        root, extension = os.path.splitext(path)
        alternative = f"{root}_new_{timestamp}{extension}"

        print("\nWARNING: could not remove existing file.")
        print("Using alternative output path:")
        print(alternative)

        return alternative


def safe_remove_raster_family(path):
    """Remove a GeoTIFF and common sidecars, with a safe fallback."""
    sidecars = [
        path,
        path + ".aux.xml",
        path + ".ovr",
        path + ".msk",
    ]

    locked = False

    for sidecar in sidecars:
        if os.path.exists(sidecar):
            try:
                os.remove(sidecar)
            except Exception:
                locked = True

    if not locked:
        return path

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    root, extension = os.path.splitext(path)
    alternative = f"{root}_new_{timestamp}{extension}"

    print("\nWARNING: raster output is locked.")
    print("Using alternative output path:")
    print(alternative)

    return alternative


def write_csv(output_csv, fieldnames, rows):
    """Write a UTF-8-SIG CSV, suitable for Excel."""
    ensure_dir_writable(os.path.dirname(output_csv))
    output_csv = safe_remove_file(output_csv)

    with open(
        output_csv,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames
        )
        writer.writeheader()
        writer.writerows(rows)

    print("CSV written:")
    print(output_csv)

    return output_csv


def open_raster(path):
    dataset = gdal.Open(path, gdal.GA_ReadOnly)

    if dataset is None:
        raise FileNotFoundError(
            f"Could not open raster:\n{path}"
        )

    return dataset


def calculate_pixel_area_km2(geotransform):
    """Assumes a projected grid in metres."""
    return (
        abs(geotransform[1])
        * abs(geotransform[5])
    ) / 1_000_000.0


def grids_are_equal(reference_ds, other_ds, tolerance=1e-9):
    """Check dimensions, geotransform and CRS."""
    if reference_ds.RasterXSize != other_ds.RasterXSize:
        return False

    if reference_ds.RasterYSize != other_ds.RasterYSize:
        return False

    for reference_value, other_value in zip(
        reference_ds.GetGeoTransform(),
        other_ds.GetGeoTransform()
    ):
        if abs(reference_value - other_value) > tolerance:
            return False

    return (
        reference_ds.GetProjection()
        == other_ds.GetProjection()
    )


def create_geotiff_like(reference_ds, output_path, dtype, nodata):
    """Create a one-band GeoTIFF aligned to a reference grid."""
    ensure_dir_writable(os.path.dirname(output_path))
    output_path = safe_remove_raster_family(output_path)

    driver = gdal.GetDriverByName("GTiff")

    output_ds = driver.Create(
        output_path,
        reference_ds.RasterXSize,
        reference_ds.RasterYSize,
        1,
        dtype,
        options=[
            "COMPRESS=LZW",
            "BIGTIFF=IF_SAFER",
        ]
    )

    if output_ds is None:
        raise RuntimeError(
            f"Could not create raster:\n{output_path}"
        )

    output_ds.SetGeoTransform(
        reference_ds.GetGeoTransform()
    )
    output_ds.SetProjection(
        reference_ds.GetProjection()
    )

    output_band = output_ds.GetRasterBand(1)
    output_band.SetNoDataValue(nodata)
    output_band.Fill(nodata)

    return output_ds, output_path


def align_raster_to_reference(
    input_raster_path,
    reference_ds,
    output_path,
    output_nodata,
    output_type=gdal.GDT_Int16,
):
    """
    Align an ordinal/categorical raster to the reference grid using
    nearest-neighbour resampling.
    """
    input_ds = open_raster(input_raster_path)

    if grids_are_equal(reference_ds, input_ds):
        input_ds = None
        return input_raster_path

    reference_gt = reference_ds.GetGeoTransform()

    xmin = reference_gt[0]
    ymax = reference_gt[3]
    xmax = (
        xmin
        + reference_ds.RasterXSize
        * reference_gt[1]
    )
    ymin = (
        ymax
        + reference_ds.RasterYSize
        * reference_gt[5]
    )

    source_nodata = (
        input_ds.GetRasterBand(1)
        .GetNoDataValue()
    )

    output_path = safe_remove_raster_family(output_path)

    warp_kwargs = {
        "format": "GTiff",
        "outputBounds": (xmin, ymin, xmax, ymax),
        "width": reference_ds.RasterXSize,
        "height": reference_ds.RasterYSize,
        "dstSRS": reference_ds.GetProjection(),
        "resampleAlg": "near",
        "outputType": output_type,
        "dstNodata": output_nodata,
        "multithread": True,
        "creationOptions": [
            "COMPRESS=LZW",
            "BIGTIFF=IF_SAFER",
        ],
    }

    if source_nodata is not None:
        warp_kwargs["srcNodata"] = source_nodata

    print("\nAligning raster to the sugarcane grid:")
    print(input_raster_path)

    output_ds = gdal.Warp(
        output_path,
        input_ds,
        options=gdal.WarpOptions(
            **warp_kwargs
        )
    )

    if output_ds is None:
        raise RuntimeError(
            f"Could not align raster:\n{input_raster_path}"
        )

    output_ds.FlushCache()
    output_ds = None
    input_ds = None

    print("Aligned raster written:")
    print(output_path)

    return output_path


def get_valid_positive_mask(array, nodata):
    """Return a mask for allocated pixels in downscaling rasters."""
    valid = np.isfinite(array)
    valid &= array > 0
    valid &= array != OUTPUT_NODATA

    if nodata is not None:
        valid &= array != nodata

    return valid


def add_count(dictionary, key, value):
    dictionary[key] = (
        dictionary.get(key, 0)
        + int(value)
    )


def safe_share(numerator, denominator):
    if denominator <= 0:
        return 0.0

    return 100.0 * numerator / denominator


# ============================================================
# FIND FINAL NEW-DOWNSCALING RASTERS
# ============================================================

def choose_latest_file(paths):
    """Return the latest path, or None."""
    paths = sorted(set(paths))

    if not paths:
        return None

    return max(paths, key=os.path.getmtime)


def manual_raster_for(scenario, feedstock):
    """Return a manually configured path, if present."""
    scenario_config = MANUAL_ALLOCATION_RASTERS.get(
        scenario,
        {}
    )

    return scenario_config.get(feedstock)


def filter_sugarcane_candidates(paths):
    """Discard intermediate rasters and keep final sugarcane outputs."""
    excluded_tokens = [
        "score_total",
        "summary",
        "selected_pixels",
        "locked",
        "mask",
        "used_for_soybean",
        "sourceclass",
        "source_class",
    ]

    clean = []

    for path in sorted(set(paths)):
        filename = os.path.basename(path).lower()
        parent = os.path.dirname(path).lower()

        if "soybean" in filename or "soybean" in parent:
            continue

        if "sugarcane" not in filename:
            continue

        if "chosen" not in filename:
            continue

        if any(
            token in filename
            for token in excluded_tokens
        ):
            continue

        clean.append(path)

    return clean


def filter_soybean_candidates(paths):
    """Discard intermediate rasters and keep final soybean outputs."""
    excluded_tokens = [
        "score_total",
        "summary",
        "selected_pixels",
        "sourceclass",
        "source_class",
        "used_for_soybean",
        "sugarcane_locked",
    ]

    clean = []

    for path in sorted(set(paths)):
        filename = os.path.basename(path).lower()
        parent = os.path.dirname(path).lower()

        if "soybean" not in filename:
            continue

        if "chosen" not in filename:
            continue

        if any(
            token in filename
            for token in excluded_tokens
        ):
            continue

        # Prefer final output inside a soybean-after-sugarcane folder.
        if (
            "soybean_after_sugarcane"
            not in parent
            and "after_sugarcane" not in filename
        ):
            continue

        clean.append(path)

    return clean


def select_sugarcane_candidate(candidates):
    """
    Prefer potential-class rasters over binary rasters, then choose the newest.
    Any positive value is used purely as an allocation mask.
    """
    potential_class = [
        path for path in candidates
        if "potential_class"
        in os.path.basename(path).lower()
    ]

    binary = [
        path for path in candidates
        if "binary"
        in os.path.basename(path).lower()
    ]

    return (
        choose_latest_file(potential_class)
        or choose_latest_file(binary)
        or choose_latest_file(candidates)
    )


def select_soybean_candidate(candidates):
    """Prefer explicit after-sugarcane final rasters, then newest."""
    explicit_after_sugarcane = [
        path for path in candidates
        if "after_sugarcane"
        in os.path.basename(path).lower()
    ]

    binary = [
        path for path in explicit_after_sugarcane
        if "binary"
        in os.path.basename(path).lower()
    ]

    return (
        choose_latest_file(binary)
        or choose_latest_file(explicit_after_sugarcane)
        or choose_latest_file(candidates)
    )


def find_sugarcane_raster(scenario):
    """Find the final sugarcane allocation for one scenario."""
    manual_path = manual_raster_for(
        scenario,
        "sugarcane"
    )

    if manual_path is not None:
        if not os.path.exists(manual_path):
            raise FileNotFoundError(
                "Manual sugarcane raster not found:\n"
                f"{manual_path}"
            )

        print("\nUsing manual sugarcane raster:")
        print(manual_path)

        return manual_path

    integration_dir = os.path.join(
        BASE_DIR,
        "geospatial_data",
        "integration"
    )

    preferred_folders = [
        (
            f"scenario_{scenario}_sugarcane_"
            "direct_raster_downscaling_checked"
        ),
        (
            f"scenario_{scenario}_sugarcane_"
            "direct_raster_downscaling"
        ),
        (
            f"scenario_{scenario}_direct_"
            "raster_downscaling_checked"
        ),
        (
            f"scenario_{scenario}_direct_"
            "raster_downscaling"
        ),
    ]

    filename_patterns = [
        (
            f"downscaled_sugarcane_chosen_"
            f"potential_class_{scenario}*.tif"
        ),
        (
            f"downscaled_sugarcane_chosen_"
            f"binary_{scenario}*.tif"
        ),
        f"*sugarcane*chosen*{scenario}*.tif",
    ]

    for folder_name in preferred_folders:
        folder = os.path.join(
            integration_dir,
            folder_name
        )

        matches = []

        for filename_pattern in filename_patterns:
            matches.extend(
                glob.glob(
                    os.path.join(
                        folder,
                        filename_pattern
                    )
                )
            )

        candidates = filter_sugarcane_candidates(
            matches
        )

        selected = select_sugarcane_candidate(
            candidates
        )

        if selected is not None:
            print("\nSugarcane folder selected:")
            print(folder)
            print("Sugarcane raster selected:")
            print(selected)

            return selected

    # Fallback: restricted recursive search only after exact folders fail.
    fallback_patterns = [
        os.path.join(
            integration_dir,
            f"*scenario_{scenario}*sugarcane*downscaling*",
            f"*sugarcane*chosen*{scenario}*.tif"
        ),
        os.path.join(
            integration_dir,
            f"*scenario_{scenario}*direct*raster*downscaling*",
            f"*sugarcane*chosen*{scenario}*.tif"
        ),
    ]

    fallback_matches = []

    for pattern in fallback_patterns:
        fallback_matches.extend(glob.glob(pattern))

    candidates = filter_sugarcane_candidates(
        fallback_matches
    )

    selected = select_sugarcane_candidate(candidates)

    print("\nFallback sugarcane candidates:")
    if candidates:
        for path in candidates:
            print("  ", path)
    else:
        print("  None found.")

    print("Sugarcane raster selected:")
    print(selected)

    return selected


def find_soybean_raster(scenario):
    """
    Find the final soybean allocation generated AFTER sugarcane locking.
    """
    if scenario in SCENARIOS_WITHOUT_SOYBEAN:
        print(
            "\nNo soybean allocation is expected for "
            f"'{scenario}'."
        )
        return None

    manual_path = manual_raster_for(
        scenario,
        "soybean"
    )

    if manual_path is not None:
        if not os.path.exists(manual_path):
            raise FileNotFoundError(
                "Manual soybean raster not found:\n"
                f"{manual_path}"
            )

        print("\nUsing manual soybean raster:")
        print(manual_path)

        return manual_path

    integration_dir = os.path.join(
        BASE_DIR,
        "geospatial_data",
        "integration"
    )

    preferred_folders = [
        (
            f"scenario_{scenario}_soybean_"
            "after_sugarcane_downscaling_checked"
        ),
        (
            f"scenario_{scenario}_soybean_"
            "after_sugarcane_downscaling"
        ),
    ]

    filename_patterns = [
        (
            f"downscaled_soybean_chosen_binary_"
            f"after_sugarcane_{scenario}*.tif"
        ),
        (
            f"downscaled_soybean_chosen_"
            f"*after_sugarcane*{scenario}*.tif"
        ),
        f"*soybean*chosen*{scenario}*.tif",
    ]

    for folder_name in preferred_folders:
        folder = os.path.join(
            integration_dir,
            folder_name
        )

        matches = []

        for filename_pattern in filename_patterns:
            matches.extend(
                glob.glob(
                    os.path.join(
                        folder,
                        filename_pattern
                    )
                )
            )

        candidates = filter_soybean_candidates(
            matches
        )

        selected = select_soybean_candidate(
            candidates
        )

        if selected is not None:
            print("\nSoybean-after-sugarcane folder selected:")
            print(folder)
            print("Soybean raster selected:")
            print(selected)

            return selected

    fallback_pattern = os.path.join(
        integration_dir,
        f"*scenario_{scenario}*soybean*"
        "after_sugarcane*downscaling*",
        f"*soybean*chosen*{scenario}*.tif"
    )

    candidates = filter_soybean_candidates(
        glob.glob(fallback_pattern)
    )

    selected = select_soybean_candidate(candidates)

    print("\nFallback soybean candidates:")
    if candidates:
        for path in candidates:
            print("  ", path)
    else:
        print("  None found.")

    print("Soybean raster selected:")
    print(selected)

    return selected


# ============================================================
# ZONES AND OCCURRENCES
# ============================================================

def detect_zone_field(zones_layer):
    """Detect a zone field, preferably values such as SP_Z2."""
    definition = zones_layer.GetLayerDefn()

    field_names = [
        definition.GetFieldDefn(index).GetName()
        for index in range(
            definition.GetFieldCount()
        )
    ]

    print("\nAvailable zone fields:")
    print(field_names)

    if ZONE_FIELD is not None:
        if ZONE_FIELD not in field_names:
            raise KeyError(
                f"ZONE_FIELD not found: {ZONE_FIELD}\n"
                f"Available fields: {field_names}"
            )

        return ZONE_FIELD

    zone_pattern = re.compile(r"^[A-Z]{2}_Z\d+$")

    for field_name in field_names:
        zones_layer.ResetReading()

        checked = 0
        matched = 0

        for feature in zones_layer:
            value = str(
                feature.GetField(field_name)
            ).strip()

            checked += 1

            if zone_pattern.match(value):
                matched += 1

            if checked >= 50:
                break

        if (
            checked > 0
            and matched >= max(1, checked * 0.5)
        ):
            return field_name

    for field_name in [
        "ZONE",
        "zone",
        "Zone",
        "NAME",
        "name",
        "Name",
        "ID",
        "id",
        "Id",
    ]:
        if field_name in field_names:
            return field_name

    raise RuntimeError(
        "Could not detect the zone field.\n"
        f"Available fields: {field_names}"
    )


def create_zones_raster(reference_ds, output_path):
    """Rasterize zone polygons with numeric IDs on the reference grid."""
    zones_ds = ogr.Open(ZONES_PATH)

    if zones_ds is None:
        raise FileNotFoundError(
            f"Could not open zones shapefile:\n{ZONES_PATH}"
        )

    zones_layer = zones_ds.GetLayer()

    selected_zone_field = detect_zone_field(
        zones_layer
    )

    raster_srs = osr.SpatialReference()
    raster_srs.ImportFromWkt(
        reference_ds.GetProjection()
    )

    zones_srs = zones_layer.GetSpatialRef()
    coordinate_transform = None

    if (
        zones_srs is not None
        and not zones_srs.IsSame(raster_srs)
    ):
        coordinate_transform = (
            osr.CoordinateTransformation(
                zones_srs,
                raster_srs
            )
        )

        print(
            "Zones CRS differs from raster CRS. "
            "Reprojecting in memory."
        )

    zone_name_to_id = {}
    zone_id_to_name = {}
    next_id = 1

    zones_layer.ResetReading()

    for feature in zones_layer:
        zone_name = feature.GetField(
            selected_zone_field
        )

        if zone_name not in zone_name_to_id:
            zone_name_to_id[zone_name] = next_id
            zone_id_to_name[next_id] = zone_name
            next_id += 1

    memory_driver = ogr.GetDriverByName("Memory")
    memory_ds = memory_driver.CreateDataSource(
        "memory_zones"
    )

    memory_layer = memory_ds.CreateLayer(
        "zones_numeric",
        srs=raster_srs,
        geom_type=zones_layer.GetGeomType()
    )

    memory_layer.CreateField(
        ogr.FieldDefn(
            "zone_id",
            ogr.OFTInteger
        )
    )

    memory_definition = (
        memory_layer.GetLayerDefn()
    )

    zones_layer.ResetReading()

    for feature in zones_layer:
        geometry = feature.GetGeometryRef()

        if geometry is None:
            continue

        geometry_copy = geometry.Clone()

        if coordinate_transform is not None:
            geometry_copy.Transform(
                coordinate_transform
            )

        output_feature = ogr.Feature(
            memory_definition
        )

        output_feature.SetField(
            "zone_id",
            zone_name_to_id[
                feature.GetField(
                    selected_zone_field
                )
            ]
        )

        output_feature.SetGeometry(
            geometry_copy
        )

        memory_layer.CreateFeature(
            output_feature
        )

        output_feature = None

    zones_raster_ds, output_path = create_geotiff_like(
        reference_ds,
        output_path,
        gdal.GDT_Int32,
        0
    )

    zones_band = zones_raster_ds.GetRasterBand(1)
    zones_band.Fill(0)

    gdal.RasterizeLayer(
        zones_raster_ds,
        [1],
        memory_layer,
        options=["ATTRIBUTE=zone_id"]
    )

    zones_band.FlushCache()
    zones_raster_ds.FlushCache()

    zones_raster_ds = None
    memory_ds = None
    zones_ds = None

    print("Zones raster created:")
    print(output_path)

    return (
        output_path,
        zone_id_to_name,
        selected_zone_field
    )


def count_occurrence_pixels(raster_path):
    """Verify that at least one occurrence point was rasterized."""
    dataset = open_raster(raster_path)
    band = dataset.GetRasterBand(1)

    count = 0

    for y in range(0, dataset.RasterYSize, BLOCK_SIZE):
        ysize = min(
            BLOCK_SIZE,
            dataset.RasterYSize - y
        )

        for x in range(0, dataset.RasterXSize, BLOCK_SIZE):
            xsize = min(
                BLOCK_SIZE,
                dataset.RasterXSize - x
            )

            array = band.ReadAsArray(
                x,
                y,
                xsize,
                ysize
            )

            if array is not None:
                count += int(np.sum(array == 1))

    dataset = None

    return count


def rasterize_occurrences_to_grid(
    reference_ds,
    output_path,
):
    """
    Rasterize recorded occurrence points to the allocation grid.

      1 = occurrence pixel
      0 = no occurrence
    """
    occurrences_ds = ogr.Open(
        OCCURRENCES_POINTS_PATH
    )

    if occurrences_ds is None:
        raise FileNotFoundError(
            "Could not open occurrence points shapefile:\n"
            f"{OCCURRENCES_POINTS_PATH}"
        )

    occurrences_layer = occurrences_ds.GetLayer()

    if occurrences_layer.GetFeatureCount() <= 0:
        raise RuntimeError(
            "The occurrence layer contains no features."
        )

    raster_srs = osr.SpatialReference()
    raster_srs.ImportFromWkt(
        reference_ds.GetProjection()
    )

    occurrence_srs = occurrences_layer.GetSpatialRef()
    coordinate_transform = None

    if (
        occurrence_srs is not None
        and not occurrence_srs.IsSame(raster_srs)
    ):
        coordinate_transform = (
            osr.CoordinateTransformation(
                occurrence_srs,
                raster_srs
            )
        )

        print(
            "Occurrence CRS differs from raster CRS. "
            "Reprojecting in memory."
        )

    memory_driver = ogr.GetDriverByName("Memory")
    memory_ds = memory_driver.CreateDataSource(
        "memory_occurrences"
    )

    memory_layer = memory_ds.CreateLayer(
        "occurrences_reprojected",
        srs=raster_srs,
        geom_type=occurrences_layer.GetGeomType()
    )

    memory_definition = (
        memory_layer.GetLayerDefn()
    )

    feature_count = 0

    occurrences_layer.ResetReading()

    for feature in occurrences_layer:
        geometry = feature.GetGeometryRef()

        if geometry is None:
            continue

        geometry_copy = geometry.Clone()

        if coordinate_transform is not None:
            geometry_copy.Transform(
                coordinate_transform
            )

        output_feature = ogr.Feature(
            memory_definition
        )

        output_feature.SetGeometry(
            geometry_copy
        )

        memory_layer.CreateFeature(
            output_feature
        )

        output_feature = None
        feature_count += 1

    if feature_count <= 0:
        raise RuntimeError(
            "No valid occurrence geometries were found."
        )

    occurrence_ds, output_path = create_geotiff_like(
        reference_ds,
        output_path,
        gdal.GDT_Byte,
        0
    )

    occurrence_band = occurrence_ds.GetRasterBand(1)
    occurrence_band.Fill(0)

    gdal.RasterizeLayer(
        occurrence_ds,
        [1],
        memory_layer,
        burn_values=[1],
        options=["ALL_TOUCHED=TRUE"]
    )

    occurrence_band.FlushCache()
    occurrence_ds.FlushCache()

    occurrence_ds = None
    memory_ds = None
    occurrences_ds = None

    burned_pixels = count_occurrence_pixels(
        output_path
    )

    print("Occurrence raster created:")
    print(output_path)
    print(
        "Occurrence pixels burned: "
        f"{burned_pixels:,}"
    )

    if burned_pixels <= 0:
        raise RuntimeError(
            "No occurrence pixels were burned. "
            "Check the point-layer CRS and extent."
        )

    return output_path


def create_distance_raster(
    occurrence_raster_path,
    output_path,
):
    """
    Compute distance to the closest occurrence.

    DISTUNITS=GEO returns the coordinate unit. The allocation grid is
    expected to be in EPSG:5880 (metres), so output is in metres.
    """
    occurrence_ds = open_raster(
        occurrence_raster_path
    )

    occurrence_band = occurrence_ds.GetRasterBand(1)

    distance_ds, output_path = create_geotiff_like(
        occurrence_ds,
        output_path,
        gdal.GDT_Float32,
        OUTPUT_NODATA
    )

    distance_band = distance_ds.GetRasterBand(1)

    print("\nCalculating distance to nearest occurrence...")

    result = gdal.ComputeProximity(
        occurrence_band,
        distance_band,
        options=[
            "VALUES=1",
            "DISTUNITS=GEO",
            f"NODATA={OUTPUT_NODATA}",
        ]
    )

    # GDAL Python bindings may return 0 (CE_None) or None on success,
    # depending on the installed GDAL version.
    if result not in (None, gdal.CE_None):
        raise RuntimeError(
            "GDAL ComputeProximity failed."
        )

    distance_band.FlushCache()
    distance_ds.FlushCache()

    distance_ds = None
    occurrence_ds = None

    print("Distance raster created:")
    print(output_path)

    return output_path


# ============================================================
# COMBINE FINAL SUGARCANE + SOYBEAN ALLOCATIONS
# ============================================================

def combine_feedstock_rasters(
    scenario,
    sugarcane_raster_path,
    soybean_raster_path,
    scenario_output_dir,
    run_tag,
):
    """
    Combine final allocations. Soybean is optional only for scenario_epe.

    Code:
      0 = no allocation
      1 = sugarcane
      2 = soybean
      3 = overlap
    """
    print("\n" + "-" * 78)
    print(
        "COMBINING FINAL ALLOCATIONS | "
        f"{scenario}"
    )
    print("-" * 78)

    if (
        sugarcane_raster_path is None
        or not os.path.exists(sugarcane_raster_path)
    ):
        raise FileNotFoundError(
            "Sugarcane raster not found:\n"
            f"{sugarcane_raster_path}"
        )

    sugarcane_ds = open_raster(
        sugarcane_raster_path
    )

    soybean_aligned_path = None
    soybean_ds = None

    if soybean_raster_path is not None:
        if not os.path.exists(soybean_raster_path):
            raise FileNotFoundError(
                "Soybean raster not found:\n"
                f"{soybean_raster_path}"
            )

        soybean_aligned_path = align_raster_to_reference(
            input_raster_path=soybean_raster_path,
            reference_ds=sugarcane_ds,
            output_path=os.path.join(
                scenario_output_dir,
                f"soybean_aligned_to_sugarcane_"
                f"{scenario}_{run_tag}.tif"
            ),
            output_nodata=0,
            output_type=gdal.GDT_Byte,
        )

        soybean_ds = open_raster(
            soybean_aligned_path
        )

        if not grids_are_equal(
            sugarcane_ds,
            soybean_ds
        ):
            raise RuntimeError(
                "Soybean raster could not be aligned "
                "to the sugarcane grid."
            )

    binary_ds, binary_path = create_geotiff_like(
        sugarcane_ds,
        os.path.join(
            scenario_output_dir,
            f"combined_feedstocks_binary_"
            f"{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Byte,
        0
    )

    feedstock_ds, feedstock_path = create_geotiff_like(
        sugarcane_ds,
        os.path.join(
            scenario_output_dir,
            f"combined_feedstocks_code_"
            f"{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Byte,
        0
    )

    sugarcane_band = sugarcane_ds.GetRasterBand(1)
    sugarcane_nodata = sugarcane_band.GetNoDataValue()

    soybean_band = (
        soybean_ds.GetRasterBand(1)
        if soybean_ds is not None
        else None
    )
    soybean_nodata = (
        soybean_band.GetNoDataValue()
        if soybean_band is not None
        else None
    )

    binary_band = binary_ds.GetRasterBand(1)
    feedstock_band = feedstock_ds.GetRasterBand(1)

    total_sugarcane_pixels = 0
    total_soybean_pixels = 0
    total_overlap_pixels = 0
    total_combined_pixels = 0

    pixel_area_km2 = calculate_pixel_area_km2(
        sugarcane_ds.GetGeoTransform()
    )

    rows = sugarcane_ds.RasterYSize
    cols = sugarcane_ds.RasterXSize

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(BLOCK_SIZE, rows - y)

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(BLOCK_SIZE, cols - x)

            sugarcane_array = (
                sugarcane_band.ReadAsArray(
                    x,
                    y,
                    xsize,
                    ysize
                ).astype(float)
            )

            sugarcane_mask = get_valid_positive_mask(
                sugarcane_array,
                sugarcane_nodata
            )

            if soybean_band is None:
                soybean_mask = np.zeros(
                    sugarcane_array.shape,
                    dtype=bool
                )
            else:
                soybean_array = (
                    soybean_band.ReadAsArray(
                        x,
                        y,
                        xsize,
                        ysize
                    ).astype(float)
                )

                soybean_mask = get_valid_positive_mask(
                    soybean_array,
                    soybean_nodata
                )

            overlap_mask = (
                sugarcane_mask
                & soybean_mask
            )

            combined_mask = (
                sugarcane_mask
                | soybean_mask
            )

            feedstock_array = np.zeros(
                sugarcane_array.shape,
                dtype=np.uint8
            )

            binary_array = np.zeros(
                sugarcane_array.shape,
                dtype=np.uint8
            )

            feedstock_array[
                sugarcane_mask
            ] = SUGARCANE_CODE

            feedstock_array[
                soybean_mask
            ] = SOYBEAN_CODE

            feedstock_array[
                overlap_mask
            ] = OVERLAP_CODE

            binary_array[combined_mask] = 1

            binary_band.WriteArray(
                binary_array,
                x,
                y
            )

            feedstock_band.WriteArray(
                feedstock_array,
                x,
                y
            )

            total_sugarcane_pixels += int(
                np.sum(sugarcane_mask)
            )
            total_soybean_pixels += int(
                np.sum(soybean_mask)
            )
            total_overlap_pixels += int(
                np.sum(overlap_mask)
            )
            total_combined_pixels += int(
                np.sum(combined_mask)
            )

        print(
            f"Combined row "
            f"{min(y + BLOCK_SIZE, rows)} of {rows}"
        )

    binary_band.FlushCache()
    feedstock_band.FlushCache()

    binary_ds.FlushCache()
    feedstock_ds.FlushCache()

    binary_ds = None
    feedstock_ds = None
    sugarcane_ds = None

    if soybean_ds is not None:
        soybean_ds = None

    sugarcane_area = (
        total_sugarcane_pixels
        * pixel_area_km2
    )
    soybean_area = (
        total_soybean_pixels
        * pixel_area_km2
    )
    overlap_area = (
        total_overlap_pixels
        * pixel_area_km2
    )
    combined_area = (
        total_combined_pixels
        * pixel_area_km2
    )

    print("\nFinal allocation area check:")
    print(f"  Sugarcane: {sugarcane_area:,.3f} km²")
    print(f"  Soybean:   {soybean_area:,.3f} km²")
    print(f"  Overlap:   {overlap_area:,.3f} km²")
    print(f"  Combined:  {combined_area:,.3f} km²")

    if total_overlap_pixels > 0 and STOP_IF_OVERLAP:
        raise RuntimeError(
            "\nUnexpected sugarcane/soybean overlap detected.\n"
            f"Scenario: {scenario}\n"
            f"Overlap: {overlap_area:,.3f} km²\n\n"
            "Soybean must be read from the final "
            "soybean-after-sugarcane allocation."
        )

    return {
        "sugarcane_raster": sugarcane_raster_path,
        "soybean_raster": soybean_aligned_path,
        "combined_binary_raster": binary_path,
        "combined_feedstock_raster": feedstock_path,
        "sugarcane_area_km2": sugarcane_area,
        "soybean_area_km2": soybean_area,
        "overlap_area_km2": overlap_area,
        "combined_area_km2": combined_area,
    }


# ============================================================
# LABOR-RISK INDICATOR
# ============================================================

def feedstock_label(feedstock_code):
    labels = {
        SUGARCANE_CODE: "sugarcane",
        SOYBEAN_CODE: "soybean",
        OVERLAP_CODE: "overlap",
        COMBINED_CODE: "combined",
    }

    return labels.get(
        int(feedstock_code),
        "none"
    )


def update_group_statistics(
    *,
    zone_id,
    feedstock_code,
    distance_km,
    risk_score,
    risk_class,
    pixel_area_km2,
    total_pixels,
    total_area,
    weighted_distance_sum,
    weighted_risk_sum,
    min_distance,
    max_distance,
    min_risk,
    max_risk,
    risk_class_counts,
):
    """Update all group-level statistics for one zone/feedstock subset."""
    if risk_score.size <= 0:
        return

    key = (int(zone_id), int(feedstock_code))

    pixel_count = int(risk_score.size)
    area_km2 = pixel_count * pixel_area_km2

    add_count(
        total_pixels,
        key,
        pixel_count
    )

    total_area[key] = (
        total_area.get(key, 0.0)
        + area_km2
    )

    weighted_distance_sum[key] = (
        weighted_distance_sum.get(key, 0.0)
        + float(np.sum(
            distance_km * pixel_area_km2
        ))
    )

    weighted_risk_sum[key] = (
        weighted_risk_sum.get(key, 0.0)
        + float(np.sum(
            risk_score * pixel_area_km2
        ))
    )

    current_min_distance = float(
        np.min(distance_km)
    )
    current_max_distance = float(
        np.max(distance_km)
    )
    current_min_risk = float(
        np.min(risk_score)
    )
    current_max_risk = float(
        np.max(risk_score)
    )

    min_distance[key] = min(
        min_distance.get(
            key,
            current_min_distance
        ),
        current_min_distance
    )

    max_distance[key] = max(
        max_distance.get(
            key,
            current_max_distance
        ),
        current_max_distance
    )

    min_risk[key] = min(
        min_risk.get(key, current_min_risk),
        current_min_risk
    )

    max_risk[key] = max(
        max_risk.get(key, current_max_risk),
        current_max_risk
    )

    for class_value in [1, 2, 3]:
        add_count(
            risk_class_counts,
            (
                int(zone_id),
                int(feedstock_code),
                int(class_value),
            ),
            int(np.sum(risk_class == class_value))
        )


def build_summary_row(
    *,
    scenario,
    zone_field,
    zone_name,
    feedstock_code,
    total_pixels,
    total_area,
    weighted_distance_sum,
    weighted_risk_sum,
    min_distance,
    max_distance,
    min_risk,
    max_risk,
    risk_class_counts,
    pixel_area_km2,
):
    """Build one CSV record for a zone/feedstock aggregate."""
    key = (zone_name["id"], feedstock_code)

    group_area = total_area[key]

    area_low = (
        risk_class_counts.get(
            (
                zone_name["id"],
                feedstock_code,
                1,
            ),
            0
        )
        * pixel_area_km2
    )

    area_medium = (
        risk_class_counts.get(
            (
                zone_name["id"],
                feedstock_code,
                2,
            ),
            0
        )
        * pixel_area_km2
    )

    area_high = (
        risk_class_counts.get(
            (
                zone_name["id"],
                feedstock_code,
                3,
            ),
            0
        )
        * pixel_area_km2
    )

    mean_distance = (
        weighted_distance_sum[key]
        / group_area
    )

    mean_risk = (
        weighted_risk_sum[key]
        / group_area
    )

    return {
        "scenario": scenario,
        zone_field: zone_name["name"],
        "feedstock": feedstock_label(
            feedstock_code
        ),
        "feedstock_code": int(feedstock_code),

        "allocated_pixels": int(
            total_pixels[key]
        ),
        "allocated_area_km2": group_area,
        "total_allocated_area_km2": group_area,

        "mean_distance_to_labor_occurrence_km": (
            mean_distance
        ),
        "min_distance_to_labor_occurrence_km": (
            min_distance[key]
        ),
        "max_distance_to_labor_occurrence_km": (
            max_distance[key]
        ),

        "mean_labor_risk_score_1_low_3_high": (
            mean_risk
        ),
        "labor_risk_index_0_low_1_high": (
            calculate_labor_risk_index_0_to_1(
                mean_risk
            )
        ),
        "min_labor_risk_score_1_low_3_high": (
            min_risk[key]
        ),
        "max_labor_risk_score_1_low_3_high": (
            max_risk[key]
        ),

        "area_low_labor_risk_score_1_km2": area_low,
        "area_medium_labor_risk_score_2_km2": (
            area_medium
        ),
        "area_high_labor_risk_score_3_km2": area_high,

        "share_low_labor_risk_score_1_pct": (
            safe_share(area_low, group_area)
        ),
        "share_medium_labor_risk_score_2_pct": (
            safe_share(area_medium, group_area)
        ),
        "share_high_labor_risk_score_3_pct": (
            safe_share(area_high, group_area)
        ),

        "max_distance_km_used_for_score": (
            MAX_DISTANCE_KM
        ),
        "interpretation": interpret_labor_risk_score(
            mean_risk
        ),
    }


def apply_labor_risk_indicator(
    scenario,
    combined_feedstock_raster,
    scenario_output_dir,
    run_tag,
):
    """
    Calculate labor risk over the final combined allocation.

    It aggregates:
      - specific allocated feedstocks (codes 1, 2, and 3)
      - combined allocation union (code 99)
    """
    print("\n" + "-" * 78)
    print(
        "APPLYING LABOR-RISK INDICATOR | "
        f"{scenario}"
    )
    print("-" * 78)

    feedstock_ds = open_raster(
        combined_feedstock_raster
    )

    feedstock_band = feedstock_ds.GetRasterBand(1)
    feedstock_nodata = (
        feedstock_band.GetNoDataValue()
    )

    rows = feedstock_ds.RasterYSize
    cols = feedstock_ds.RasterXSize

    pixel_area_km2 = calculate_pixel_area_km2(
        feedstock_ds.GetGeoTransform()
    )

    occurrence_raster_path = rasterize_occurrences_to_grid(
        reference_ds=feedstock_ds,
        output_path=os.path.join(
            scenario_output_dir,
            f"labor_occurrences_rasterized_"
            f"{scenario}_{run_tag}.tif"
        )
    )

    distance_raster_path = create_distance_raster(
        occurrence_raster_path=occurrence_raster_path,
        output_path=os.path.join(
            scenario_output_dir,
            f"distance_to_labor_occurrences_meters_"
            f"{scenario}_{run_tag}.tif"
        )
    )

    (
        zones_raster_path,
        zone_id_to_name,
        selected_zone_field
    ) = create_zones_raster(
        reference_ds=feedstock_ds,
        output_path=os.path.join(
            scenario_output_dir,
            f"zones_aligned_to_labor_risk_"
            f"{scenario}_{run_tag}.tif"
        )
    )

    distance_ds = open_raster(
        distance_raster_path
    )
    zones_ds = open_raster(zones_raster_path)

    distance_band = distance_ds.GetRasterBand(1)
    distance_nodata = distance_band.GetNoDataValue()

    zones_band = zones_ds.GetRasterBand(1)

    labor_risk_ds, labor_risk_path = create_geotiff_like(
        feedstock_ds,
        os.path.join(
            scenario_output_dir,
            f"labor_risk_score_1_low_3_"
            f"combined_feedstocks_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Float32,
        OUTPUT_NODATA
    )

    labor_class_ds, labor_class_path = create_geotiff_like(
        feedstock_ds,
        os.path.join(
            scenario_output_dir,
            f"labor_risk_class_1_low_3_high_"
            f"combined_feedstocks_{scenario}_{run_tag}.tif"
        ),
        gdal.GDT_Int16,
        OUTPUT_NODATA
    )

    feedstock_map_ds, feedstock_map_path = (
        create_geotiff_like(
            feedstock_ds,
            os.path.join(
                scenario_output_dir,
                f"feedstock_labor_risk_map_code_"
                f"{scenario}_{run_tag}.tif"
            ),
            gdal.GDT_Int16,
            OUTPUT_NODATA
        )
    )

    labor_risk_band = labor_risk_ds.GetRasterBand(1)
    labor_class_band = labor_class_ds.GetRasterBand(1)
    feedstock_map_band = (
        feedstock_map_ds.GetRasterBand(1)
    )

    # Key for group-level aggregation:
    #   (zone_id, feedstock_code)
    total_pixels = {}
    total_area = {}

    weighted_distance_sum = {}
    weighted_risk_sum = {}

    min_distance = {}
    max_distance = {}
    min_risk = {}
    max_risk = {}

    # (zone_id, feedstock_code, risk_class) -> pixel count
    risk_class_counts = {}

    print(
        "\nCalculating labor risk and zonal "
        "feedstock summaries..."
    )

    for y in range(0, rows, BLOCK_SIZE):
        ysize = min(BLOCK_SIZE, rows - y)

        for x in range(0, cols, BLOCK_SIZE):
            xsize = min(BLOCK_SIZE, cols - x)

            feedstock_array = (
                feedstock_band.ReadAsArray(
                    x,
                    y,
                    xsize,
                    ysize
                ).astype(np.int16)
            )

            distance_array = (
                distance_band.ReadAsArray(
                    x,
                    y,
                    xsize,
                    ysize
                ).astype(float)
            )

            zones_array = (
                zones_band.ReadAsArray(
                    x,
                    y,
                    xsize,
                    ysize
                ).astype(np.int32)
            )

            valid_feedstock = (
                feedstock_array > 0
            )

            if feedstock_nodata is not None:
                valid_feedstock &= (
                    feedstock_array
                    != feedstock_nodata
                )

            valid_distance = np.isfinite(
                distance_array
            )

            if distance_nodata is not None:
                valid_distance &= (
                    distance_array
                    != distance_nodata
                )

            valid_distance &= distance_array >= 0

            valid_zone = zones_array > 0

            valid_mask = (
                valid_feedstock
                & valid_distance
                & valid_zone
            )

            risk_output = np.full(
                feedstock_array.shape,
                OUTPUT_NODATA,
                dtype=np.float32
            )

            class_output = np.full(
                feedstock_array.shape,
                OUTPUT_NODATA,
                dtype=np.int16
            )

            map_output = np.full(
                feedstock_array.shape,
                OUTPUT_NODATA,
                dtype=np.int16
            )

            if np.any(valid_mask):
                distance_km_array = (
                    distance_array / 1000.0
                )

                risk_array = (
                    convert_distance_to_labor_risk_1_3(
                        distance_km_array
                    )
                )

                class_array = continuous_risk_to_class(
                    risk_array
                )

                risk_output[valid_mask] = (
                    risk_array[valid_mask]
                    .astype(np.float32)
                )

                class_output[valid_mask] = (
                    class_array[valid_mask]
                    .astype(np.int16)
                )

                map_output[valid_mask] = (
                    feedstock_array[valid_mask]
                    * 100
                    + class_array[valid_mask]
                )

            labor_risk_band.WriteArray(
                risk_output,
                x,
                y
            )

            labor_class_band.WriteArray(
                class_output,
                x,
                y
            )

            feedstock_map_band.WriteArray(
                map_output,
                x,
                y
            )

            if not np.any(valid_mask):
                continue

            selected_zones = zones_array[
                valid_mask
            ].astype(np.int32)

            selected_feedstocks = feedstock_array[
                valid_mask
            ].astype(np.int16)

            selected_distance_km = (
                distance_array[valid_mask] / 1000.0
            )

            selected_risk = risk_array[
                valid_mask
            ].astype(np.float32)

            selected_classes = class_array[
                valid_mask
            ].astype(np.int16)

            # ------------------------------------------------
            # Individual feedstocks: sugarcane, soybean, overlap
            # ------------------------------------------------
            zone_feedstock_pairs = np.column_stack(
                (
                    selected_zones,
                    selected_feedstocks
                )
            )

            unique_pairs = np.unique(
                zone_feedstock_pairs,
                axis=0
            )

            for zone_id, feedstock_code in unique_pairs:
                zone_id = int(zone_id)
                feedstock_code = int(feedstock_code)

                group_mask = (
                    (selected_zones == zone_id)
                    & (
                        selected_feedstocks
                        == feedstock_code
                    )
                )

                update_group_statistics(
                    zone_id=zone_id,
                    feedstock_code=feedstock_code,
                    distance_km=selected_distance_km[
                        group_mask
                    ],
                    risk_score=selected_risk[group_mask],
                    risk_class=selected_classes[
                        group_mask
                    ],
                    pixel_area_km2=pixel_area_km2,
                    total_pixels=total_pixels,
                    total_area=total_area,
                    weighted_distance_sum=(
                        weighted_distance_sum
                    ),
                    weighted_risk_sum=(
                        weighted_risk_sum
                    ),
                    min_distance=min_distance,
                    max_distance=max_distance,
                    min_risk=min_risk,
                    max_risk=max_risk,
                    risk_class_counts=(
                        risk_class_counts
                    ),
                )

            # ------------------------------------------------
            # Combined group: union of all allocated feedstocks
            # ------------------------------------------------
            for zone_id in np.unique(selected_zones):
                zone_id = int(zone_id)

                zone_mask = (
                    selected_zones == zone_id
                )

                update_group_statistics(
                    zone_id=zone_id,
                    feedstock_code=COMBINED_CODE,
                    distance_km=selected_distance_km[
                        zone_mask
                    ],
                    risk_score=selected_risk[zone_mask],
                    risk_class=selected_classes[
                        zone_mask
                    ],
                    pixel_area_km2=pixel_area_km2,
                    total_pixels=total_pixels,
                    total_area=total_area,
                    weighted_distance_sum=(
                        weighted_distance_sum
                    ),
                    weighted_risk_sum=(
                        weighted_risk_sum
                    ),
                    min_distance=min_distance,
                    max_distance=max_distance,
                    min_risk=min_risk,
                    max_risk=max_risk,
                    risk_class_counts=(
                        risk_class_counts
                    ),
                )

        print(
            f"Processed row "
            f"{min(y + BLOCK_SIZE, rows)} of {rows}"
        )

    for dataset in [
        labor_risk_ds,
        labor_class_ds,
        feedstock_map_ds,
    ]:
        dataset.FlushCache()

    labor_risk_ds = None
    labor_class_ds = None
    feedstock_map_ds = None

    # ========================================================
    # Build zone-level CSV records
    # ========================================================

    results = []

    for zone_id, feedstock_code in sorted(
        total_area.keys()
    ):
        key = (zone_id, feedstock_code)

        if total_area[key] <= 0:
            continue

        results.append(
            build_summary_row(
                scenario=scenario,
                zone_field=selected_zone_field,
                zone_name={
                    "id": zone_id,
                    "name": zone_id_to_name[zone_id],
                },
                feedstock_code=feedstock_code,
                total_pixels=total_pixels,
                total_area=total_area,
                weighted_distance_sum=(
                    weighted_distance_sum
                ),
                weighted_risk_sum=weighted_risk_sum,
                min_distance=min_distance,
                max_distance=max_distance,
                min_risk=min_risk,
                max_risk=max_risk,
                risk_class_counts=(
                    risk_class_counts
                ),
                pixel_area_km2=pixel_area_km2,
            )
        )

    # ========================================================
    # Add TOTAL_BRAZIL records for each feedstock grouping
    # ========================================================

    feedstock_codes_present = sorted({
        feedstock_code
        for _, feedstock_code in total_area.keys()
    })

    for feedstock_code in feedstock_codes_present:
        keys = [
            key for key in total_area
            if key[1] == feedstock_code
        ]

        group_area = sum(
            total_area[key]
            for key in keys
        )

        if group_area <= 0:
            continue

        group_pixels = sum(
            total_pixels[key]
            for key in keys
        )

        group_weighted_distance = sum(
            weighted_distance_sum[key]
            for key in keys
        )

        group_weighted_risk = sum(
            weighted_risk_sum[key]
            for key in keys
        )

        total_class_counts = {
            risk_class: sum(
                risk_class_counts.get(
                    (
                        zone_id,
                        feedstock_code,
                        risk_class,
                    ),
                    0
                )
                for zone_id, _ in keys
            )
            for risk_class in [1, 2, 3]
        }

        # Create temporary national dicts so the same row constructor
        # is used for zone and national summaries.
        national_zone_id = -1
        national_key = (
            national_zone_id,
            feedstock_code
        )

        national_total_pixels = {
            national_key: group_pixels
        }
        national_total_area = {
            national_key: group_area
        }
        national_weighted_distance = {
            national_key: group_weighted_distance
        }
        national_weighted_risk = {
            national_key: group_weighted_risk
        }
        national_min_distance = {
            national_key: min(
                min_distance[key]
                for key in keys
            )
        }
        national_max_distance = {
            national_key: max(
                max_distance[key]
                for key in keys
            )
        }
        national_min_risk = {
            national_key: min(
                min_risk[key]
                for key in keys
            )
        }
        national_max_risk = {
            national_key: max(
                max_risk[key]
                for key in keys
            )
        }
        national_class_counts = {
            (
                national_zone_id,
                feedstock_code,
                risk_class,
            ): total_class_counts[risk_class]
            for risk_class in [1, 2, 3]
        }

        results.append(
            build_summary_row(
                scenario=scenario,
                zone_field=selected_zone_field,
                zone_name={
                    "id": national_zone_id,
                    "name": "TOTAL_BRAZIL",
                },
                feedstock_code=feedstock_code,
                total_pixels=national_total_pixels,
                total_area=national_total_area,
                weighted_distance_sum=(
                    national_weighted_distance
                ),
                weighted_risk_sum=(
                    national_weighted_risk
                ),
                min_distance=national_min_distance,
                max_distance=national_max_distance,
                min_risk=national_min_risk,
                max_risk=national_max_risk,
                risk_class_counts=(
                    national_class_counts
                ),
                pixel_area_km2=pixel_area_km2,
            )
        )

    results = sorted(
        results,
        key=lambda row: (
            str(row[selected_zone_field]),
            int(row["feedstock_code"]),
        )
    )

    fieldnames = [
        "scenario",
        selected_zone_field,
        "feedstock",
        "feedstock_code",

        "allocated_pixels",
        "allocated_area_km2",
        "total_allocated_area_km2",

        "mean_distance_to_labor_occurrence_km",
        "min_distance_to_labor_occurrence_km",
        "max_distance_to_labor_occurrence_km",

        "mean_labor_risk_score_1_low_3_high",
        "labor_risk_index_0_low_1_high",
        "min_labor_risk_score_1_low_3_high",
        "max_labor_risk_score_1_low_3_high",

        "area_low_labor_risk_score_1_km2",
        "area_medium_labor_risk_score_2_km2",
        "area_high_labor_risk_score_3_km2",

        "share_low_labor_risk_score_1_pct",
        "share_medium_labor_risk_score_2_pct",
        "share_high_labor_risk_score_3_pct",

        "max_distance_km_used_for_score",
        "interpretation",
    ]

    summary_csv = write_csv(
        os.path.join(
            scenario_output_dir,
            f"labor_risk_score_by_zone_feedstock_"
            f"{scenario}_{run_tag}.csv"
        ),
        fieldnames,
        results
    )

    # Classified area associated with the combined union.
    combined_key = (
        -1,
        COMBINED_CODE
    )

    combined_total_row = next(
        (
            row for row in results
            if row[selected_zone_field] == "TOTAL_BRAZIL"
            and row["feedstock"] == "combined"
        ),
        None
    )

    combined_classified_area = (
        combined_total_row[
            "allocated_area_km2"
        ]
        if combined_total_row is not None
        else 0.0
    )

    print("\nLabor-risk classified combined area:")
    print(f"  {combined_classified_area:,.3f} km²")

    feedstock_ds = None
    distance_ds = None
    zones_ds = None

    return {
        "labor_risk_raster": labor_risk_path,
        "labor_risk_class_raster": labor_class_path,
        "feedstock_labor_risk_map": feedstock_map_path,
        "occurrence_raster": occurrence_raster_path,
        "distance_raster": distance_raster_path,
        "csv": summary_csv,
        "combined_classified_area_km2": (
            combined_classified_area
        ),
    }


# ============================================================
# COMBINE CSVs ACROSS SCENARIOS
# ============================================================

def combine_csvs(input_csvs, output_csv):
    """Concatenate compatible scenario-level CSVs."""
    all_rows = []
    fieldnames = None

    for csv_path in input_csvs:
        if (
            csv_path is None
            or not os.path.exists(csv_path)
        ):
            continue

        with open(
            csv_path,
            "r",
            encoding="utf-8-sig",
            newline=""
        ) as handle:
            reader = csv.DictReader(handle)

            if fieldnames is None:
                fieldnames = reader.fieldnames

            all_rows.extend(reader)

    if fieldnames is None:
        print("\nNo CSVs found to combine.")
        return None

    return write_csv(
        output_csv,
        fieldnames,
        all_rows
    )


# ============================================================
# MAIN
# ============================================================

def main():
    print("\n" + "=" * 78)
    print(
        "LABOR RISK | NEW SEQUENTIAL DOWNSCALING"
    )
    print("=" * 78)

    ensure_dir_writable(OUTPUT_DIR)

    for path, description in [
        (
            OCCURRENCES_POINTS_PATH,
            "Occurrence points shapefile"
        ),
        (
            ZONES_PATH,
            "Zones shapefile"
        ),
    ]:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"{description} not found:\n{path}"
            )

    all_outputs = []

    for scenario in SCENARIOS:
        scenario_output_dir = os.path.join(
            OUTPUT_DIR,
            scenario
        )

        ensure_dir_writable(scenario_output_dir)

        run_tag = datetime.now().strftime(
            "%Y%m%d_%H%M%S_%f"
        )

        print("\n" + "=" * 78)
        print(f"SCENARIO: {scenario}")
        print("=" * 78)

        try:
            sugarcane_raster = find_sugarcane_raster(
                scenario
            )

            soybean_raster = find_soybean_raster(
                scenario
            )

            if sugarcane_raster is None:
                raise FileNotFoundError(
                    "Could not find the final sugarcane "
                    f"raster for '{scenario}'.\n"
                    "Set MANUAL_ALLOCATION_RASTERS."
                )

            if (
                scenario
                not in SCENARIOS_WITHOUT_SOYBEAN
                and soybean_raster is None
            ):
                raise FileNotFoundError(
                    "Could not find the final soybean-after-"
                    f"sugarcane raster for '{scenario}'.\n"
                    "Set MANUAL_ALLOCATION_RASTERS."
                )

            combine_outputs = combine_feedstock_rasters(
                scenario=scenario,
                sugarcane_raster_path=sugarcane_raster,
                soybean_raster_path=soybean_raster,
                scenario_output_dir=scenario_output_dir,
                run_tag=run_tag,
            )

            labor_outputs = apply_labor_risk_indicator(
                scenario=scenario,
                combined_feedstock_raster=(
                    combine_outputs[
                        "combined_feedstock_raster"
                    ]
                ),
                scenario_output_dir=scenario_output_dir,
                run_tag=run_tag,
            )

            all_outputs.append({
                "scenario": scenario,
                **combine_outputs,
                **labor_outputs,
            })

        except Exception as exc:
            if SKIP_MISSING_SCENARIOS:
                print("\nWARNING: scenario skipped.")
                print(f"Scenario: {scenario}")
                print(exc)
                continue

            raise

    combined_run_tag = datetime.now().strftime(
        "%Y%m%d_%H%M%S_%f"
    )

    combined_csv = combine_csvs(
        input_csvs=[
            item["csv"]
            for item in all_outputs
        ],
        output_csv=os.path.join(
            OUTPUT_DIR,
            f"combined_labor_risk_score_by_zone_"
            f"feedstock_all_scenarios_"
            f"{combined_run_tag}.csv"
        )
    )

    print("\n" + "=" * 78)
    print("DONE")
    print("=" * 78)

    for item in all_outputs:
        print(f"\nScenario: {item['scenario']}")

        print("  Sugarcane raster:")
        print(f"    {item['sugarcane_raster']}")

        print("  Soybean raster:")
        print(f"    {item['soybean_raster']}")

        print("  Combined allocation area:")
        print(
            f"    {item['combined_area_km2']:,.3f} km²"
        )

        print("  Classified combined area:")
        print(
            f"    {item['combined_classified_area_km2']:,.3f} km²"
        )

        print("  Labor-risk CSV:")
        print(f"    {item['csv']}")

    print("\nCombined CSV:")
    print(combined_csv)


# QGIS Python Editor runs scripts through exec(...), so call directly.
main()
