# ============================================================
# LAND TENURE INDICATOR OVER DOWNSCALED ALLOCATED AREA
# MULTI-SCENARIO VERSION - QGIS PYTHON CONSOLE
#
# SOYBEAN VERSION
#
# The downscaled raster is used ONLY as an allocation mask.
# Any valid positive value = allocated soybean area.
#
# The final indicator raster stores RAW LAND TENURE CLASS values.
#
# Additional CSV:
#   land_tenure_risk_score_by_zone_soybean_<scenario>_<timestamp>.csv
#
# Scoring rule:
#   high risk   = score 3 = all valid classes except 1, 2, 3
#   medium risk = score 2 = raw classes 1 and 2
#   low risk    = score 1 = SIGEF / raw class 3
#
# Weighted risk score:
#   sum(score * area_km2) / total_area_km2
#
# Risk index:
#   (weighted_score - 1) / 2
#
# Interpretation:
#   weighted_score closer to 1 = lower risk
#   weighted_score closer to 3 = higher risk
# ============================================================

import os
import csv
from datetime import datetime

import numpy as np

from osgeo import gdal, ogr, osr
from qgis.core import QgsProject, QgsRasterLayer


# ============================================================
# INPUTS
# ============================================================

scenario_rasters = {
    "baseline": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\integration\scenario_baseline_soybean_after_sugarcane_downscaling\downscaled_soybean_chosen_binary_after_sugarcane_baseline_new_20260617_105457.tif",

    # "conservation": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\integration\scenario_conservation_soybean_direct_raster_downscaling\downscaled_soybean_chosen_binary_conservation.tif",

    # "governance": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\integration\scenario_governance_soybean_direct_raster_downscaling\downscaled_soybean_chosen_binary_governance.tif",

    # "degraded_pastures": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\integration\scenario_degraded_pastures_soybean_direct_raster_downscaling\downscaled_soybean_chosen_binary_degraded_pastures.tif",

    # "integrated": r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\integration\scenario_integrated_soybean_direct_raster_downscaling\downscaled_soybean_chosen_binary_integrated.tif",
}

land_tenure_raster_path = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\geospatial_data\land_tenure\raster\br_land_tenure_250m.tif"

zones_path = r"C:\Users\pcsbo\OneDrive\Doutorado\Library\Data\shapefile\zones\zones_\zones_fixed.shp"

# Leave None for automatic detection.
# If the automatic field is wrong, manually set it, for example:
# zone_field = "ZONE"
zone_field = None


# ============================================================
# OUTPUTS
# ============================================================

output_dir = r"C:\Users\pcsbo\OneDrive\PostDoc\INPE\paper_land_tenure\outputs\land_tenure_indicator_downscaled_scenarios_soybean"

os.makedirs(output_dir, exist_ok=True)


# ============================================================
# PARAMETERS
# ============================================================

output_nodata = -9999
block_size = 1024

# Optional values to exclude from the land-tenure raster.
# Keep empty unless you know some class should be ignored.
exclude_land_tenure_values = []

# Recommended False while testing to avoid QGIS locking the outputs.
# After the code is stable, you can set it to True.
load_outputs_to_qgis = False


# ============================================================
# LAND TENURE SCORING RULE
# ============================================================

# New scoring logic:
#   high risk   = score 3 = all valid classes except 1, 2, 3
#   medium risk = score 2 = raw classes 1 and 2
#   low risk    = score 1 = SIGEF / raw class 3

# Raw class 3 = SIGEF = low risk = score 1
land_tenure_low_risk_classes = [3]

# Raw classes 1 and 2 = medium risk = score 2
land_tenure_medium_risk_classes = [1, 2]


def map_land_tenure_class_to_score(land_tenure_array):
    """
    Converts raw land-tenure classes into risk score values.

    score 3 = high risk
    score 2 = medium risk
    score 1 = low risk / SIGEF
    """

    score_array = np.full(
        land_tenure_array.shape,
        3,
        dtype=np.int32
    )

    score_array[np.isin(
        land_tenure_array,
        land_tenure_medium_risk_classes
    )] = 2

    score_array[np.isin(
        land_tenure_array,
        land_tenure_low_risk_classes
    )] = 1

    return score_array


def calculate_risk_index_0_to_1(weighted_score):
    """
    Converts the 1-3 risk score into a 0-1 risk index.

    0 = lowest risk
    1 = highest risk
    """

    return (weighted_score - 1) / 2


def interpret_land_tenure_score(weighted_score):
    """
    Simple interpretation of the weighted risk score.
    """

    if weighted_score >= 2.5:
        return "high-risk dominated"

    if weighted_score >= 1.5:
        return "mixed or medium-risk dominated"

    return "low-risk dominated"


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def safe_scenario_name(name):
    return str(name).replace(" ", "_").replace("/", "_").replace("\\", "_")


def calculate_pixel_area_km2(geotransform):
    """
    Calculates pixel area in km².

    Assumes projected CRS in meters.
    Example:
        250 m x 250 m = 0.0625 km²
    """

    pixel_width = abs(geotransform[1])
    pixel_height = abs(geotransform[5])

    pixel_area_m2 = pixel_width * pixel_height
    pixel_area_km2 = pixel_area_m2 / 1_000_000

    return pixel_area_km2


def detect_zone_field(zones_layer, zone_field_input):
    """
    Detects the zone field if not provided manually.
    """

    layer_defn = zones_layer.GetLayerDefn()

    field_names = [
        layer_defn.GetFieldDefn(i).GetName()
        for i in range(layer_defn.GetFieldCount())
    ]

    print("\nFields available in zones shapefile:")
    print(field_names)

    if zone_field_input is not None:

        if zone_field_input not in field_names:
            raise Exception(
                f"Manual zone field '{zone_field_input}' was not found. "
                f"Available fields: {field_names}"
            )

        return zone_field_input

    preferred_fields = [
        "ZONE", "zone", "Zone",
        "NAME", "name", "Name",
        "ID", "id", "Id",
        "UF", "uf"
    ]

    detected = [f for f in preferred_fields if f in field_names]

    if len(detected) == 0:
        raise Exception(
            "Could not detect zone field automatically. "
            f"Available fields: {field_names}"
        )

    return detected[0]


def align_land_tenure_to_allocation(
    allocation_ds,
    land_tenure_ds,
    land_tenure_original_path,
    aligned_land_tenure_path,
    output_nodata
):
    """
    Aligns land-tenure raster to the allocation raster grid if needed.

    Uses nearest-neighbor resampling because the raster is categorical.
    """

    alloc_cols = allocation_ds.RasterXSize
    alloc_rows = allocation_ds.RasterYSize
    alloc_geotransform = allocation_ds.GetGeoTransform()
    alloc_projection = allocation_ds.GetProjection()

    lt_band = land_tenure_ds.GetRasterBand(1)
    lt_nodata = lt_band.GetNoDataValue()

    same_dimensions = (
        allocation_ds.RasterXSize == land_tenure_ds.RasterXSize and
        allocation_ds.RasterYSize == land_tenure_ds.RasterYSize
    )

    same_transform = (
        allocation_ds.GetGeoTransform() == land_tenure_ds.GetGeoTransform()
    )

    same_projection = (
        allocation_ds.GetProjection() == land_tenure_ds.GetProjection()
    )

    if same_dimensions and same_transform and same_projection:
        print("Land tenure raster is already aligned.")
        return land_tenure_original_path

    print("Land tenure raster is not aligned.")
    print("Creating aligned land tenure raster...")

    xmin = alloc_geotransform[0]
    ymax = alloc_geotransform[3]
    pixel_width = alloc_geotransform[1]
    pixel_height = alloc_geotransform[5]

    xmax = xmin + alloc_cols * pixel_width
    ymin = ymax + alloc_rows * pixel_height

    warp_kwargs = {
        "format": "GTiff",
        "outputBounds": (xmin, ymin, xmax, ymax),
        "width": alloc_cols,
        "height": alloc_rows,
        "dstSRS": alloc_projection,
        "resampleAlg": "near",
        "multithread": True,
        "creationOptions": ["COMPRESS=LZW"],
        "dstNodata": output_nodata
    }

    if lt_nodata is not None:
        warp_kwargs["srcNodata"] = lt_nodata

    warp_options = gdal.WarpOptions(**warp_kwargs)

    aligned_ds = gdal.Warp(
        aligned_land_tenure_path,
        land_tenure_ds,
        options=warp_options
    )

    if aligned_ds is None:
        raise Exception("Failed to align land tenure raster.")

    aligned_ds.FlushCache()
    aligned_ds = None

    print("Aligned land tenure raster created:")
    print(aligned_land_tenure_path)

    return aligned_land_tenure_path


def create_zones_raster(
    zones_path,
    zone_field,
    raster_projection,
    raster_geotransform,
    cols,
    rows,
    zones_raster_path
):
    """
    Rasterizes zones to the same grid as the allocation raster.

    Returns:
        zones_raster_path
        zone_id_to_name
        selected_zone_field
    """

    zones_ds = ogr.Open(zones_path)

    if zones_ds is None:
        raise Exception("Could not open zones shapefile.")

    zones_layer = zones_ds.GetLayer()

    selected_zone_field = detect_zone_field(zones_layer, zone_field)

    print("Zone field selected:", selected_zone_field)

    raster_srs = osr.SpatialReference()
    raster_srs.ImportFromWkt(raster_projection)

    zones_srs = zones_layer.GetSpatialRef()

    need_transform = False
    coord_transform = None

    if zones_srs is not None and not zones_srs.IsSame(raster_srs):
        need_transform = True
        coord_transform = osr.CoordinateTransformation(zones_srs, raster_srs)
        print("Zones CRS differs from raster CRS. Reprojecting zones in memory.")
    else:
        print("Zones CRS matches raster CRS.")

    zone_name_to_id = {}
    zone_id_to_name = {}
    current_id = 1

    for feature in zones_layer:

        zone_name = feature.GetField(selected_zone_field)

        if zone_name not in zone_name_to_id:
            zone_name_to_id[zone_name] = current_id
            zone_id_to_name[current_id] = zone_name
            current_id += 1

    zones_layer.ResetReading()

    print("Number of unique zones:", len(zone_name_to_id))

    driver_memory = ogr.GetDriverByName("Memory")
    mem_ds = driver_memory.CreateDataSource("memory_zones")

    mem_layer = mem_ds.CreateLayer(
        "zones_numeric",
        srs=raster_srs,
        geom_type=zones_layer.GetGeomType()
    )

    id_field = ogr.FieldDefn("zone_id", ogr.OFTInteger)
    mem_layer.CreateField(id_field)

    mem_layer_defn = mem_layer.GetLayerDefn()

    for feature in zones_layer:

        zone_name = feature.GetField(selected_zone_field)
        zone_id = zone_name_to_id[zone_name]

        geom = feature.GetGeometryRef()

        if geom is None:
            continue

        geom_copy = geom.Clone()

        if need_transform:
            geom_copy.Transform(coord_transform)

        new_feature = ogr.Feature(mem_layer_defn)
        new_feature.SetField("zone_id", zone_id)
        new_feature.SetGeometry(geom_copy)

        mem_layer.CreateFeature(new_feature)
        new_feature = None

    zones_layer.ResetReading()

    driver_tiff = gdal.GetDriverByName("GTiff")

    zones_raster_ds = driver_tiff.Create(
        zones_raster_path,
        cols,
        rows,
        1,
        gdal.GDT_Int32,
        options=["COMPRESS=LZW"]
    )

    if zones_raster_ds is None:
        raise Exception("Could not create zones raster.")

    zones_raster_ds.SetGeoTransform(raster_geotransform)
    zones_raster_ds.SetProjection(raster_projection)

    zones_raster_band = zones_raster_ds.GetRasterBand(1)
    zones_raster_band.SetNoDataValue(0)
    zones_raster_band.Fill(0)

    gdal.RasterizeLayer(
        zones_raster_ds,
        [1],
        mem_layer,
        options=["ATTRIBUTE=zone_id"]
    )

    zones_raster_band.FlushCache()
    zones_raster_ds.FlushCache()
    zones_raster_ds = None

    print("Zones rasterized:")
    print(zones_raster_path)

    return zones_raster_path, zone_id_to_name, selected_zone_field


def get_unique_values_from_raster(raster_path, block_size=1024):
    """
    Reads unique valid values from a raster.
    """

    ds = gdal.Open(raster_path)

    if ds is None:
        raise Exception(f"Could not open raster for checking: {raster_path}")

    band = ds.GetRasterBand(1)
    nodata = band.GetNoDataValue()

    cols = ds.RasterXSize
    rows = ds.RasterYSize

    unique_values = set()

    for y in range(0, rows, block_size):

        ysize = min(block_size, rows - y)

        for x in range(0, cols, block_size):

            xsize = min(block_size, cols - x)

            arr = band.ReadAsArray(x, y, xsize, ysize)

            if arr is None:
                continue

            arr = arr.astype(float)

            valid = np.isfinite(arr)

            if nodata is not None:
                valid &= arr != nodata

            if np.any(valid):
                vals = np.unique(arr[valid]).astype(int)

                for v in vals:
                    unique_values.add(int(v))

    ds = None

    return sorted(unique_values)


def combine_csvs(input_csvs, output_csv):
    """
    Combines scenario CSVs into one file.
    """

    rows_all = []
    fieldnames = None

    for csv_path in input_csvs:

        if not os.path.exists(csv_path):
            continue

        with open(csv_path, mode="r", encoding="utf-8-sig") as file:

            reader = csv.DictReader(file)

            if fieldnames is None:
                fieldnames = reader.fieldnames

            for row in reader:
                rows_all.append(row)

    if fieldnames is None:
        print("\nNo CSVs found to combine.")
        return

    with open(output_csv, mode="w", newline="", encoding="utf-8-sig") as file:

        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows_all)

    print("\nCombined CSV created:")
    print(output_csv)


# ============================================================
# MAIN SCENARIO FUNCTION
# ============================================================

def process_scenario(
    scenario_name,
    allocation_raster_path,
    land_tenure_raster_path,
    zones_path,
    zone_field,
    output_dir
):
    """
    Processes one scenario.
    """

    scenario_safe = safe_scenario_name(scenario_name)

    print("\n")
    print("===================================================")
    print(f"PROCESSING SCENARIO: {scenario_name}")
    print("===================================================")

    if not os.path.exists(allocation_raster_path):
        raise Exception(
            f"Allocation/downscaled raster not found for scenario '{scenario_name}':\n"
            f"{allocation_raster_path}"
        )

    scenario_output_dir = os.path.join(output_dir, scenario_safe)
    os.makedirs(scenario_output_dir, exist_ok=True)

    run_tag = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    aligned_land_tenure_path = os.path.join(
        scenario_output_dir,
        f"land_tenure_aligned_to_{scenario_safe}_{run_tag}.tif"
    )

    zones_raster_path = os.path.join(
        scenario_output_dir,
        f"zones_raster_aligned_to_{scenario_safe}_{run_tag}.tif"
    )

    indicator_raster_path = os.path.join(
        scenario_output_dir,
        f"land_tenure_indicator_soybean_{scenario_safe}_{run_tag}.tif"
    )

    distribution_csv = os.path.join(
        scenario_output_dir,
        f"land_tenure_distribution_by_zone_soybean_{scenario_safe}_{run_tag}.csv"
    )

    risk_score_csv = os.path.join(
        scenario_output_dir,
        f"land_tenure_risk_score_by_zone_soybean_{scenario_safe}_{run_tag}.csv"
    )

    alloc_ds = gdal.Open(allocation_raster_path)
    lt_ds = gdal.Open(land_tenure_raster_path)

    if alloc_ds is None:
        raise Exception(f"Could not open allocation raster: {allocation_raster_path}")

    if lt_ds is None:
        raise Exception(f"Could not open land tenure raster: {land_tenure_raster_path}")

    alloc_band = alloc_ds.GetRasterBand(1)
    alloc_nodata = alloc_band.GetNoDataValue()

    cols = alloc_ds.RasterXSize
    rows = alloc_ds.RasterYSize
    geotransform = alloc_ds.GetGeoTransform()
    projection = alloc_ds.GetProjection()

    pixel_area_km2 = calculate_pixel_area_km2(geotransform)

    print("Downscaled allocation raster loaded.")
    print("Rows:", rows)
    print("Columns:", cols)
    print("Allocation NoData:", alloc_nodata)
    print("Pixel area km²:", pixel_area_km2)

    print("\nLand tenure raster loaded.")
    print("Rows:", lt_ds.RasterXSize)
    print("Columns:", lt_ds.RasterYSize)
    print("Land tenure NoData:", lt_ds.GetRasterBand(1).GetNoDataValue())

    lt_for_analysis_path = align_land_tenure_to_allocation(
        allocation_ds=alloc_ds,
        land_tenure_ds=lt_ds,
        land_tenure_original_path=land_tenure_raster_path,
        aligned_land_tenure_path=aligned_land_tenure_path,
        output_nodata=output_nodata
    )

    lt_ds = None

    lt_ds = gdal.Open(lt_for_analysis_path)

    if lt_ds is None:
        raise Exception("Could not reopen aligned land tenure raster.")

    lt_band = lt_ds.GetRasterBand(1)
    lt_nodata = lt_band.GetNoDataValue()

    zones_raster_path, zone_id_to_name, selected_zone_field = create_zones_raster(
        zones_path=zones_path,
        zone_field=zone_field,
        raster_projection=projection,
        raster_geotransform=geotransform,
        cols=cols,
        rows=rows,
        zones_raster_path=zones_raster_path
    )

    zones_raster_ds = gdal.Open(zones_raster_path)

    if zones_raster_ds is None:
        raise Exception("Could not open zones raster.")

    zones_raster_band = zones_raster_ds.GetRasterBand(1)

    driver_tiff = gdal.GetDriverByName("GTiff")

    indicator_ds = driver_tiff.Create(
        indicator_raster_path,
        cols,
        rows,
        1,
        gdal.GDT_Int32,
        options=["COMPRESS=LZW"]
    )

    if indicator_ds is None:
        raise Exception("Could not create indicator raster.")

    indicator_ds.SetGeoTransform(geotransform)
    indicator_ds.SetProjection(projection)

    indicator_band = indicator_ds.GetRasterBand(1)
    indicator_band.SetNoDataValue(output_nodata)
    indicator_band.Fill(output_nodata)

    class_counts_by_zone = {}
    total_pixels_by_zone = {}
    score_counts_by_zone = {}
    weighted_score_sum_by_zone = {}
    total_area_by_zone = {}

    print("\nCreating land tenure indicator raster and computing distributions...")

    for y in range(0, rows, block_size):

        ysize = min(block_size, rows - y)

        for x in range(0, cols, block_size):

            xsize = min(block_size, cols - x)

            alloc_array = alloc_band.ReadAsArray(x, y, xsize, ysize)
            lt_array = lt_band.ReadAsArray(x, y, xsize, ysize)
            zone_array = zones_raster_band.ReadAsArray(x, y, xsize, ysize)

            if alloc_array is None or lt_array is None or zone_array is None:
                continue

            alloc_array = alloc_array.astype(float)
            lt_array = lt_array.astype(float)
            zone_array = zone_array.astype(int)

            output_array = np.full(
                alloc_array.shape,
                output_nodata,
                dtype=np.int32
            )

            valid_alloc = np.isfinite(alloc_array)

            if alloc_nodata is not None:
                valid_alloc &= alloc_array != alloc_nodata

            valid_alloc &= alloc_array > 0

            valid_lt = np.isfinite(lt_array)

            if lt_nodata is not None:
                valid_lt &= lt_array != lt_nodata

            if len(exclude_land_tenure_values) > 0:
                for excluded_value in exclude_land_tenure_values:
                    valid_lt &= lt_array != excluded_value

            valid_zone = zone_array > 0

            valid_mask = valid_alloc & valid_lt & valid_zone

            output_array[valid_mask] = lt_array[valid_mask].astype(np.int32)
            indicator_band.WriteArray(output_array, x, y)

            selected_zones = zone_array[valid_mask]
            selected_land_tenure_classes = lt_array[valid_mask].astype(np.int32)

            if selected_zones.size == 0:
                continue

            raw_pairs = np.column_stack(
                (
                    selected_zones,
                    selected_land_tenure_classes
                )
            )

            unique_raw_pairs, raw_pair_counts = np.unique(
                raw_pairs,
                axis=0,
                return_counts=True
            )

            for pair, count in zip(unique_raw_pairs, raw_pair_counts):

                zone_id = int(pair[0])
                land_tenure_class = int(pair[1])
                count = int(count)

                key = (zone_id, land_tenure_class)

                class_counts_by_zone[key] = (
                    class_counts_by_zone.get(key, 0) + count
                )

            unique_zones, zone_counts = np.unique(
                selected_zones,
                return_counts=True
            )

            for zone_id, count in zip(unique_zones, zone_counts):

                zone_id = int(zone_id)
                count = int(count)

                total_pixels_by_zone[zone_id] = (
                    total_pixels_by_zone.get(zone_id, 0) + count
                )

            selected_scores = map_land_tenure_class_to_score(
                selected_land_tenure_classes
            ).astype(np.int32)

            score_pairs = np.column_stack(
                (
                    selected_zones,
                    selected_scores
                )
            )

            unique_score_pairs, score_pair_counts = np.unique(
                score_pairs,
                axis=0,
                return_counts=True
            )

            for pair, count in zip(unique_score_pairs, score_pair_counts):

                zone_id = int(pair[0])
                score = int(pair[1])
                count = int(count)

                key = (zone_id, score)

                score_counts_by_zone[key] = (
                    score_counts_by_zone.get(key, 0) + count
                )

                area_km2 = count * pixel_area_km2

                weighted_score_sum_by_zone[zone_id] = (
                    weighted_score_sum_by_zone.get(zone_id, 0.0)
                    + score * area_km2
                )

                total_area_by_zone[zone_id] = (
                    total_area_by_zone.get(zone_id, 0.0)
                    + area_km2
                )

        print(f"Processed row {min(y + block_size, rows)} of {rows}")

    indicator_band.FlushCache()
    indicator_ds.FlushCache()
    indicator_ds = None

    print("\nLand tenure indicator raster created:")
    print(indicator_raster_path)

    # ========================================================
    # CSV 1: raw land-tenure class distribution by zone
    # ========================================================

    distribution_results = []

    for (zone_id, land_tenure_class), pixel_count in sorted(class_counts_by_zone.items()):

        zone_name = zone_id_to_name[zone_id]
        total_pixels_zone = total_pixels_by_zone[zone_id]

        area_km2 = pixel_count * pixel_area_km2
        total_allocated_area_km2 = total_pixels_zone * pixel_area_km2
        percentage_in_zone = (pixel_count / total_pixels_zone) * 100

        distribution_results.append({
            "scenario": scenario_name,
            selected_zone_field: zone_name,
            "land_tenure_class": land_tenure_class,
            "pixel_count": pixel_count,
            "area_km2": area_km2,
            "total_pixels_in_zone": total_pixels_zone,
            "total_allocated_area_in_zone_km2": total_allocated_area_km2,
            "percentage_in_zone": percentage_in_zone
        })

    distribution_fieldnames = [
        "scenario",
        selected_zone_field,
        "land_tenure_class",
        "pixel_count",
        "area_km2",
        "total_pixels_in_zone",
        "total_allocated_area_in_zone_km2",
        "percentage_in_zone"
    ]

    with open(distribution_csv, mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=distribution_fieldnames)
        writer.writeheader()
        writer.writerows(distribution_results)

    print("\nRaw class distribution CSV created:")
    print(distribution_csv)

    # ========================================================
    # CSV 2: weighted land-tenure risk score by zone
    # ========================================================

    risk_score_results = []

    total_area_all_zones = 0.0
    total_weighted_score_all_zones = 0.0

    total_score_area_all_zones = {
        1: 0.0,
        2: 0.0,
        3: 0.0
    }

    for zone_id in sorted(total_area_by_zone.keys()):

        zone_name = zone_id_to_name[zone_id]
        total_area_km2 = total_area_by_zone[zone_id]

        if total_area_km2 <= 0:
            continue

        weighted_score_sum = weighted_score_sum_by_zone.get(zone_id, 0.0)
        weighted_score = weighted_score_sum / total_area_km2
        risk_index_0_to_1 = calculate_risk_index_0_to_1(weighted_score)

        area_score_1 = score_counts_by_zone.get((zone_id, 1), 0) * pixel_area_km2
        area_score_2 = score_counts_by_zone.get((zone_id, 2), 0) * pixel_area_km2
        area_score_3 = score_counts_by_zone.get((zone_id, 3), 0) * pixel_area_km2

        total_area_all_zones += total_area_km2
        total_weighted_score_all_zones += weighted_score_sum

        total_score_area_all_zones[1] += area_score_1
        total_score_area_all_zones[2] += area_score_2
        total_score_area_all_zones[3] += area_score_3

        risk_score_results.append({
            "scenario": scenario_name,
            selected_zone_field: zone_name,
            "total_allocated_area_km2": total_area_km2,

            "area_low_risk_sigef_score_1_km2": area_score_1,
            "area_medium_risk_score_2_km2": area_score_2,
            "area_high_risk_score_3_km2": area_score_3,

            "share_low_risk_sigef_score_1_pct": (area_score_1 / total_area_km2) * 100,
            "share_medium_risk_score_2_pct": (area_score_2 / total_area_km2) * 100,
            "share_high_risk_score_3_pct": (area_score_3 / total_area_km2) * 100,

            "land_tenure_risk_score_1_low_3_high": weighted_score,
            "land_tenure_risk_index_0_low_1_high": risk_index_0_to_1,
            "interpretation": interpret_land_tenure_score(weighted_score)
        })

    if total_area_all_zones > 0:

        total_weighted_score = total_weighted_score_all_zones / total_area_all_zones
        total_risk_index_0_to_1 = calculate_risk_index_0_to_1(total_weighted_score)

        risk_score_results.append({
            "scenario": scenario_name,
            selected_zone_field: "TOTAL",
            "total_allocated_area_km2": total_area_all_zones,

            "area_low_risk_sigef_score_1_km2": total_score_area_all_zones[1],
            "area_medium_risk_score_2_km2": total_score_area_all_zones[2],
            "area_high_risk_score_3_km2": total_score_area_all_zones[3],

            "share_low_risk_sigef_score_1_pct": (total_score_area_all_zones[1] / total_area_all_zones) * 100,
            "share_medium_risk_score_2_pct": (total_score_area_all_zones[2] / total_area_all_zones) * 100,
            "share_high_risk_score_3_pct": (total_score_area_all_zones[3] / total_area_all_zones) * 100,

            "land_tenure_risk_score_1_low_3_high": total_weighted_score,
            "land_tenure_risk_index_0_low_1_high": total_risk_index_0_to_1,
            "interpretation": interpret_land_tenure_score(total_weighted_score)
        })

    risk_score_fieldnames = [
        "scenario",
        selected_zone_field,
        "total_allocated_area_km2",

        "area_low_risk_sigef_score_1_km2",
        "area_medium_risk_score_2_km2",
        "area_high_risk_score_3_km2",

        "share_low_risk_sigef_score_1_pct",
        "share_medium_risk_score_2_pct",
        "share_high_risk_score_3_pct",

        "land_tenure_risk_score_1_low_3_high",
        "land_tenure_risk_index_0_low_1_high",
        "interpretation"
    ]

    with open(risk_score_csv, mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=risk_score_fieldnames)
        writer.writeheader()
        writer.writerows(risk_score_results)

    print("\nWeighted risk score CSV created:")
    print(risk_score_csv)

    unique_indicator_values = get_unique_values_from_raster(
        raster_path=indicator_raster_path,
        block_size=block_size
    )

    print("\nUnique RAW LAND TENURE classes in final indicator raster:")
    print(unique_indicator_values)

    if len(unique_indicator_values) == 1:
        print(
            "\nWARNING: The final indicator raster has only one valid land-tenure class. "
            "This can be correct if all allocated pixels fall in the same land-tenure class."
        )

    if load_outputs_to_qgis:

        indicator_layer = QgsRasterLayer(
            indicator_raster_path,
            f"Land Tenure Indicator - Soybean - {scenario_name}"
        )

        if indicator_layer.isValid():
            QgsProject.instance().addMapLayer(indicator_layer)
            print("\nIndicator raster added to QGIS.")
        else:
            print("\nRaster created, but it could not be automatically loaded.")

    alloc_ds = None
    lt_ds = None
    zones_raster_ds = None

    return {
        "scenario": scenario_name,
        "indicator_raster": indicator_raster_path,
        "distribution_csv": distribution_csv,
        "risk_score_csv": risk_score_csv,
        "unique_indicator_values": unique_indicator_values
    }


# ============================================================
# MAIN EXECUTION
# ============================================================

gdal.UseExceptions()

all_outputs = []

for scenario_name, allocation_raster_path in scenario_rasters.items():

    outputs = process_scenario(
        scenario_name=scenario_name,
        allocation_raster_path=allocation_raster_path,
        land_tenure_raster_path=land_tenure_raster_path,
        zones_path=zones_path,
        zone_field=zone_field,
        output_dir=output_dir
    )

    all_outputs.append(outputs)


# ============================================================
# COMBINED CSVS FOR THIS RUN
# ============================================================

combined_run_tag = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

combined_distribution_csv = os.path.join(
    output_dir,
    f"combined_land_tenure_distribution_by_zone_all_scenarios_soybean_{combined_run_tag}.csv"
)

combine_csvs(
    input_csvs=[item["distribution_csv"] for item in all_outputs],
    output_csv=combined_distribution_csv
)

combined_risk_score_csv = os.path.join(
    output_dir,
    f"combined_land_tenure_risk_score_by_zone_all_scenarios_soybean_{combined_run_tag}.csv"
)

combine_csvs(
    input_csvs=[item["risk_score_csv"] for item in all_outputs],
    output_csv=combined_risk_score_csv
)


# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n===================================================")
print("DONE")
print("===================================================")

for item in all_outputs:

    print("\nScenario:", item["scenario"])
    print("Indicator raster:")
    print(item["indicator_raster"])
    print("Raw class distribution CSV:")
    print(item["distribution_csv"])
    print("Weighted risk score CSV:")
    print(item["risk_score_csv"])
    print("Unique raw land tenure classes in indicator raster:")
    print(item["unique_indicator_values"])

print("\nCombined raw class distribution CSV:")
print(combined_distribution_csv)

print("\nCombined weighted risk score CSV:")
print(combined_risk_score_csv)